package com.gesundheit.fullround;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class DbHelper {
    // New file name ensures an update from the old large DB uses the compact app DB.
    private static final String DB_NAME = "fullround_rankpair_app_v4.sqlite";
    private final Context context;
    private SQLiteDatabase db;
    private boolean validated;

    public DbHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    public SQLiteDatabase open() throws IOException {
        if (db != null && db.isOpen()) return db;
        File out = context.getDatabasePath(DB_NAME);
        File parent = out.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        if (!out.exists() || out.length() < 128L * 1024L) {
            copyAsset(DB_NAME, out);
        }
        db = SQLiteDatabase.openDatabase(out.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
        validateDatabase(db);
        return db;
    }

    private void copyAsset(String assetName, File destination) throws IOException {
        try (InputStream in = context.getAssets().open(assetName);
             FileOutputStream out = new FileOutputStream(destination)) {
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
        }
    }

    private void validateDatabase(SQLiteDatabase database) throws IOException {
        if (validated) return;
        requireTable(database, "round_signatures");
        requireTable(database, "round_signatures_unordered");
        try (Cursor c = database.rawQuery("PRAGMA quick_check", null)) {
            if (!c.moveToFirst() || !"ok".equalsIgnoreCase(c.getString(0))) {
                throw new IOException("SQLite quick_check fehlgeschlagen.");
            }
        }
        validated = true;
    }

    private void requireTable(SQLiteDatabase database, String table) throws IOException {
        try (Cursor c = database.rawQuery(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                new String[]{table})) {
            if (!c.moveToFirst()) {
                throw new IOException("Pflichttabelle fehlt: " + table);
            }
        }
    }

    public AnalysisResult analyze(int tableSize, int kPlayed, String signatureInput) throws Exception {
        if (kPlayed < 0) throw new IllegalArgumentException("K darf nicht negativ sein.");

        SQLiteDatabase database = open();
        String directedSignature = SignatureUtil.normalizeAndValidateDirectedSignature(signatureInput, tableSize);
        String unorderedSignature = SignatureUtil.toUnorderedSignature(directedSignature);
        List<String> targetPairs = SignatureUtil.splitPairs(directedSignature);

        AnalysisResult result = new AnalysisResult();
        result.tableSize = tableSize;
        result.kPlayed = kPlayed;
        result.directedSignature = directedSignature;
        result.unorderedSignature = unorderedSignature;

        // Main search levels.
        result.directedWithK = queryDirected(database, tableSize, kPlayed, directedSignature);
        result.directedAnyK = queryDirectedAnyK(database, tableSize, directedSignature);

        // Main diagnostic: unordered Full-Round without K, then today's direction per pair.
        result.unorderedAnyK = queryUnorderedAnyK(database, tableSize, unorderedSignature);

        // Extra audit only, not a release level.
        result.unorderedWithK = queryUnordered(database, tableSize, kPlayed, unorderedSignature);

        result.pairSummaries.put("directed_with_k", summarizePairs(targetPairs, result.directedWithK));
        result.pairSummaries.put("directed_any_k", summarizePairs(targetPairs, result.directedAnyK));
        result.pairSummaries.put("unordered_any_k_direction_checked", summarizePairs(targetPairs, result.unorderedAnyK));
        result.pairSummaries.put("unordered_with_k_direction_checked", summarizePairs(targetPairs, result.unorderedWithK));
        return result;
    }

    private List<RoundHit> queryDirected(SQLiteDatabase db, int tableSize, int kPlayed, String signature) {
        String sql = "SELECT round_uid, league_code, season_key, table_size, k_played, date_min, date_max, signature, result_vector, score_vector " +
                "FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?";
        return queryRoundHits(db, sql, new String[]{String.valueOf(tableSize), String.valueOf(kPlayed), signature}, false);
    }

    private List<RoundHit> queryDirectedAnyK(SQLiteDatabase db, int tableSize, String signature) {
        String sql = "SELECT round_uid, league_code, season_key, table_size, k_played, date_min, date_max, signature, result_vector, score_vector " +
                "FROM round_signatures WHERE table_size=? AND signature=?";
        return queryRoundHits(db, sql, new String[]{String.valueOf(tableSize), signature}, false);
    }

    private List<RoundHit> queryUnordered(SQLiteDatabase db, int tableSize, int kPlayed, String unorderedSignature) {
        String sql = "SELECT round_uid, league_code, season_key, table_size, k_played, date_min, date_max, directed_signature, result_vector, score_vector " +
                "FROM round_signatures_unordered WHERE table_size=? AND k_played=? AND unordered_signature=?";
        return queryRoundHits(db, sql, new String[]{String.valueOf(tableSize), String.valueOf(kPlayed), unorderedSignature}, true);
    }

    private List<RoundHit> queryUnorderedAnyK(SQLiteDatabase db, int tableSize, String unorderedSignature) {
        String sql = "SELECT round_uid, league_code, season_key, table_size, k_played, date_min, date_max, directed_signature, result_vector, score_vector " +
                "FROM round_signatures_unordered WHERE table_size=? AND unordered_signature=?";
        return queryRoundHits(db, sql, new String[]{String.valueOf(tableSize), unorderedSignature}, true);
    }

    private List<RoundHit> queryRoundHits(SQLiteDatabase db, String sql, String[] args, boolean unorderedMode) {
        List<RoundHit> out = new ArrayList<>();
        try (Cursor c = db.rawQuery(sql, args)) {
            while (c.moveToNext()) {
                RoundHit h = new RoundHit();
                h.roundUid = c.getString(0);
                h.leagueCode = c.getString(1);
                h.seasonKey = c.getString(2);
                h.tableSize = c.getInt(3);
                h.kPlayed = c.getInt(4);
                h.dateMin = c.getString(5);
                h.dateMax = c.getString(6);
                h.signature = c.getString(7);
                h.resultVector = c.getString(8);
                h.scoreVector = c.getString(9);
                h.unorderedMode = unorderedMode;
                out.add(h);
            }
        }
        return out;
    }

    private List<PairSummary> summarizePairs(List<String> targetPairs, List<RoundHit> hits) {
        Map<String, PairSummary> map = new LinkedHashMap<>();
        for (String p : targetPairs) map.put(p, new PairSummary(p));
        for (RoundHit hit : hits) {
            Map<String, String> resultsByPair = SignatureUtil.parseResultVector(hit.resultVector);
            for (String p : targetPairs) {
                String r = resultsByPair.get(p);
                if (r == null) continue; // Direction mismatch: never flip Home/Away.
                PairSummary s = map.get(p);
                s.n++;
                if ("1".equals(r)) s.one++;
                else if ("X".equalsIgnoreCase(r)) s.draw++;
                else if ("2".equals(r)) s.two++;
            }
        }
        return new ArrayList<>(map.values());
    }

    public static final class RoundHit {
        public String roundUid;
        public String leagueCode;
        public String seasonKey;
        public int tableSize;
        public int kPlayed;
        public String dateMin;
        public String dateMax;
        public String signature;
        public String resultVector;
        public String scoreVector;
        public boolean unorderedMode;
    }

    public static final class PairSummary {
        public final String pair;
        public int n;
        public int one;
        public int draw;
        public int two;

        public PairSummary(String pair) { this.pair = pair; }

        public int resultTypes() {
            int t = 0;
            if (one > 0) t++;
            if (draw > 0) t++;
            if (two > 0) t++;
            return t;
        }

        public String market() {
            boolean h = one > 0, x = draw > 0, a = two > 0;
            if (resultTypes() == 0) return "NO_SIGNAL";
            if (resultTypes() == 3) return "RAUS: 1/X/2";

            String base;
            if (h && x && !a) base = "1X";
            else if (!h && x && a) base = "X2";
            else if (h && !x && a) base = "12";
            else if (h) base = "1 / 1X";
            else if (x) base = "X only, vorsichtig";
            else base = "2 / X2";

            if (n == 1) base += ", Low-N";
            return base;
        }

        public boolean candidate() {
            return n > 0 && resultTypes() <= 2;
        }
    }

    public static final class AnalysisResult {
        public int tableSize;
        public int kPlayed;
        public String directedSignature;
        public String unorderedSignature;
        public List<RoundHit> directedWithK = new ArrayList<>();
        public List<RoundHit> directedAnyK = new ArrayList<>();
        public List<RoundHit> unorderedWithK = new ArrayList<>();
        public List<RoundHit> unorderedAnyK = new ArrayList<>();
        public Map<String, List<PairSummary>> pairSummaries = new HashMap<>();
    }
}
