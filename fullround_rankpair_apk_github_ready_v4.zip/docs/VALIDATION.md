# Validation — App DB v4

- SQLite `PRAGMA quick_check = ok`
- `round_signatures = 10260`
- `round_signatures_unordered = 10260`
- every stored row satisfies `num_games * 2 = table_size`
- no standalone rankpair fallback tables are bundled
- directed signature remains Home/Away-sensitive
- unordered signature is diagnostic only; current Home/Away direction must still occur in the historical directed result vector

## Expanded freeze audit

- balanced DB1 snapshots inspected: 10,457
- snapshot-frozen valid rounds: 9,679
- rejected because a team repeated before the round was complete: 760
- rejected incomplete season tails: 18
- retained legacy-only non-conflicting rows from v3: 581
- final total: 10,260
