# GitHub Actions – APK-Build freigeben

Der Workflow unter `.github/workflows/build.yml` verwendet absichtlich nur GitHub-eigene Actions:

- `actions/checkout`
- `actions/setup-java`
- `actions/upload-artifact`

Alle Actions sind auf vollständige Commit-SHAs gepinnt. Es werden **keine Drittanbieter-Actions** benötigt.
Android SDK und Gradle werden direkt per Shell im GitHub-Runner vorbereitet.

## Repository-Einstellung

Falls GitHub meldet, dass Actions/Workflows nicht erlaubt sind:

1. Repository öffnen.
2. **Settings** → **Actions** → **General**.
3. Unter **Actions permissions** mindestens GitHub-eigene Actions zulassen.
   - Bei persönlichem Repository kann auch `Allow all actions and reusable workflows` verwendet werden.
4. Speichern.
5. Tab **Actions** öffnen.
6. Workflow **Build Android APK** wählen.
7. **Run workflow** → Branch `main` → **Run workflow**.

## Wenn die Einstellung gesperrt ist

Liegt das Repository in einer Organisation, kann eine Organisations- oder Enterprise-Richtlinie Actions blockieren.
Dann kann die Repository-Einstellung nicht selbst überstimmt werden. In diesem Fall muss die Organisation GitHub Actions bzw. GitHub-eigene Actions freigeben.

## APK herunterladen

Nach erfolgreichem Lauf:

1. Workflow-Lauf öffnen.
2. Unten bei **Artifacts** auf `fullround-rankpair-debug-apk` klicken.
3. ZIP herunterladen und entpacken.
4. Darin liegt die Debug-APK.
