# Expanded Full-Round App DB v4

The v4 app DB contains 10,260 historical Full-Rounds (directed + unordered mirrors).

## Primary expansion method

The new rows are rebuilt from `db1_snapshot_team_rows` + `db1_match_context` in the unified master DB.
A historical checkpoint is accepted only when:

1. the full snapshot contains every rank `1..table_size` exactly once;
2. every team in the snapshot has exactly the same `played = K`;
3. `K >= 1`;
4. starting from that frozen snapshot, the next `table_size / 2` historical matches cover every team exactly once;
5. no team appears a second time before all teams have played once.

All rank pairs in the target round are generated from the SAME frozen table after K. Home/Away is never flipped.

This produced 9,679 snapshot-frozen rounds. The former v3 index contained 2,999 rows; 2,418 were exact matches to the new snapshot rebuild. The remaining 581 old rows were legacy-only rounds from master coverage not represented by DB1 snapshots. They were retained because none conflicted with an available snapshot-frozen `(league, season, table_size, K)` round.

Final v4 total: **10,260**.

## Coverage by table size

| Teams | Rounds | Distinct unordered signatures |
|---:|---:|---:|
| 10 | 1,338 | 697 |
| 12 | 383 | 370 |
| 14 | 80 | 80 |
| 16 | 740 | 740 |
| 18 | 3,134 | 3,134 |
| 20 | 2,570 | 2,570 |
| 22 | 1,029 | 1,029 |
| 24 | 975 | 975 |

The DB contains no standalone rankpair fallback tables.
