#!/usr/bin/env python3
import argparse
import bisect
import collections
import hashlib
import os
import sqlite3
import sys

SCHEMA_DIRECTED = '''
CREATE TABLE round_signatures(
 round_uid TEXT PRIMARY KEY,
 league_code TEXT NOT NULL,
 season_key TEXT NOT NULL,
 table_size INTEGER NOT NULL,
 k_played INTEGER NOT NULL,
 num_games INTEGER NOT NULL,
 date_min TEXT,
 date_max TEXT,
 signature TEXT NOT NULL,
 result_vector TEXT,
 score_vector TEXT
)
'''
SCHEMA_UNORDERED = '''
CREATE TABLE round_signatures_unordered(
 round_uid TEXT PRIMARY KEY,
 league_code TEXT NOT NULL,
 season_key TEXT NOT NULL,
 table_size INTEGER NOT NULL,
 k_played INTEGER NOT NULL,
 num_games INTEGER NOT NULL,
 date_min TEXT,
 date_max TEXT,
 unordered_signature TEXT NOT NULL,
 directed_signature TEXT NOT NULL,
 result_vector TEXT,
 score_vector TEXT
)
'''

def build(master, out):
    src = sqlite3.connect(f'file:{master}?mode=ro', uri=True)
    src.execute('PRAGMA query_only=ON')

    balanced = src.execute('''
    WITH g AS (
      SELECT snapshot_id, division, season_key, match_date,
             MAX(table_size) AS table_size,
             MIN(played) AS k_min, MAX(played) AS k_max,
             COUNT(*) AS row_count, COUNT(DISTINCT team) AS team_count
      FROM db1_snapshot_team_rows
      GROUP BY snapshot_id, division, season_key, match_date
    )
    SELECT snapshot_id, division, season_key, match_date, table_size, k_min
    FROM g
    WHERE table_size % 2 = 0
      AND k_min = k_max
      AND row_count = table_size
      AND team_count = table_size
      AND k_min >= 1
    ORDER BY division, season_key, match_date
    ''').fetchall()
    balanced_ids = {r[0] for r in balanced}

    ranks = collections.defaultdict(dict)
    for sid, team, rank in src.execute(
        'SELECT snapshot_id, team, rank FROM db1_snapshot_team_rows ORDER BY snapshot_id, rank'
    ):
        if sid in balanced_ids:
            ranks[sid][team] = int(rank)

    matches = collections.defaultdict(list)
    for row in src.execute('''
        SELECT division, season_key, match_date, archive_row_id,
               home_team, away_team, home_goals, away_goals, actual_1x2, table_size
        FROM db1_match_context
        WHERE home_goals IS NOT NULL AND away_goals IS NOT NULL
        ORDER BY division, season_key, match_date, archive_row_id
    '''):
        matches[(row[0], row[1])].append(row)
    src.close()

    season_dates = {key: [r[2] for r in rows] for key, rows in matches.items()}
    output = []
    rejected = collections.Counter()

    for sid, league, season, snap_date, n, k in balanced:
        n, k = int(n), int(k)
        snap = ranks.get(sid, {})
        if len(snap) != n or set(snap.values()) != set(range(1, n + 1)):
            rejected['bad_snapshot_rank_map'] += 1
            continue

        season_rows = matches.get((league, season))
        if not season_rows:
            rejected['no_season_matches'] += 1
            continue

        idx = bisect.bisect_left(season_dates[(league, season)], snap_date)
        seen = set()
        picked = []
        invalid_reason = None

        j = idx
        while j < len(season_rows) and len(seen) < n:
            row = season_rows[j]
            _, _, match_date, archive_id, home, away, hg, ag, result, table_size = row
            if int(table_size) != n or home not in snap or away not in snap:
                invalid_reason = 'team_or_size_change'
                break
            if home in seen or away in seen:
                invalid_reason = 'repeat_team_before_round_complete'
                break
            seen.add(home)
            seen.add(away)
            picked.append(row)
            j += 1

        if invalid_reason:
            rejected[invalid_reason] += 1
            continue
        if len(picked) != n // 2 or len(seen) != n:
            rejected['incomplete_tail'] += 1
            continue
        if picked[0][2] != snap_date:
            rejected['snapshot_without_match_on_same_date'] += 1
            continue

        pairs = []
        for row in picked:
            _, _, match_date, archive_id, home, away, hg, ag, result, table_size = row
            hr, ar = snap[home], snap[away]
            if result not in ('1', 'X', '2'):
                rejected['bad_result_label'] += 1
                pairs = []
                break
            pairs.append((hr, ar, result, int(hg), int(ag), home, away, match_date))
        if not pairs:
            continue

        # Directed signature is canonical by HOME rank; Home/Away is NEVER flipped.
        pairs.sort(key=lambda x: (x[0], x[1]))
        directed = '|'.join(f'{hr}->{ar}' for hr, ar, *_ in pairs)
        result_vector = '|'.join(f'{hr}->{ar}:{result}' for hr, ar, result, *_ in pairs)
        score_vector = '|'.join(f'{hr}->{ar}:{hg}-{ag}' for hr, ar, result, hg, ag, *_ in pairs)

        unordered_pairs = sorted((min(hr, ar), max(hr, ar)) for hr, ar, *_ in pairs)
        unordered = '|'.join(f'{a}-{b}' for a, b in unordered_pairs)

        # Hard structural validation: every frozen rank 1..N exactly once.
        rank_use = []
        for hr, ar, *_ in pairs:
            rank_use.extend((hr, ar))
        if sorted(rank_use) != list(range(1, n + 1)):
            rejected['rank_coverage_failure'] += 1
            continue

        dates = [p[7] for p in pairs]
        date_min, date_max = min(dates), max(dates)
        uid = f'DB1SNAP|{league}|{season}|T{n}|K{k}|{sid}|{date_min}|{date_max}'
        output.append((uid, league, season, n, k, n // 2, date_min, date_max,
                       directed, result_vector, score_vector, unordered))

    # Defensive duplicate round_uid check.
    if len({r[0] for r in output}) != len(output):
        raise RuntimeError('duplicate round_uid generated')

    if os.path.exists(out):
        os.remove(out)
    db = sqlite3.connect(out)
    db.execute('PRAGMA journal_mode=OFF')
    db.execute('PRAGMA synchronous=OFF')
    db.execute('PRAGMA temp_store=MEMORY')
    db.execute(SCHEMA_DIRECTED)
    db.execute(SCHEMA_UNORDERED)

    db.executemany('''INSERT INTO round_signatures
        (round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,signature,result_vector,score_vector)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)''', [r[:11] for r in output])
    db.executemany('''INSERT INTO round_signatures_unordered
        (round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,unordered_signature,directed_signature,result_vector,score_vector)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
        [(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[11],r[8],r[9],r[10]) for r in output])

    db.executescript('''
      CREATE INDEX idx_rs_directed_k ON round_signatures(table_size,k_played,signature);
      CREATE INDEX idx_rs_directed_any ON round_signatures(table_size,signature);
      CREATE INDEX idx_ru_unordered_k ON round_signatures_unordered(table_size,k_played,unordered_signature);
      CREATE INDEX idx_ru_unordered_any ON round_signatures_unordered(table_size,unordered_signature);
      CREATE INDEX idx_rs_league_season_k ON round_signatures(league_code,season_key,k_played);
    ''')
    db.commit()

    qc = db.execute('PRAGMA quick_check').fetchone()[0]
    if qc != 'ok':
        raise RuntimeError(f'quick_check failed: {qc}')
    bad1 = db.execute('SELECT COUNT(*) FROM round_signatures WHERE num_games*2<>table_size').fetchone()[0]
    bad2 = db.execute('SELECT COUNT(*) FROM round_signatures_unordered WHERE num_games*2<>table_size').fetchone()[0]
    if bad1 or bad2:
        raise RuntimeError(f'incomplete rounds: directed={bad1} unordered={bad2}')

    by_size = db.execute('SELECT table_size,COUNT(*) FROM round_signatures GROUP BY table_size ORDER BY table_size').fetchall()
    distinct_unordered = db.execute('SELECT table_size,COUNT(DISTINCT unordered_signature) FROM round_signatures_unordered GROUP BY table_size ORDER BY table_size').fetchall()
    distinct_directed = db.execute('SELECT table_size,COUNT(DISTINCT signature) FROM round_signatures GROUP BY table_size ORDER BY table_size').fetchall()
    leagues = db.execute('SELECT COUNT(DISTINCT league_code),COUNT(DISTINCT league_code||"|"||season_key) FROM round_signatures').fetchone()
    count = db.execute('SELECT COUNT(*) FROM round_signatures').fetchone()[0]
    db.close()

    return {
        'balanced_snapshots': len(balanced),
        'valid_rounds': count,
        'rejected': dict(rejected),
        'by_size': by_size,
        'distinct_unordered_by_size': distinct_unordered,
        'distinct_directed_by_size': distinct_directed,
        'league_codes': leagues[0],
        'league_seasons': leagues[1],
        'quick_check': qc,
    }

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--master', default='jstb_unified_master_v11.sqlite')
    ap.add_argument('--out', default='fullround_snapshot_v4.sqlite')
    args = ap.parse_args()
    report = build(args.master, args.out)
    for k,v in report.items(): print(f'{k}: {v}')
    h=hashlib.sha256(open(args.out,'rb').read()).hexdigest()
    print('sha256:',h)
