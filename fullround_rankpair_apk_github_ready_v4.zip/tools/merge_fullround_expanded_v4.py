#!/usr/bin/env python3
import argparse, os, sqlite3, hashlib

def main(snapshot_db, legacy_db, out_path):
    if os.path.exists(out_path): os.remove(out_path)
    new=sqlite3.connect(f"file:{snapshot_db}?mode=ro",uri=True)
    old=sqlite3.connect(f"file:{legacy_db}?mode=ro",uri=True)
    out=sqlite3.connect(out_path)
    out.executescript("""
CREATE TABLE round_signatures(
 round_uid TEXT PRIMARY KEY, league_code TEXT NOT NULL, season_key TEXT NOT NULL,
 table_size INTEGER NOT NULL, k_played INTEGER NOT NULL, num_games INTEGER NOT NULL,
 date_min TEXT, date_max TEXT, signature TEXT NOT NULL, result_vector TEXT, score_vector TEXT);
CREATE TABLE round_signatures_unordered(
 round_uid TEXT PRIMARY KEY, league_code TEXT NOT NULL, season_key TEXT NOT NULL,
 table_size INTEGER NOT NULL, k_played INTEGER NOT NULL, num_games INTEGER NOT NULL,
 date_min TEXT, date_max TEXT, unordered_signature TEXT NOT NULL, directed_signature TEXT NOT NULL,
 result_vector TEXT, score_vector TEXT);
""")
    out.executemany('insert into round_signatures values (?,?,?,?,?,?,?,?,?,?,?)', new.execute('select * from round_signatures'))
    out.executemany('insert into round_signatures_unordered values (?,?,?,?,?,?,?,?,?,?,?,?)', new.execute('select * from round_signatures_unordered'))
    keys=set(new.execute('select league_code,season_key,table_size,k_played from round_signatures'))
    legacy=[r for r in old.execute('select * from round_signatures') if (r[1],r[2],r[3],r[4]) not in keys]
    out.executemany('insert into round_signatures values (?,?,?,?,?,?,?,?,?,?,?)', legacy)
    ids={r[0] for r in legacy}
    out.executemany('insert into round_signatures_unordered values (?,?,?,?,?,?,?,?,?,?,?,?)', [r for r in old.execute('select * from round_signatures_unordered') if r[0] in ids])
    out.executescript("""
CREATE INDEX idx_rs_directed_k ON round_signatures(table_size,k_played,signature);
CREATE INDEX idx_rs_directed_any ON round_signatures(table_size,signature);
CREATE INDEX idx_ru_unordered_k ON round_signatures_unordered(table_size,k_played,unordered_signature);
CREATE INDEX idx_ru_unordered_any ON round_signatures_unordered(table_size,unordered_signature);
CREATE INDEX idx_rs_league_season_k ON round_signatures(league_code,season_key,k_played);
""")
    out.commit()
    qc=out.execute('pragma quick_check').fetchone()[0]
    n=out.execute('select count(*) from round_signatures').fetchone()[0]
    nu=out.execute('select count(*) from round_signatures_unordered').fetchone()[0]
    print(f'quick_check={qc}; directed={n}; unordered={nu}; legacy_added={len(legacy)}')
    out.close(); new.close(); old.close()
    h=hashlib.sha256()
    with open(out_path,'rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    print('sha256='+h.hexdigest())

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--snapshot-db', required=True)
    ap.add_argument('--legacy-db', required=True)
    ap.add_argument('--out', default='fullround_rankpair_app_v4.sqlite')
    a=ap.parse_args()
    main(a.snapshot_db,a.legacy_db,a.out)
