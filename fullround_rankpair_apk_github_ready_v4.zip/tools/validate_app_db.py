#!/usr/bin/env python3
import sqlite3
import sys

EXPECTED_TABLES = {"round_signatures", "round_signatures_unordered"}


def main(path):
    conn = sqlite3.connect(path)
    qc = conn.execute("PRAGMA quick_check").fetchone()[0]
    if qc != "ok":
        raise SystemExit(f"quick_check failed: {qc}")

    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if tables != EXPECTED_TABLES:
        raise SystemExit(f"unexpected table set: {sorted(tables)}")

    counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in EXPECTED_TABLES}
    if counts["round_signatures"] != 10260 or counts["round_signatures_unordered"] != 10260:
        raise SystemExit(f"unexpected row counts: {counts}")

    for t in EXPECTED_TABLES:
        bad = conn.execute(f"SELECT COUNT(*) FROM {t} WHERE num_games * 2 != table_size").fetchone()[0]
        if bad:
            raise SystemExit(f"{t}: {bad} incomplete rounds")

    # Ensure no excluded standalone rankpair fallback tables exist.
    forbidden = {"rankpair_counts", "rankpair_counts_by_league", "rankpair_scores"}
    if tables & forbidden:
        raise SystemExit(f"forbidden fallback tables bundled: {sorted(tables & forbidden)}")

    print(f"DB OK: quick_check={qc}; directed={counts['round_signatures']}; unordered={counts['round_signatures_unordered']}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: validate_app_db.py PATH.sqlite")
    main(sys.argv[1])
