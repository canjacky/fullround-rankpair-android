FullRound Rankpair App DB v4
File inside ZIP: fullround_rankpair_app_v4.sqlite
Contains ONLY round_signatures and round_signatures_unordered plus indexes.
Rows: 10260 directed + 10260 unordered.
Primary expansion: balanced historical DB1 snapshot freeze after K, then exact next complete round K+1.
No standalone rankpair fallback tables.
