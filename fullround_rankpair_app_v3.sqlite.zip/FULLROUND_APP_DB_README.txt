FullRound Rankpair App DB v3
Contains ONLY round_signatures and round_signatures_unordered plus indexes.
No standalone rankpair-count tables are bundled.
Rows: 2999 directed + 2999 unordered.
SHA256 sqlite: edd8614e861b77cc5b4abf802ae22a217069a27d4e2621659b4af0c4734a4129
