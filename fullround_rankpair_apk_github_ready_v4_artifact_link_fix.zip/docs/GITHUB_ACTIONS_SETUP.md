# GitHub Actions – APK-Build und Download

Der Workflow `.github/workflows/build.yml` baut die Debug-APK und lädt sie als GitHub Actions Artifact hoch.

## Workflow starten

1. Repository öffnen.
2. **Actions** → **Build Android APK**.
3. **Run workflow** → Branch `main` → **Run workflow**.
4. Den neuen Workflow-Lauf öffnen.
5. Warten, bis der Job **Build debug APK** grün ist.

## APK herunterladen

Nach erfolgreichem Lauf gibt es zwei Download-Wege:

1. Direkt in der **Run Summary** unter **APK download** auf **Download APK artifact** klicken.
2. Alternativ unten im Workflow-Lauf im Bereich **Artifacts** auf `fullround-rankpair-debug-apk` klicken.

GitHub liefert Actions Artifacts als ZIP. Darin liegen:
- `FullRound-RankPair-debug.apk`
- `FullRound-RankPair-debug.apk.sha256`

## Diagnose: Workflow grün, aber kein Download

Öffne den konkreten Workflow-Lauf und kontrolliere den letzten Schritt **Upload APK artifact**.

- Fehlt der Schritt komplett, läuft im Repository noch eine ältere `.github/workflows/build.yml`.
- Ist der Schritt rot, den Fehler im Step-Log prüfen.
- Ist der Schritt grün, muss die Run Summary den direkten Artifact-Link anzeigen.

Der Upload nutzt `if-no-files-found: error`. Ein komplett grüner Lauf kann daher nicht erfolgreich enden, wenn kein APK für den Upload vorhanden war.
