package com.gesundheit.fullround;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class SportsDbClient {
    private static final String BASE = "https://www.thesportsdb.com/api/v1/json/";
    private final Context context;
    private long lastRequestMs = 0L;

    public SportsDbClient(Context context) { this.context = context.getApplicationContext(); }

    private String apiKey() {
        SharedPreferences p = context.getSharedPreferences("research", Context.MODE_PRIVATE);
        String k = p.getString("sportsdb_key", "123");
        if (k == null || k.trim().isEmpty()) return "123";
        return k.trim();
    }

    public List<League> defaultLeagues() {
        // Stable TheSportsDB IDs. The user can add more IDs in the app without rebuilding.
        String[][] rows = new String[][]{
                {"4328","English Premier League","England"},
                {"4329","English League Championship","England"},
                {"4330","Scottish Premier League","Scotland"},
                {"4331","German Bundesliga","Germany"},
                {"4332","Italian Serie A","Italy"},
                {"4334","French Ligue 1","France"},
                {"4335","Spanish La Liga","Spain"},
                {"4338","Belgian Pro League","Belgium"},
                {"4339","Turkish Super Lig","Turkey"},
                {"4340","Danish Superliga","Denmark"},
                {"4344","Portuguese Primeira Liga","Portugal"},
                {"4346","American Major League Soccer","United States"},
                {"4347","Swedish Allsvenskan","Sweden"},
                {"4350","Mexican Primera League","Mexico"},
                {"4351","Brazilian Serie A","Brazil"},
                {"4354","Ukrainian Premier League","Ukraine"},
                {"4358","Norwegian Eliteserien","Norway"},
                {"4401","French Ligue 2","France"},
                {"4403","Swedish Superettan","Sweden"},
                {"4457","Norwegian 1. Divisjon","Norway"},
                {"4472","Welsh Premier League","Wales"},
                {"4684","American USL Championship","United States"},
                {"4802","South African Premier Soccer League","South Africa"}
        };
        List<League> out = new ArrayList<>();
        for (String[] r : rows) {
            League l = new League(); l.id=r[0]; l.name=r[1]; l.country=r[2]; l.sport="Soccer"; l.source="TheSportsDB"; out.add(l);
        }
        return out;
    }

    public League lookupLeague(String leagueId) throws Exception {
        JSONObject root = get("lookupleague.php?id=" + enc(leagueId));
        JSONArray a = root.optJSONArray("leagues");
        if (a == null || a.length() == 0) return null;
        JSONObject o = a.getJSONObject(0);
        League l = new League();
        l.id = o.optString("idLeague", leagueId);
        l.name = o.optString("strLeague", "League " + leagueId);
        l.country = o.optString("strCountry", "");
        l.sport = o.optString("strSport", "Soccer");
        l.currentSeason = nullIfEmpty(o.optString("strCurrentSeason", null));
        l.source = "TheSportsDB";
        return l;
    }

    public TableData fetchTable(League league) throws Exception {
        String suffix = "lookuptable.php?l=" + enc(league.id);
        if (league.currentSeason != null) suffix += "&s=" + enc(league.currentSeason);
        JSONObject root = get(suffix);
        JSONArray a = root.optJSONArray("table");
        TableData td = new TableData(); td.leagueId=league.id; td.leagueName=league.name; td.season=league.currentSeason;
        if (a == null) return td;
        for (int i=0;i<a.length();i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            TableRow r = new TableRow();
            r.teamId = first(o, "idTeam", "teamid", "idStanding");
            r.teamName = first(o, "strTeam", "name");
            r.rank = intFirst(o, i+1, "intRank", "rank");
            r.played = intFirst(o, 0, "intPlayed", "played");
            r.wins = intFirst(o, 0, "intWin", "wins", "win");
            r.draws = intFirst(o, 0, "intDraw", "draws", "draw");
            r.losses = intFirst(o, 0, "intLoss", "losses", "loss");
            r.goalsFor = intFirst(o, 0, "intGoalsFor", "goalsfor");
            r.goalsAgainst = intFirst(o, 0, "intGoalsAgainst", "goalsagainst");
            r.goalDiff = intFirst(o, r.goalsFor-r.goalsAgainst, "intGoalDifference", "goaldifference");
            r.points = intFirst(o, 0, "intPoints", "points");
            r.form = nullIfEmpty(first(o, "strForm", "form"));
            String season = nullIfEmpty(first(o, "strSeason", "season"));
            if (season != null) td.season = season;
            if (r.teamId != null && r.teamName != null) td.rows.add(r);
        }
        return td;
    }

    public List<Event> fetchSeasonEvents(League league, String season) throws Exception {
        if (season == null || season.trim().isEmpty()) return new ArrayList<>();
        JSONObject root = get("eventsseason.php?id=" + enc(league.id) + "&s=" + enc(season));
        return parseEvents(root.optJSONArray("events"), league);
    }

    public List<Event> fetchNextLeagueEvents(League league) throws Exception {
        JSONObject root = get("eventsnextleague.php?id=" + enc(league.id));
        return parseEvents(root.optJSONArray("events"), league);
    }

    public List<Event> fetchPastLeagueEvents(League league) throws Exception {
        JSONObject root = get("eventspastleague.php?id=" + enc(league.id));
        return parseEvents(root.optJSONArray("events"), league);
    }

    private List<Event> parseEvents(JSONArray a, League fallback) {
        List<Event> out = new ArrayList<>(); if (a == null) return out;
        for (int i=0;i<a.length();i++) {
            JSONObject o=a.optJSONObject(i); if(o==null) continue;
            Event e = new Event();
            e.id=first(o,"idEvent"); if (e.id==null) continue;
            e.leagueId=coalesce(first(o,"idLeague"), fallback.id);
            e.leagueName=coalesce(first(o,"strLeague"), fallback.name);
            e.season=coalesce(first(o,"strSeason"), fallback.currentSeason);
            e.roundNo=nullIfEmpty(first(o,"intRound","strRound"));
            e.date=nullIfEmpty(first(o,"dateEvent","strTimestamp"));
            if (e.date != null && e.date.length() > 10) e.date=e.date.substring(0,10);
            e.time=nullIfEmpty(first(o,"strTime"));
            e.homeTeamId=nullIfEmpty(first(o,"idHomeTeam")); e.awayTeamId=nullIfEmpty(first(o,"idAwayTeam"));
            e.homeTeam=nullIfEmpty(first(o,"strHomeTeam")); e.awayTeam=nullIfEmpty(first(o,"strAwayTeam"));
            e.homeScore=nullableInt(o,"intHomeScore"); e.awayScore=nullableInt(o,"intAwayScore");
            String s = nullIfEmpty(first(o,"strStatus","strPostponed"));
            e.status = s == null ? (e.homeScore!=null && e.awayScore!=null ? "FINISHED" : "SCHEDULED") : s;
            if (e.homeTeamId != null && e.awayTeamId != null) out.add(e);
        }
        return out;
    }

    private JSONObject get(String suffix) throws Exception {
        throttle();
        URL u = new URL(BASE + apiKey() + "/" + suffix);
        HttpURLConnection c = (HttpURLConnection)u.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept","application/json"); c.setRequestProperty("User-Agent","FullRound-RankPair-AutoResearch/2.0");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(in);
        c.disconnect();
        if (code == 429) throw new IllegalStateException("TheSportsDB Rate-Limit erreicht; nächster Auto-Sync versucht es erneut.");
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + " von TheSportsDB");
        if (body == null || body.trim().isEmpty()) return new JSONObject();
        return new JSONObject(body);
    }

    private synchronized void throttle() throws InterruptedException {
        long now=System.currentTimeMillis(); long wait=2100L-(now-lastRequestMs); if(wait>0) Thread.sleep(wait); lastRequestMs=System.currentTimeMillis();
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb=new StringBuilder();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while((line=br.readLine())!=null) sb.append(line);
        }
        return sb.toString();
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
    private static String first(JSONObject o, String... keys) { for(String k:keys){ if(o.has(k) && !o.isNull(k)){String s=o.optString(k,null); if(s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s)) return s.trim();}} return null; }
    private static String coalesce(String a,String b){return a==null?b:a;}
    private static String nullIfEmpty(String s){ if(s==null) return null; s=s.trim(); return s.isEmpty()||"null".equalsIgnoreCase(s)?null:s; }
    private static int intFirst(JSONObject o,int fallback,String...keys){for(String k:keys){if(o.has(k)&&!o.isNull(k)){try{return Integer.parseInt(o.optString(k));}catch(Exception ignored){}}}return fallback;}
    private static Integer nullableInt(JSONObject o,String key){if(!o.has(key)||o.isNull(key))return null;try{String s=o.optString(key,null);if(s==null||s.trim().isEmpty()||"null".equalsIgnoreCase(s))return null;return Integer.valueOf(s);}catch(Exception e){return null;}}

    public static final class League { public String id,name,country,sport,currentSeason,source; }
    public static final class TableData { public String leagueId,leagueName,season; public final List<TableRow> rows=new ArrayList<>(); }
    public static final class TableRow { public String teamId,teamName,form; public int rank,played,wins,draws,losses,goalsFor,goalsAgainst,goalDiff,points; }
    public static final class Event {
        public String id,leagueId,leagueName,season,roundNo,date,time,homeTeamId,homeTeam,awayTeamId,awayTeam,status; public Integer homeScore,awayScore;
        public String result1x2(){ if(homeScore==null||awayScore==null)return null; return homeScore>awayScore?"1":homeScore<awayScore?"2":"X"; }
    }
}
