package com.gesundheit.fullround;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class DbHelper {
    // All DbHelper instances share the same on-device database file. Dashboard,
    // manual research and JobService may start at nearly the same time, so the
    // first install/recovery must be serialized process-wide.
    private static final Object DB_OPEN_LOCK = new Object();
    private static final String ASSET_DB = "fullround_rankpair_app_v3.sqlite";
    private static final String DB_NAME = "fullround_rankpair_global_v7_1_research.sqlite";
    private static final String EXPECTED_BASE_ID = "fullround_canonical_v6_25813_20260902";
    private final Context context;
    private SQLiteDatabase db;
    private boolean validated;

    public DbHelper(Context context) { this.context=context.getApplicationContext(); }

    public SQLiteDatabase open() throws IOException {
        synchronized (DB_OPEN_LOCK) {
            if(db!=null&&db.isOpen())return db;
            File out=context.getDatabasePath(DB_NAME);
            File parent=out.getParentFile();
            if(parent!=null&&!parent.exists()&&!parent.mkdirs()&&!parent.exists())throw new IOException("Datenbankordner konnte nicht erstellt werden.");

            // V7.2: Dashboard, Initial-Research und JobService können parallel starten.
            // Installation + Recovery sind deshalb über ALLE DbHelper-Instanzen serialisiert.
            // Der stabile DB_NAME bleibt absichtlich erhalten, damit bereits gelernte
            // COMPLETE-Cases bei normalen App-Updates nicht verloren gehen.
            if(!out.exists())installFreshDatabase(out);

            try {
                db=SQLiteDatabase.openDatabase(out.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);
                validateDatabase(db);
            } catch(Exception first) {
                closeQuietly();
                deleteDatabaseFiles(out);
                installFreshDatabase(out);
                try {
                    db=SQLiteDatabase.openDatabase(out.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);
                    validated=false;
                    validateDatabase(db);
                } catch(Exception second) {
                    closeQuietly();
                    throw new IOException("SQLite-Basis konnte auch nach automatischer Neuinstallation nicht validiert werden: "+second.getMessage(),second);
                }
            }

            ResearchDb.ensureSchema(db);
            try {
                if(upgradeStaticBaseIfNeeded(db,out)) {
                    validated=false;
                    validateDatabase(db);
                    ResearchDb.cleanupExactLocalDuplicates(db);
                }
                validateCanonicalBase(db);
            } catch(Exception upgradeError) {
                // WICHTIG: Bei einem fehlgeschlagenen Basis-Upgrade die vorhandene lokale
                // Research-DB NICHT löschen. So bleiben selbst gelernte COMPLETE-Cases erhalten.
                closeQuietly();
                throw new IOException("Kanonisches Basis-Upgrade fehlgeschlagen; lokale Research-Daten wurden nicht gelöscht: "+upgradeError.getMessage(),upgradeError);
            }
            return db;
        }
    }


    private boolean upgradeStaticBaseIfNeeded(SQLiteDatabase current,File destination)throws IOException {
        String installedId=readBuildMeta(current,"canonical_base_id");
        if(EXPECTED_BASE_ID.equals(installedId))return false;

        File fresh=new File(destination.getAbsolutePath()+".baseupgrade");
        if(fresh.exists()&&!fresh.delete())throw new IOException("Alte Basis-Upgrade-Datei konnte nicht entfernt werden.");
        copyAsset(ASSET_DB,fresh);
        if(fresh.length()<128L*1024L)throw new IOException("Neue kanonische Basis ist unerwartet klein: "+fresh.length()+" Bytes.");

        SQLiteDatabase probe=null;
        boolean attached=false;
        try {
            probe=SQLiteDatabase.openDatabase(fresh.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
            requireTable(probe,"round_signatures");
            requireTable(probe,"round_signatures_unordered");
            String assetId=readBuildMeta(probe,"canonical_base_id");
            if(!EXPECTED_BASE_ID.equals(assetId))throw new IOException("Asset-Basis-ID stimmt nicht: "+assetId);
            int assetRounds=scalar(probe,"SELECT COUNT(*) FROM round_signatures");
            if(assetRounds!=25813)throw new IOException("Asset-Basis hat unerwartete Rundenzahl: "+assetRounds);
            try(Cursor c=probe.rawQuery("PRAGMA quick_check",null)){
                if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))throw new IOException("Asset-Basis quick_check fehlgeschlagen.");
            }
            probe.close();probe=null;

            String escaped=fresh.getAbsolutePath().replace("'","''");
            current.execSQL("ATTACH DATABASE '"+escaped+"' AS freshbase");
            attached=true;
            current.beginTransaction();
            try {
                // Der alte Unique-Index (Liga,Saison,K) ist für K=-1 fachlich falsch:
                // mehrere valide Mixed-K-Runden einer Saison dürfen existieren.
                current.execSQL("DROP INDEX IF EXISTS uq_rs_natural_round");
                current.execSQL("DROP INDEX IF EXISTS uq_ru_natural_round");
                current.execSQL("DELETE FROM round_audit");
                current.execSQL("DELETE FROM round_signatures");
                current.execSQL("DELETE FROM round_signatures_unordered");
                current.execSQL("DELETE FROM build_meta");
                current.execSQL("INSERT INTO round_audit(round_uid,source_type,match_fingerprint) SELECT round_uid,source_type,match_fingerprint FROM freshbase.round_audit");
                current.execSQL("INSERT INTO round_signatures(round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,signature,result_vector,score_vector) SELECT round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,signature,result_vector,score_vector FROM freshbase.round_signatures");
                current.execSQL("INSERT INTO round_signatures_unordered(round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,unordered_signature,directed_signature,result_vector,score_vector) SELECT round_uid,league_code,season_key,table_size,k_played,num_games,date_min,date_max,unordered_signature,directed_signature,result_vector,score_vector FROM freshbase.round_signatures_unordered");
                current.execSQL("INSERT INTO build_meta(key,value) SELECT key,value FROM freshbase.build_meta");
                current.setTransactionSuccessful();
            } finally { current.endTransaction(); }
        } finally {
            try{if(probe!=null&&probe.isOpen())probe.close();}catch(Exception ignored){}
            if(attached){try{current.execSQL("DETACH DATABASE freshbase");}catch(Exception ignored){}}
            if(fresh.exists())fresh.delete();
        }
        return true;
    }

    private static void validateCanonicalBase(SQLiteDatabase database)throws IOException {
        String id=readBuildMeta(database,"canonical_base_id");
        if(!EXPECTED_BASE_ID.equals(id))throw new IOException("Kanonische Basis-ID fehlt oder ist falsch: "+id);
        int n=scalar(database,"SELECT COUNT(*) FROM round_signatures");
        int u=scalar(database,"SELECT COUNT(*) FROM round_signatures_unordered");
        if(n!=25813||u!=25813)throw new IOException("Kanonische Basis unvollständig: directed="+n+", unordered="+u);
        int badKnownK=scalar(database,"SELECT COUNT(*) FROM (SELECT league_code,season_key,k_played,COUNT(*) c FROM round_signatures WHERE k_played>=0 GROUP BY league_code,season_key,k_played HAVING c>1)");
        if(badKnownK!=0)throw new IOException("Kanonische Basis enthält doppelte bekannte K-Runden: "+badKnownK);
    }

    private static String readBuildMeta(SQLiteDatabase database,String key) {
        try(Cursor c=database.rawQuery("SELECT value FROM build_meta WHERE key=?",new String[]{key})){if(c.moveToFirst())return c.getString(0);}
        catch(Exception ignored){}
        return null;
    }

    private static int scalar(SQLiteDatabase database,String sql) {
        try(Cursor c=database.rawQuery(sql,null)){return c.moveToFirst()?c.getInt(0):0;}
    }

    private void installFreshDatabase(File destination)throws IOException {
        File tmp=new File(destination.getAbsolutePath()+".installing");
        if(tmp.exists()&&!tmp.delete())throw new IOException("Temporäre DB-Datei konnte nicht entfernt werden.");
        try {
            copyAsset(ASSET_DB,tmp);
            // Header-Prüfung fängt abgeschnittene/fehlerhafte Asset-Kopien bereits vor SQLite ab.
            if(tmp.length()<128L*1024L)throw new IOException("Kopierte Basis-DB ist unerwartet klein: "+tmp.length()+" Bytes.");
            if(destination.exists()&&!destination.delete())throw new IOException("Alte DB-Datei konnte nicht ersetzt werden.");
            if(!tmp.renameTo(destination)) {
                copyFile(tmp,destination);
                if(!tmp.delete())tmp.deleteOnExit();
            }
        } catch(IOException e) {
            if(tmp.exists())tmp.delete();
            throw e;
        }
    }

    private void copyAsset(String assetName,File destination)throws IOException {
        try(InputStream in=context.getAssets().open(assetName);FileOutputStream out=new FileOutputStream(destination)){
            byte[]buf=new byte[1024*1024];int read;
            while((read=in.read(buf))!=-1)out.write(buf,0,read);
            out.flush();
            out.getFD().sync();
        }
    }

    private void copyFile(File source,File destination)throws IOException {
        try(InputStream in=new java.io.FileInputStream(source);FileOutputStream out=new FileOutputStream(destination)){
            byte[]buf=new byte[1024*1024];int read;
            while((read=in.read(buf))!=-1)out.write(buf,0,read);
            out.flush();out.getFD().sync();
        }
    }

    private void deleteDatabaseFiles(File base) {
        String p=base.getAbsolutePath();
        new File(p).delete();new File(p+"-wal").delete();new File(p+"-shm").delete();new File(p+"-journal").delete();new File(p+".installing").delete();
    }

    private void closeQuietly() {
        try{if(db!=null&&db.isOpen())db.close();}catch(Exception ignored){}
        db=null;validated=false;
    }

    private void validateDatabase(SQLiteDatabase database)throws IOException {
        if(validated)return;
        requireTable(database,"round_signatures");
        requireTable(database,"round_signatures_unordered");
        try(Cursor c=database.rawQuery("PRAGMA quick_check",null)){
            if(!c.moveToFirst())throw new IOException("SQLite quick_check lieferte keine Antwort.");
            String first=c.getString(0);
            if(!"ok".equalsIgnoreCase(first))throw new IOException("SQLite quick_check: "+first);
        }
        validated=true;
    }
    private void requireTable(SQLiteDatabase database,String table)throws IOException{try(Cursor c=database.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",new String[]{table})){if(!c.moveToFirst())throw new IOException("Pflichttabelle fehlt: "+table);}}

    public AnalysisResult analyze(int tableSize,int kPlayed,String signatureInput)throws Exception{if(kPlayed<0)throw new IllegalArgumentException("K darf nicht negativ sein.");return analyzeAuto(tableSize,kPlayed,signatureInput);}

    public AnalysisResult analyzeAuto(int tableSize,Integer kPlayed,String signatureInput)throws Exception{
        SQLiteDatabase database=open();String directedSignature=SignatureUtil.normalizeAndValidateDirectedSignature(signatureInput,tableSize);String unorderedSignature=SignatureUtil.toUnorderedSignature(directedSignature);List<String>targetPairs=SignatureUtil.splitPairs(directedSignature);
        AnalysisResult result=new AnalysisResult();result.tableSize=tableSize;result.kPlayed=kPlayed;result.directedSignature=directedSignature;result.unorderedSignature=unorderedSignature;
        if(kPlayed!=null&&kPlayed>=0){result.directedWithK=queryDirected(database,tableSize,kPlayed,directedSignature);result.unorderedWithK=queryUnordered(database,tableSize,kPlayed,unorderedSignature);}else{result.kUnknown=true;}
        result.directedAnyK=queryDirectedAnyK(database,tableSize,directedSignature);result.unorderedAnyK=queryUnorderedAnyK(database,tableSize,unorderedSignature);
        result.pairSummaries.put("directed_with_k",summarizePairs(targetPairs,result.directedWithK));result.pairSummaries.put("directed_any_k",summarizePairs(targetPairs,result.directedAnyK));result.pairSummaries.put("unordered_any_k_direction_checked",summarizePairs(targetPairs,result.unorderedAnyK));result.pairSummaries.put("unordered_with_k_direction_checked",summarizePairs(targetPairs,result.unorderedWithK));return result;
    }

    private List<RoundHit> queryDirected(SQLiteDatabase db,int tableSize,int kPlayed,String signature){List<RoundHit>out=queryStatic(db,"SELECT round_uid,league_code,season_key,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?",new String[]{String.valueOf(tableSize),String.valueOf(kPlayed),signature},false);out.addAll(queryLocal(db,"SELECT observation_id,league_name,season,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND k_played=? AND signature=?",new String[]{String.valueOf(tableSize),String.valueOf(kPlayed),signature},false));return out;}
    private List<RoundHit> queryDirectedAnyK(SQLiteDatabase db,int tableSize,String signature){List<RoundHit>out=queryStatic(db,"SELECT round_uid,league_code,season_key,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM round_signatures WHERE table_size=? AND signature=?",new String[]{String.valueOf(tableSize),signature},false);out.addAll(queryLocal(db,"SELECT observation_id,league_name,season,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND signature=?",new String[]{String.valueOf(tableSize),signature},false));return out;}
    private List<RoundHit> queryUnordered(SQLiteDatabase db,int tableSize,int kPlayed,String unorderedSignature){List<RoundHit>out=queryStatic(db,"SELECT round_uid,league_code,season_key,table_size,k_played,date_min,date_max,directed_signature,result_vector,score_vector FROM round_signatures_unordered WHERE table_size=? AND k_played=? AND unordered_signature=?",new String[]{String.valueOf(tableSize),String.valueOf(kPlayed),unorderedSignature},true);out.addAll(queryLocal(db,"SELECT observation_id,league_name,season,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND k_played=? AND unordered_signature=?",new String[]{String.valueOf(tableSize),String.valueOf(kPlayed),unorderedSignature},true));return out;}
    private List<RoundHit> queryUnorderedAnyK(SQLiteDatabase db,int tableSize,String unorderedSignature){List<RoundHit>out=queryStatic(db,"SELECT round_uid,league_code,season_key,table_size,k_played,date_min,date_max,directed_signature,result_vector,score_vector FROM round_signatures_unordered WHERE table_size=? AND unordered_signature=?",new String[]{String.valueOf(tableSize),unorderedSignature},true);out.addAll(queryLocal(db,"SELECT observation_id,league_name,season,table_size,k_played,date_min,date_max,signature,result_vector,score_vector FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND unordered_signature=?",new String[]{String.valueOf(tableSize),unorderedSignature},true));return out;}

    private List<RoundHit> queryStatic(SQLiteDatabase db,String sql,String[]args,boolean unordered){return queryRoundHits(db,sql,args,unordered,false);}
    private List<RoundHit> queryLocal(SQLiteDatabase db,String sql,String[]args,boolean unordered){return queryRoundHits(db,sql,args,unordered,true);}
    private List<RoundHit> queryRoundHits(SQLiteDatabase db,String sql,String[]args,boolean unorderedMode,boolean local){List<RoundHit>out=new ArrayList<>();try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext()){RoundHit h=new RoundHit();h.roundUid=c.getString(0);h.leagueCode=(local?"AUTO:":"")+safe(c.getString(1));h.seasonKey=c.getString(2);h.tableSize=c.getInt(3);h.kPlayed=c.isNull(4)?-1:c.getInt(4);h.dateMin=c.getString(5);h.dateMax=c.getString(6);h.signature=c.getString(7);h.resultVector=c.getString(8);h.scoreVector=c.getString(9);h.unorderedMode=unorderedMode;h.localResearch=local;out.add(h);}}return out;}
    private static String safe(String x){return x==null?"?":x;}

    private List<PairSummary> summarizePairs(List<String>targetPairs,List<RoundHit>hits){Map<String,PairSummary>map=new LinkedHashMap<>();for(String p:targetPairs)map.put(p,new PairSummary(p));for(RoundHit hit:hits){Map<String,String>resultsByPair=SignatureUtil.parseResultVector(hit.resultVector);for(String p:targetPairs){String r=resultsByPair.get(p);if(r==null)continue;PairSummary s=map.get(p);s.n++;if("1".equals(r))s.one++;else if("X".equalsIgnoreCase(r))s.draw++;else if("2".equals(r))s.two++;}}return new ArrayList<>(map.values());}

    public static final class RoundHit{public String roundUid,leagueCode,seasonKey,dateMin,dateMax,signature,resultVector,scoreVector;public int tableSize,kPlayed;public boolean unorderedMode,localResearch;}
    public static final class PairSummary{public final String pair;public int n,one,draw,two;public PairSummary(String pair){this.pair=pair;}public int resultTypes(){int t=0;if(one>0)t++;if(draw>0)t++;if(two>0)t++;return t;}public String market(){boolean h=one>0,x=draw>0,a=two>0;if(resultTypes()==0)return"NO_SIGNAL";if(resultTypes()==3)return"RAUS: 1/X/2";String base;if(h&&x&&!a)base="1X";else if(!h&&x&&a)base="X2";else if(h&&!x&&a)base="12";else if(h)base="1 / 1X";else if(x)base="X only, vorsichtig";else base="2 / X2";if(n==1)base+=", Low-N";return base;}public boolean candidate(){return n>0&&resultTypes()<=2;}}
    public static final class AnalysisResult{public int tableSize;public Integer kPlayed;public boolean kUnknown;public String directedSignature,unorderedSignature;public List<RoundHit>directedWithK=new ArrayList<>(),directedAnyK=new ArrayList<>(),unorderedWithK=new ArrayList<>(),unorderedAnyK=new ArrayList<>();public Map<String,List<PairSummary>>pairSummaries=new HashMap<>();}
}
