package com.gesundheit.fullround;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class FootballDataClient {
    private static final String BASE="https://api.football-data.org/v4/";
    private final Context context;
    private long lastRequestMs=0L;
    public FootballDataClient(Context c){context=c.getApplicationContext();}
    public boolean enabled(){return token()!=null;}
    private String token(){SharedPreferences p=context.getSharedPreferences("research",Context.MODE_PRIVATE);String t=p.getString("football_data_token","");return t==null||t.trim().isEmpty()?null:t.trim();}

    public List<SportsDbClient.League> listCompetitions() throws Exception {
        JSONObject root=get("competitions");JSONArray a=root.optJSONArray("competitions");List<SportsDbClient.League>out=new ArrayList<>();if(a==null)return out;
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String type=o.optString("type","");if(!"LEAGUE".equalsIgnoreCase(type))continue;SportsDbClient.League l=new SportsDbClient.League();l.id="fd:"+o.optInt("id");l.name=o.optString("name","League "+l.id);JSONObject area=o.optJSONObject("area");l.country=area==null?"":area.optString("name","");l.sport="Soccer";l.source="football-data.org";JSONObject cs=o.optJSONObject("currentSeason");if(cs!=null){String start=cs.optString("startDate","");if(start.length()>=4)l.currentSeason=start.substring(0,4);}out.add(l);}return out;
    }

    public SportsDbClient.TableData fetchTable(SportsDbClient.League league)throws Exception{
        String id=strip(league.id);JSONObject root=get("competitions/"+id+"/standings");SportsDbClient.TableData td=new SportsDbClient.TableData();td.leagueId=league.id;td.leagueName=league.name;td.season=league.currentSeason;
        JSONObject season=root.optJSONObject("season");if(season!=null){String start=season.optString("startDate","");if(start.length()>=4)td.season=start.substring(0,4);}
        JSONArray standings=root.optJSONArray("standings");if(standings==null)return td;JSONArray table=null;for(int i=0;i<standings.length();i++){JSONObject s=standings.optJSONObject(i);if(s!=null&&"TOTAL".equalsIgnoreCase(s.optString("type"))){table=s.optJSONArray("table");break;}}if(table==null&&standings.length()>0)table=standings.optJSONObject(0).optJSONArray("table");if(table==null)return td;
        for(int i=0;i<table.length();i++){JSONObject o=table.optJSONObject(i);if(o==null)continue;SportsDbClient.TableRow r=new SportsDbClient.TableRow();JSONObject team=o.optJSONObject("team");if(team==null)continue;r.teamId="fdteam:"+team.optInt("id");r.teamName=team.optString("name",team.optString("shortName","?"));r.rank=o.optInt("position",i+1);r.played=o.optInt("playedGames",0);r.wins=o.optInt("won",0);r.draws=o.optInt("draw",0);r.losses=o.optInt("lost",0);r.points=o.optInt("points",0);r.goalsFor=o.optInt("goalsFor",0);r.goalsAgainst=o.optInt("goalsAgainst",0);r.goalDiff=o.optInt("goalDifference",r.goalsFor-r.goalsAgainst);r.form=o.optString("form",null);td.rows.add(r);}return td;
    }

    public List<SportsDbClient.Event> fetchMatches(SportsDbClient.League league)throws Exception{
        JSONObject root=get("competitions/"+strip(league.id)+"/matches");JSONArray a=root.optJSONArray("matches");List<SportsDbClient.Event>out=new ArrayList<>();if(a==null)return out;
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;SportsDbClient.Event e=new SportsDbClient.Event();e.id="fdmatch:"+o.optInt("id");e.leagueId=league.id;e.leagueName=league.name;JSONObject season=o.optJSONObject("season");if(season!=null){String start=season.optString("startDate","");e.season=start.length()>=4?start.substring(0,4):league.currentSeason;}else e.season=league.currentSeason;e.roundNo=o.has("matchday")&&!o.isNull("matchday")?String.valueOf(o.optInt("matchday")):null;String utc=o.optString("utcDate","");e.date=utc.length()>=10?utc.substring(0,10):null;e.time=utc.length()>=16?utc.substring(11,16):null;JSONObject h=o.optJSONObject("homeTeam"),aw=o.optJSONObject("awayTeam");if(h==null||aw==null)continue;e.homeTeamId="fdteam:"+h.optInt("id");e.homeTeam=h.optString("name","?");e.awayTeamId="fdteam:"+aw.optInt("id");e.awayTeam=aw.optString("name","?");e.status=o.optString("status","SCHEDULED");JSONObject score=o.optJSONObject("score");if(score!=null){JSONObject ft=score.optJSONObject("fullTime");if(ft!=null){if(ft.has("home")&&!ft.isNull("home"))e.homeScore=ft.optInt("home");if(ft.has("away")&&!ft.isNull("away"))e.awayScore=ft.optInt("away");}}out.add(e);}return out;
    }

    private JSONObject get(String path)throws Exception{throttle();String t=token();if(t==null)throw new IllegalStateException("football-data.org Token fehlt");HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestMethod("GET");c.setRequestProperty("Accept","application/json");c.setRequestProperty("X-Auth-Token",t);c.setRequestProperty("User-Agent","FullRound-RankPair-AutoResearch/2.0");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String body=readAll(in);c.disconnect();if(code==429)throw new IllegalStateException("football-data.org Rate-Limit erreicht");if(code<200||code>=300)throw new IllegalStateException("football-data.org HTTP "+code+(body.isEmpty()?"":" – "+body));return body.isEmpty()?new JSONObject():new JSONObject(body);}
    private synchronized void throttle()throws InterruptedException{long now=System.currentTimeMillis();long wait=6200L-(now-lastRequestMs);if(wait>0)Thread.sleep(wait);lastRequestMs=System.currentTimeMillis();}
    private static String strip(String id){return id!=null&&id.startsWith("fd:")?id.substring(3):id;}
    private static String readAll(InputStream in)throws Exception{if(in==null)return"";StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}return sb.toString();}
}
