package com.gesundheit.fullround;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class ResearchJobService extends JobService {
    @Override public boolean onStartJob(final JobParameters params) {
        new Thread(() -> {
            try { new ResearchEngine(getApplicationContext()).runFullSync(null); }
            catch (Exception ignored) {}
            finally { jobFinished(params, false); }
        }, "fullround-auto-research").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }
}
