package com.gesundheit.fullround;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SignatureUtil {
    private static final Pattern PAIR_PATTERN = Pattern.compile("^(\\d+)\\s*(?:->|→|=>|-)\\s*(\\d+)$");

    private SignatureUtil() {}

    /**
     * Parses rank pairs while preserving the user's input order.
     * Home/Away is never swapped.
     */
    public static List<String> normalizedPairsPreserveOrder(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Full-Round-Signatur fehlt.");
        }

        String normalized = raw
                .replace(";", "|")
                .replace(",", "|")
                .replace("\r", "|")
                .replace("\n", "|");

        String[] parts = normalized.split("\\|");
        List<String> pairs = new ArrayList<>();
        for (String part : parts) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            Matcher m = PAIR_PATTERN.matcher(p);
            if (!m.matches()) {
                throw new IllegalArgumentException("Ungültiges Rangpaar: '" + p + "'. Erwartet z. B. 2->6.");
            }
            int home = Integer.parseInt(m.group(1));
            int away = Integer.parseInt(m.group(2));
            pairs.add(home + "->" + away);
        }
        if (pairs.isEmpty()) {
            throw new IllegalArgumentException("Keine Rangpaare erkannt.");
        }
        return pairs;
    }

    /**
     * Canonical directed Full-Round signature used by the historical DB.
     * The list is sorted by HOME rank (then away rank), but direction is preserved.
     */
    public static String normalizeAndValidateDirectedSignature(String raw, int tableSize) {
        if (tableSize < 2 || tableSize % 2 != 0) {
            throw new IllegalArgumentException("Teamzahl muss eine gerade Zahl >= 2 sein.");
        }

        List<String> pairs = normalizedPairsPreserveOrder(raw);
        int expectedGames = tableSize / 2;
        if (pairs.size() != expectedGames) {
            throw new IllegalArgumentException(
                    "Unvollständige Full-Round: erwartet " + expectedGames +
                    " Spiele für " + tableSize + " Teams, erkannt " + pairs.size() + ".");
        }

        Set<Integer> seenRanks = new HashSet<>();
        for (String pair : pairs) {
            int[] ab = directedNums(pair);
            int home = ab[0];
            int away = ab[1];
            if (home < 1 || home > tableSize || away < 1 || away > tableSize) {
                throw new IllegalArgumentException(
                        "Rang außerhalb 1.." + tableSize + ": " + pair + ".");
            }
            if (home == away) {
                throw new IllegalArgumentException("Heim- und Auswärtsrang dürfen nicht identisch sein: " + pair + ".");
            }
            if (!seenRanks.add(home)) {
                throw new IllegalArgumentException("Rang " + home + " kommt mehrfach in der Runde vor.");
            }
            if (!seenRanks.add(away)) {
                throw new IllegalArgumentException("Rang " + away + " kommt mehrfach in der Runde vor.");
            }
        }

        if (seenRanks.size() != tableSize) {
            throw new IllegalArgumentException(
                    "Full-Round ungültig: jeder Rang 1.." + tableSize + " muss genau einmal vorkommen.");
        }
        for (int rank = 1; rank <= tableSize; rank++) {
            if (!seenRanks.contains(rank)) {
                throw new IllegalArgumentException("Full-Round ungültig: Rang " + rank + " fehlt.");
            }
        }

        Collections.sort(pairs, new Comparator<String>() {
            @Override
            public int compare(String x, String y) {
                int[] ax = directedNums(x);
                int[] ay = directedNums(y);
                if (ax[0] != ay[0]) return Integer.compare(ax[0], ay[0]);
                return Integer.compare(ax[1], ay[1]);
            }
        });
        return String.join("|", pairs);
    }

    /** Compatibility helper for code that only needs canonical parsing. */
    public static String normalizeDirectedSignature(String raw) {
        List<String> pairs = normalizedPairsPreserveOrder(raw);
        Collections.sort(pairs, new Comparator<String>() {
            @Override
            public int compare(String x, String y) {
                int[] ax = directedNums(x);
                int[] ay = directedNums(y);
                if (ax[0] != ay[0]) return Integer.compare(ax[0], ay[0]);
                return Integer.compare(ax[1], ay[1]);
            }
        });
        return String.join("|", pairs);
    }

    public static List<String> splitPairs(String directedSignature) {
        List<String> out = new ArrayList<>();
        if (directedSignature == null || directedSignature.trim().isEmpty()) return out;
        String[] parts = directedSignature.split("\\|");
        for (String p : parts) {
            String q = p.trim();
            if (!q.isEmpty()) out.add(q);
        }
        return out;
    }

    public static String toUnorderedSignature(String directedSignature) {
        List<String> unordered = new ArrayList<>();
        for (String pair : splitPairs(directedSignature)) {
            int[] ab = directedNums(pair);
            int low = Math.min(ab[0], ab[1]);
            int high = Math.max(ab[0], ab[1]);
            unordered.add(low + "-" + high);
        }
        Collections.sort(unordered, new Comparator<String>() {
            @Override
            public int compare(String x, String y) {
                int[] ax = unorderedNums(x);
                int[] ay = unorderedNums(y);
                if (ax[0] != ay[0]) return Integer.compare(ax[0], ay[0]);
                return Integer.compare(ax[1], ay[1]);
            }
        });
        return String.join("|", unordered);
    }

    private static int[] directedNums(String s) {
        String[] p = s.split("->");
        if (p.length != 2) throw new IllegalArgumentException("Ungültiges gerichtetes Rangpaar: " + s);
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
    }

    private static int[] unorderedNums(String s) {
        String[] p = s.split("-");
        if (p.length != 2) throw new IllegalArgumentException("Ungültiges ungeordnetes Rangpaar: " + s);
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
    }

    public static Map<String, String> parseResultVector(String resultVector) {
        Map<String, String> out = new LinkedHashMap<>();
        if (resultVector == null) return out;
        String[] items = resultVector.split("\\|");
        for (String item : items) {
            String[] kv = item.split(":", 2);
            if (kv.length == 2) out.put(kv[0].trim(), kv[1].trim());
        }
        return out;
    }
}
