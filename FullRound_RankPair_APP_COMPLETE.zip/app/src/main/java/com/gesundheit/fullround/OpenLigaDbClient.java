package com.gesundheit.fullround;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/**
 * No-key supplemental provider. OpenLigaDB is community maintained, so every
 * imported season still has to pass the Full-Round completeness checks before
 * it can become a comparison case.
 */
public final class OpenLigaDbClient {
    private static final String BASE="https://api.openligadb.de/";
    private long lastRequestMs=0L;

    public List<SportsDbClient.League> fetchAvailableSoccerLeaguesForSeason(int season) throws Exception {
        JSONArray a=getArray("getavailableleagues/"+season);
        LinkedHashMap<String,SportsDbClient.League> out=new LinkedHashMap<>();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            JSONObject sport=o.optJSONObject("sport");
            String sportName=first(sport,"sportName","name");
            if(!isSoccer(sportName))continue;
            String leagueId=first(o,"leagueId","id");
            String shortcut=first(o,"leagueShortcut","shortcut");
            String leagueSeason=first(o,"leagueSeason","season");
            if(leagueId==null||shortcut==null)continue;
            SportsDbClient.League l=new SportsDbClient.League();
            l.id="olg:"+leagueId;
            l.providerKey=shortcut;
            l.name=coalesce(first(o,"leagueName","name"),"OpenLigaDB "+shortcut+" "+season);
            l.country="OpenLigaDB";
            l.sport="Soccer";
            l.currentSeason=leagueSeason==null?String.valueOf(season):leagueSeason;
            l.source="OpenLigaDB";
            out.put(l.id,l);
        }
        return new ArrayList<>(out.values());
    }

    /** Fetches the currently selected matchday for a shortcut and keeps only the expected season-specific league id. */
    public List<SportsDbClient.Event> fetchCurrentRoundMatches(SportsDbClient.League league) throws Exception {
        if(league.providerKey==null||league.providerKey.trim().isEmpty())return new ArrayList<>();
        JSONArray a=getArray("getmatchdata/"+encPath(league.providerKey));
        return parseMatches(a,league,true);
    }

    public List<SportsDbClient.Event> fetchSeasonMatches(SportsDbClient.League league,String season) throws Exception {
        if(league.providerKey==null||league.providerKey.trim().isEmpty())return new ArrayList<>();
        JSONArray a=getArray("getmatchdata/"+encPath(league.providerKey)+"/"+encPath(season));
        return parseMatches(a,league,false);
    }

    public SportsDbClient.TableData fetchTable(SportsDbClient.League league) throws Exception {
        SportsDbClient.TableData td=new SportsDbClient.TableData();td.leagueId=league.id;td.leagueName=league.name;td.season=league.currentSeason;
        if(league.providerKey==null||league.currentSeason==null)return td;
        JSONArray a;
        try { a=getArray("getbltable/"+encPath(league.providerKey)+"/"+encPath(league.currentSeason)); }
        catch(Exception first){ a=getArray("getgrouptable/"+encPath(league.providerKey)+"/"+encPath(league.currentSeason)); }
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            SportsDbClient.TableRow r=new SportsDbClient.TableRow();
            String teamId=first(o,"teamInfoId","TeamInfoId","teamId","TeamId");
            if(teamId==null)continue;
            r.teamId="olgteam:"+teamId;
            r.teamName=coalesce(first(o,"teamName","TeamName","name"),r.teamId);
            r.rank=i+1;
            r.played=intFirst(o,0,"matches","Matches","played","Played");
            r.wins=intFirst(o,0,"won","Won","wins","Wins");
            r.draws=intFirst(o,0,"draw","Draw","draws","Draws");
            r.losses=intFirst(o,0,"lost","Lost","losses","Losses");
            r.goalsFor=intFirst(o,0,"goals","Goals","goalsFor","GoalsFor");
            r.goalsAgainst=intFirst(o,0,"opponentGoals","OpponentGoals","goalsAgainst","GoalsAgainst");
            r.goalDiff=intFirst(o,r.goalsFor-r.goalsAgainst,"goalDiff","GoalDiff");
            r.points=intFirst(o,0,"points","Points");
            td.rows.add(r);
        }
        return td;
    }

    private List<SportsDbClient.Event> parseMatches(JSONArray a,SportsDbClient.League fallback,boolean enforceLeagueId){
        List<SportsDbClient.Event>out=new ArrayList<>();if(a==null)return out;
        String expectedNumeric=fallback.id!=null&&fallback.id.startsWith("olg:")?fallback.id.substring(4):null;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            String numericLeague=first(o,"leagueId","LeagueId");
            if(enforceLeagueId&&expectedNumeric!=null&&numericLeague!=null&&!expectedNumeric.equals(numericLeague))continue;
            SportsDbClient.Event e=new SportsDbClient.Event();
            String mid=first(o,"matchID","matchId","MatchID");if(mid==null)continue;
            e.id="olgmatch:"+mid;
            e.leagueId=fallback.id;
            e.leagueName=coalesce(first(o,"leagueName","LeagueName"),fallback.name);
            e.country=fallback.country;
            e.season=coalesce(first(o,"leagueSeason","LeagueSeason"),fallback.currentSeason);
            JSONObject group=o.optJSONObject("group");
            e.roundNo=first(group,"groupOrderID","groupOrderId","GroupOrderID");
            if(e.roundNo==null)e.roundNo=first(o,"groupOrderID","groupOrderId");
            String dt=first(o,"matchDateTimeUTC","matchDateTime","MatchDateTime");
            if(dt!=null){e.date=dt.length()>=10?dt.substring(0,10):dt;e.time=dt.length()>=16?dt.substring(11,16):null;}
            JSONObject h=o.optJSONObject("team1"),aw=o.optJSONObject("team2");if(h==null||aw==null)continue;
            String hid=first(h,"teamId","teamID","TeamId"),aid=first(aw,"teamId","teamID","TeamId");if(hid==null||aid==null)continue;
            e.homeTeamId="olgteam:"+hid;e.awayTeamId="olgteam:"+aid;
            e.homeTeam=coalesce(first(h,"teamName","TeamName","shortName"),e.homeTeamId);
            e.awayTeam=coalesce(first(aw,"teamName","TeamName","shortName"),e.awayTeamId);
            boolean finished=boolFirst(o,false,"matchIsFinished","MatchIsFinished","isFinished");
            int[]score=fullTimeScore(o.optJSONArray("matchResults"));
            if(score!=null){e.homeScore=score[0];e.awayScore=score[1];}
            e.status=(finished||score!=null)?"FINISHED":"SCHEDULED";
            out.add(e);
        }
        return out;
    }

    private static int[] fullTimeScore(JSONArray a){
        if(a==null)return null;JSONObject best=null;int bestOrder=Integer.MIN_VALUE;
        for(int i=0;i<a.length();i++){
            JSONObject r=a.optJSONObject(i);if(r==null)continue;
            int type=intFirst(r,-1,"resultTypeID","resultTypeId","ResultTypeID");
            int order=intFirst(r,i,"resultOrderID","resultOrderId","ResultOrderID");
            if(type==2){best=r;break;}if(order>=bestOrder){bestOrder=order;best=r;}
        }
        if(best==null)return null;
        Integer h=nullableInt(best,"pointsTeam1","PointsTeam1"),g=nullableInt(best,"pointsTeam2","PointsTeam2");
        if(h==null||g==null)return null;return new int[]{h,g};
    }

    private JSONArray getArray(String path)throws Exception{
        throttle();HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestMethod("GET");c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","FullRound-GlobalResearch/3.1");
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String body=readAll(in);c.disconnect();
        if(code==429)throw new IllegalStateException("OpenLigaDB Rate-Limit erreicht; nächster Auto-Sync versucht es erneut.");
        if(code<200||code>=300)throw new IllegalStateException("OpenLigaDB HTTP "+code);
        if(body==null||body.trim().isEmpty())return new JSONArray();
        String t=body.trim();if(t.startsWith("["))return new JSONArray(t);
        JSONObject root=new JSONObject(t);for(String key:new String[]{"matches","leagues","table","data"}){JSONArray a=root.optJSONArray(key);if(a!=null)return a;}return new JSONArray();
    }

    private synchronized void throttle()throws InterruptedException{long interval=350L;long now=System.currentTimeMillis();long wait=interval-(now-lastRequestMs);if(wait>0)Thread.sleep(wait);lastRequestMs=System.currentTimeMillis();}
    private static boolean isSoccer(String s){if(s==null)return false;String n=s.toLowerCase(Locale.ROOT);return n.contains("fußball")||n.contains("fussball")||n.contains("football")||n.contains("soccer");}
    private static String encPath(String s)throws Exception{return URLEncoder.encode(s==null?"":s,"UTF-8").replace("+","%20");}
    private static String readAll(InputStream in)throws Exception{if(in==null)return"";StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}return sb.toString();}
    private static String first(JSONObject o,String...keys){if(o==null)return null;for(String k:keys){if(o.has(k)&&!o.isNull(k)){String s=o.optString(k,null);if(s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s))return s.trim();}}return null;}
    private static String coalesce(String a,String b){return a==null?b:a;}
    private static int intFirst(JSONObject o,int fallback,String...keys){if(o==null)return fallback;for(String k:keys){if(o.has(k)&&!o.isNull(k)){try{return Integer.parseInt(o.optString(k));}catch(Exception ignored){}}}return fallback;}
    private static Integer nullableInt(JSONObject o,String...keys){if(o==null)return null;for(String k:keys){if(o.has(k)&&!o.isNull(k)){try{return Integer.valueOf(o.optString(k));}catch(Exception ignored){}}}return null;}
    private static boolean boolFirst(JSONObject o,boolean fallback,String...keys){if(o==null)return fallback;for(String k:keys){if(o.has(k)&&!o.isNull(k)){Object v=o.opt(k);if(v instanceof Boolean)return (Boolean)v;String s=String.valueOf(v);if("true".equalsIgnoreCase(s)||"1".equals(s))return true;if("false".equalsIgnoreCase(s)||"0".equals(s))return false;}}return fallback;}
}
