package com.gesundheit.fullround;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ResearchDb {
    private ResearchDb() {}

    public static void ensureSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS research_meta (key TEXT PRIMARY KEY, value TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_leagues (" +
                "league_id TEXT PRIMARY KEY, league_name TEXT, country TEXT, sport TEXT, source TEXT NOT NULL, " +
                "season TEXT, table_size INTEGER, discovered_at TEXT, last_sync_at TEXT, last_error TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_teams (" +
                "team_id TEXT PRIMARY KEY, team_name TEXT NOT NULL, league_id TEXT, source TEXT NOT NULL, updated_at TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_fixtures (" +
                "event_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, event_date TEXT, event_time TEXT, " +
                "home_team_id TEXT, home_team TEXT, away_team_id TEXT, away_team TEXT, home_score INTEGER, away_score INTEGER, " +
                "status TEXT, result_1x2 TEXT, source TEXT NOT NULL, fetched_at TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_fixtures_league_round ON research_fixtures(league_id, season, round_no)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_fixtures_date ON research_fixtures(event_date)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_table_snapshots (" +
                "snapshot_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, captured_at TEXT NOT NULL, table_size INTEGER NOT NULL, source TEXT NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_snapshots_league ON research_table_snapshots(league_id, captured_at)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_table_rows (" +
                "snapshot_id TEXT NOT NULL, team_id TEXT NOT NULL, team_name TEXT NOT NULL, rank INTEGER, played INTEGER, wins INTEGER, draws INTEGER, losses INTEGER, " +
                "goals_for INTEGER, goals_against INTEGER, goal_diff INTEGER, points INTEGER, form TEXT, PRIMARY KEY(snapshot_id, team_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS local_round_observations (" +
                "observation_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, table_size INTEGER NOT NULL, k_played INTEGER, " +
                "date_min TEXT, date_max TEXT, signature TEXT NOT NULL, unordered_signature TEXT NOT NULL, result_vector TEXT, score_vector TEXT, " +
                "state TEXT NOT NULL, source TEXT NOT NULL, prematch_snapshot_id TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_local_round_signature ON local_round_observations(table_size, signature, state)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_local_round_unordered ON local_round_observations(table_size, unordered_signature, state)");
        db.execSQL("CREATE TABLE IF NOT EXISTS local_round_games (" +
                "observation_id TEXT NOT NULL, event_id TEXT NOT NULL, home_team_id TEXT, away_team_id TEXT, home_rank INTEGER NOT NULL, away_rank INTEGER NOT NULL, " +
                "PRIMARY KEY(observation_id, event_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_comparisons (" +
                "observation_id TEXT PRIMARY KEY, generated_at TEXT NOT NULL, directed_with_k_n INTEGER, directed_any_k_n INTEGER, unordered_any_k_n INTEGER, " +
                "summary TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_sync_log (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL, leagues_discovered INTEGER DEFAULT 0, " +
                "leagues_synced INTEGER DEFAULT 0, fixtures_upserted INTEGER DEFAULT 0, snapshots_added INTEGER DEFAULT 0, observations_added INTEGER DEFAULT 0, " +
                "observations_completed INTEGER DEFAULT 0, message TEXT)");
    }

    public static void upsertLeague(SQLiteDatabase db, SportsDbClient.League league, String now) {
        ContentValues v = new ContentValues();
        v.put("league_id", league.id);
        v.put("league_name", league.name);
        v.put("country", league.country);
        v.put("sport", league.sport);
        v.put("source", league.source == null ? "TheSportsDB" : league.source);
        v.put("discovered_at", now);
        db.insertWithOnConflict("research_leagues", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        ContentValues u = new ContentValues();
        u.put("league_name", league.name);
        u.put("country", league.country);
        u.put("sport", league.sport);
        db.update("research_leagues", u, "league_id=?", new String[]{league.id});
    }

    public static List<SportsDbClient.League> leaguesNeedingSync(SQLiteDatabase db, int limit) {
        List<SportsDbClient.League> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT league_id, league_name, country, sport, source FROM research_leagues " +
                "WHERE sport='Soccer' ORDER BY CASE WHEN last_sync_at IS NULL THEN 0 ELSE 1 END, last_sync_at ASC LIMIT ?",
                new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) {
                SportsDbClient.League l = new SportsDbClient.League();
                l.id = c.getString(0); l.name = c.getString(1); l.country = c.getString(2); l.sport = c.getString(3); l.source = c.getString(4);
                out.add(l);
            }
        }
        return out;
    }

    public static List<SportsDbClient.League> leaguesNeedingSync(SQLiteDatabase db, String source, int limit) {
        List<SportsDbClient.League> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT league_id, league_name, country, sport, source FROM research_leagues " +
                "WHERE sport='Soccer' AND source=? ORDER BY CASE WHEN last_sync_at IS NULL THEN 0 ELSE 1 END, last_sync_at ASC LIMIT ?",
                new String[]{source, String.valueOf(limit)})) {
            while (c.moveToNext()) {
                SportsDbClient.League l = new SportsDbClient.League();
                l.id = c.getString(0); l.name = c.getString(1); l.country = c.getString(2); l.sport = c.getString(3); l.source = c.getString(4);
                out.add(l);
            }
        }
        return out;
    }

    public static void markLeagueSynced(SQLiteDatabase db, String leagueId, String season, int tableSize, String now, String error) {
        ContentValues v = new ContentValues();
        v.put("last_sync_at", now);
        if (season != null) v.put("season", season);
        if (tableSize > 0) v.put("table_size", tableSize);
        if (error == null) v.putNull("last_error"); else v.put("last_error", error);
        db.update("research_leagues", v, "league_id=?", new String[]{leagueId});
    }

    public static int upsertFixtures(SQLiteDatabase db, List<SportsDbClient.Event> events, String now) {
        int n = 0;
        for (SportsDbClient.Event e : events) {
            ContentValues v = new ContentValues();
            v.put("event_id", e.id); v.put("league_id", e.leagueId); v.put("league_name", e.leagueName); v.put("season", e.season);
            v.put("round_no", e.roundNo); v.put("event_date", e.date); v.put("event_time", e.time);
            v.put("home_team_id", e.homeTeamId); v.put("home_team", e.homeTeam); v.put("away_team_id", e.awayTeamId); v.put("away_team", e.awayTeam);
            if (e.homeScore == null) v.putNull("home_score"); else v.put("home_score", e.homeScore);
            if (e.awayScore == null) v.putNull("away_score"); else v.put("away_score", e.awayScore);
            v.put("status", e.status); v.put("result_1x2", e.result1x2()); v.put("source", sourceForId(e.leagueId)); v.put("fetched_at", now);
            db.insertWithOnConflict("research_fixtures", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            n++;
        }
        return n;
    }

    public static String saveStandingSnapshot(SQLiteDatabase db, SportsDbClient.TableData table, String now) {
        if (table.rows.isEmpty()) return null;
        String snapshotId = table.leagueId + "|" + (table.season == null ? "?" : table.season) + "|" + now;
        db.beginTransaction();
        try {
            ContentValues s = new ContentValues();
            s.put("snapshot_id", snapshotId); s.put("league_id", table.leagueId); s.put("league_name", table.leagueName);
            s.put("season", table.season); s.put("captured_at", now); s.put("table_size", table.rows.size()); s.put("source", sourceForId(table.leagueId));
            db.insertOrThrow("research_table_snapshots", null, s);
            for (SportsDbClient.TableRow r : table.rows) {
                ContentValues v = new ContentValues();
                v.put("snapshot_id", snapshotId); v.put("team_id", r.teamId); v.put("team_name", r.teamName); v.put("rank", r.rank);
                v.put("played", r.played); v.put("wins", r.wins); v.put("draws", r.draws); v.put("losses", r.losses); v.put("goals_for", r.goalsFor);
                v.put("goals_against", r.goalsAgainst); v.put("goal_diff", r.goalDiff); v.put("points", r.points); v.put("form", r.form);
                db.insertOrThrow("research_table_rows", null, v);
                ContentValues t = new ContentValues();
                t.put("team_id", r.teamId); t.put("team_name", r.teamName); t.put("league_id", table.leagueId); t.put("source", sourceForId(table.leagueId)); t.put("updated_at", now);
                db.insertWithOnConflict("research_teams", null, t, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return snapshotId;
    }

    public static Map<String, Integer> rankMap(SQLiteDatabase db, String snapshotId) {
        Map<String, Integer> out = new LinkedHashMap<>();
        try (Cursor c = db.rawQuery("SELECT team_id, rank FROM research_table_rows WHERE snapshot_id=?", new String[]{snapshotId})) {
            while (c.moveToNext()) out.put(c.getString(0), c.getInt(1));
        }
        return out;
    }

    public static Integer uniformPlayed(SQLiteDatabase db, String snapshotId) {
        try (Cursor c = db.rawQuery("SELECT MIN(played), MAX(played) FROM research_table_rows WHERE snapshot_id=?", new String[]{snapshotId})) {
            if (c.moveToFirst() && !c.isNull(0) && c.getInt(0) == c.getInt(1)) return c.getInt(0);
        }
        return null;
    }

    public static long startSync(SQLiteDatabase db, String now) {
        ContentValues v = new ContentValues(); v.put("started_at", now); v.put("status", "RUNNING");
        return db.insert("research_sync_log", null, v);
    }

    public static void finishSync(SQLiteDatabase db, long id, String now, String status, ResearchEngine.SyncStats st, String message) {
        ContentValues v = new ContentValues(); v.put("finished_at", now); v.put("status", status); v.put("leagues_discovered", st.leaguesDiscovered);
        v.put("leagues_synced", st.leaguesSynced); v.put("fixtures_upserted", st.fixturesUpserted); v.put("snapshots_added", st.snapshotsAdded);
        v.put("observations_added", st.observationsAdded); v.put("observations_completed", st.observationsCompleted); v.put("message", message);
        db.update("research_sync_log", v, "id=?", new String[]{String.valueOf(id)});
    }

    public static String getMeta(SQLiteDatabase db, String key, String fallback) {
        try (Cursor c = db.rawQuery("SELECT value FROM research_meta WHERE key=?", new String[]{key})) {
            if (c.moveToFirst()) return c.getString(0);
        }
        return fallback;
    }

    public static void putMeta(SQLiteDatabase db, String key, String value) {
        ContentValues v = new ContentValues(); v.put("key", key); v.put("value", value);
        db.insertWithOnConflict("research_meta", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public static DashboardStats dashboard(SQLiteDatabase db) {
        DashboardStats d = new DashboardStats();
        d.historicalRounds = scalar(db, "SELECT COUNT(*) FROM round_signatures");
        d.leagues = scalar(db, "SELECT COUNT(*) FROM research_leagues");
        d.fixtures = scalar(db, "SELECT COUNT(*) FROM research_fixtures");
        d.snapshots = scalar(db, "SELECT COUNT(*) FROM research_table_snapshots");
        d.upcomingRounds = scalar(db, "SELECT COUNT(*) FROM local_round_observations WHERE state='UPCOMING'");
        d.completedRounds = scalar(db, "SELECT COUNT(*) FROM local_round_observations WHERE state='COMPLETE'");
        try (Cursor c = db.rawQuery("SELECT finished_at, status, message FROM research_sync_log ORDER BY id DESC LIMIT 1", null)) {
            if (c.moveToFirst()) { d.lastSync = c.getString(0); d.lastStatus = c.getString(1); d.lastMessage = c.getString(2); }
        }
        return d;
    }

    private static int scalar(SQLiteDatabase db, String sql) {
        try (Cursor c = db.rawQuery(sql, null)) { return c.moveToFirst() ? c.getInt(0) : 0; }
    }

    public static List<String> recentComparisonSummaries(SQLiteDatabase db, int limit) {
        List<String> out = new ArrayList<>();
        String sql = "SELECT o.league_name, o.season, o.round_no, o.date_min, o.signature, c.summary " +
                "FROM local_round_observations o LEFT JOIN research_comparisons c ON c.observation_id=o.observation_id " +
                "WHERE o.state='UPCOMING' ORDER BY o.date_min ASC LIMIT ?";
        try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) {
                out.add((c.getString(0) == null ? c.getString(1) : c.getString(0)) + " | Runde " + c.getString(2) + " | " + c.getString(3) +
                        "\n" + c.getString(4) + "\n" + (c.getString(5) == null ? "Vergleich noch nicht berechnet" : c.getString(5)));
            }
        }
        return out;
    }

    private static String sourceForId(String leagueId) {
        return leagueId != null && leagueId.startsWith("fd:") ? "football-data.org" : "TheSportsDB";
    }

    public static final class DashboardStats {
        public int historicalRounds, leagues, fixtures, snapshots, upcomingRounds, completedRounds;
        public String lastSync, lastStatus, lastMessage;
    }
}
