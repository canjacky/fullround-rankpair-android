package com.gesundheit.fullround;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ResearchDb {
    private ResearchDb() {}

    public static void ensureSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS research_meta (key TEXT PRIMARY KEY, value TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_leagues (" +
                "league_id TEXT PRIMARY KEY, league_name TEXT, country TEXT, sport TEXT, source TEXT NOT NULL, " +
                "season TEXT, table_size INTEGER, discovered_at TEXT, last_sync_at TEXT, last_error TEXT)");
        ensureColumn(db,"research_leagues","seasons_discovered_at","TEXT");
        ensureColumn(db,"research_leagues","provider_key","TEXT");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_leagues_source_season ON research_leagues(source,season,last_sync_at)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_country_queue (" +
                "country TEXT PRIMARY KEY, discovered_at TEXT NOT NULL, last_crawled_at TEXT, last_error TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_season_backfill (" +
                "league_id TEXT NOT NULL, season TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0, " +
                "events_count INTEGER DEFAULT 0, rounds_added INTEGER DEFAULT 0, duplicates_skipped INTEGER DEFAULT 0, last_attempt_at TEXT, last_error TEXT, " +
                "PRIMARY KEY(league_id,season))");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_backfill_status ON research_season_backfill(status,last_attempt_at)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_teams (" +
                "team_id TEXT PRIMARY KEY, team_name TEXT NOT NULL, league_id TEXT, source TEXT NOT NULL, updated_at TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_fixtures (" +
                "event_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, event_date TEXT, event_time TEXT, " +
                "home_team_id TEXT, home_team TEXT, away_team_id TEXT, away_team TEXT, home_score INTEGER, away_score INTEGER, " +
                "status TEXT, result_1x2 TEXT, source TEXT NOT NULL, fetched_at TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_fixtures_league_round ON research_fixtures(league_id, season, round_no)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_fixtures_date ON research_fixtures(event_date)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_table_snapshots (" +
                "snapshot_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, captured_at TEXT NOT NULL, table_size INTEGER NOT NULL, source TEXT NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_research_snapshots_league ON research_table_snapshots(league_id, captured_at)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_table_rows (" +
                "snapshot_id TEXT NOT NULL, team_id TEXT NOT NULL, team_name TEXT NOT NULL, rank INTEGER, played INTEGER, wins INTEGER, draws INTEGER, losses INTEGER, " +
                "goals_for INTEGER, goals_against INTEGER, goal_diff INTEGER, points INTEGER, form TEXT, PRIMARY KEY(snapshot_id, team_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS local_round_observations (" +
                "observation_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, table_size INTEGER NOT NULL, k_played INTEGER, " +
                "date_min TEXT, date_max TEXT, signature TEXT NOT NULL, unordered_signature TEXT NOT NULL, result_vector TEXT, score_vector TEXT, " +
                "state TEXT NOT NULL, source TEXT NOT NULL, prematch_snapshot_id TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)");
        ensureColumn(db,"local_round_observations","research_kind","TEXT");
        ensureColumn(db,"local_round_observations","rank_method","TEXT");
        ensureColumn(db,"local_round_observations","dedupe_fingerprint","TEXT");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_local_round_signature ON local_round_observations(table_size, signature, state)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_local_round_unordered ON local_round_observations(table_size, unordered_signature, state)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_local_round_fingerprint ON local_round_observations(dedupe_fingerprint) WHERE dedupe_fingerprint IS NOT NULL");
        db.execSQL("CREATE TABLE IF NOT EXISTS local_round_games (" +
                "observation_id TEXT NOT NULL, event_id TEXT NOT NULL, home_team_id TEXT, away_team_id TEXT, home_rank INTEGER NOT NULL, away_rank INTEGER NOT NULL, " +
                "PRIMARY KEY(observation_id, event_id))");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_comparisons (" +
                "observation_id TEXT PRIMARY KEY, generated_at TEXT NOT NULL, directed_with_k_n INTEGER, directed_any_k_n INTEGER, unordered_any_k_n INTEGER, " +
                "summary TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS research_sync_log (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL, leagues_discovered INTEGER DEFAULT 0, " +
                "leagues_synced INTEGER DEFAULT 0, fixtures_upserted INTEGER DEFAULT 0, snapshots_added INTEGER DEFAULT 0, observations_added INTEGER DEFAULT 0, " +
                "observations_completed INTEGER DEFAULT 0, message TEXT)");
        ensureColumn(db,"research_sync_log","countries_crawled","INTEGER DEFAULT 0");
        ensureColumn(db,"research_sync_log","today_fixtures","INTEGER DEFAULT 0");
        ensureColumn(db,"research_sync_log","seasons_queued","INTEGER DEFAULT 0");
        ensureColumn(db,"research_sync_log","backfills_processed","INTEGER DEFAULT 0");
        ensureColumn(db,"research_sync_log","historical_rounds_added","INTEGER DEFAULT 0");
        ensureColumn(db,"research_sync_log","duplicates_skipped","INTEGER DEFAULT 0");
    }

    private static void ensureColumn(SQLiteDatabase db,String table,String column,String type) {
        boolean exists=false;
        try(Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null)){
            while(c.moveToNext()) if(column.equalsIgnoreCase(c.getString(1))){exists=true;break;}
        }
        if(!exists) db.execSQL("ALTER TABLE "+table+" ADD COLUMN "+column+" "+type);
    }

    public static void upsertLeague(SQLiteDatabase db, SportsDbClient.League league, String now) {
        if(league==null||league.id==null)return;
        ContentValues v = new ContentValues();
        v.put("league_id", league.id); v.put("league_name", league.name); v.put("country", league.country); v.put("sport", league.sport);
        v.put("source", league.source == null ? "TheSportsDB" : league.source); if(league.currentSeason!=null)v.put("season",league.currentSeason); if(league.providerKey!=null)v.put("provider_key",league.providerKey); v.put("discovered_at", now);
        db.insertWithOnConflict("research_leagues", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        ContentValues u = new ContentValues();
        if(league.name!=null)u.put("league_name", league.name); if(league.country!=null)u.put("country", league.country); if(league.sport!=null)u.put("sport", league.sport);
        if(league.source!=null)u.put("source",league.source); if(league.currentSeason!=null)u.put("season",league.currentSeason); if(league.providerKey!=null)u.put("provider_key",league.providerKey);
        db.update("research_leagues", u, "league_id=?", new String[]{league.id});
    }

    public static SportsDbClient.League getLeague(SQLiteDatabase db,String leagueId) {
        try(Cursor c=db.rawQuery("SELECT league_id,league_name,country,sport,source,season,provider_key FROM research_leagues WHERE league_id=?",new String[]{leagueId})){
            if(c.moveToFirst()){
                SportsDbClient.League l=new SportsDbClient.League();l.id=c.getString(0);l.name=c.getString(1);l.country=c.getString(2);l.sport=c.getString(3);l.source=c.getString(4);l.currentSeason=c.getString(5);l.providerKey=c.getString(6);return l;
            }
        }
        return null;
    }

    public static void enqueueCountries(SQLiteDatabase db,List<String> countries,String now){
        for(String country:countries){if(country==null||country.trim().isEmpty())continue;ContentValues v=new ContentValues();v.put("country",country.trim());v.put("discovered_at",now);db.insertWithOnConflict("research_country_queue",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    }

    public static List<String> countriesNeedingCrawl(SQLiteDatabase db,int limit){
        List<String>out=new ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT country FROM research_country_queue ORDER BY CASE WHEN last_crawled_at IS NULL THEN 0 ELSE 1 END,last_crawled_at ASC LIMIT ?",new String[]{String.valueOf(limit)})){while(c.moveToNext())out.add(c.getString(0));}
        return out;
    }

    public static void markCountryCrawled(SQLiteDatabase db,String country,String now,String error){ContentValues v=new ContentValues();v.put("last_crawled_at",now);if(error==null)v.putNull("last_error");else v.put("last_error",error);db.update("research_country_queue",v,"country=?",new String[]{country});}

    public static List<SportsDbClient.League> leaguesNeedingSync(SQLiteDatabase db, int limit) { return leaguesNeedingSync(db,null,limit); }

    public static List<SportsDbClient.League> leaguesNeedingSync(SQLiteDatabase db, String source, int limit) {
        List<SportsDbClient.League> out = new ArrayList<>();
        String where="WHERE sport='Soccer'";List<String>args=new ArrayList<>();if(source!=null){where+=" AND source=?";args.add(source);}args.add(String.valueOf(limit));
        try (Cursor c = db.rawQuery("SELECT league_id, league_name, country, sport, source, season, provider_key FROM research_leagues " + where +
                " ORDER BY CASE WHEN last_sync_at IS NULL THEN 0 ELSE 1 END, last_sync_at ASC LIMIT ?",args.toArray(new String[0]))) {
            while (c.moveToNext()) { SportsDbClient.League l = new SportsDbClient.League(); l.id=c.getString(0);l.name=c.getString(1);l.country=c.getString(2);l.sport=c.getString(3);l.source=c.getString(4);l.currentSeason=c.getString(5);l.providerKey=c.getString(6);out.add(l); }
        }
        return out;
    }

    public static List<SportsDbClient.League> leaguesNeedingSeasonDiscovery(SQLiteDatabase db,int limit){ return leaguesNeedingSeasonDiscovery(db,"TheSportsDB",limit); }

    public static List<SportsDbClient.League> leaguesNeedingSeasonDiscovery(SQLiteDatabase db,String source,int limit){
        List<SportsDbClient.League>out=new ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT league_id,league_name,country,sport,source,season,provider_key FROM research_leagues WHERE sport='Soccer' AND source=? ORDER BY CASE WHEN seasons_discovered_at IS NULL THEN 0 ELSE 1 END,seasons_discovered_at ASC LIMIT ?",new String[]{source,String.valueOf(limit)})){
            while(c.moveToNext()){SportsDbClient.League l=new SportsDbClient.League();l.id=c.getString(0);l.name=c.getString(1);l.country=c.getString(2);l.sport=c.getString(3);l.source=c.getString(4);l.currentSeason=c.getString(5);l.providerKey=c.getString(6);out.add(l);}
        }return out;
    }

    public static void markSeasonsDiscovered(SQLiteDatabase db,String leagueId,String now){ContentValues v=new ContentValues();v.put("seasons_discovered_at",now);db.update("research_leagues",v,"league_id=?",new String[]{leagueId});}

    public static int enqueueSeasons(SQLiteDatabase db,String leagueId,List<String>seasons){int n=0;for(String s:seasons){if(s==null||s.trim().isEmpty())continue;ContentValues v=new ContentValues();v.put("league_id",leagueId);v.put("season",s.trim());v.put("status","PENDING");long x=db.insertWithOnConflict("research_season_backfill",null,v,SQLiteDatabase.CONFLICT_IGNORE);if(x!=-1)n++;}return n;}

    public static List<BackfillTask> backfillsNeedingWork(SQLiteDatabase db,int limit){
        List<BackfillTask>out=new ArrayList<>();
        String sql="SELECT b.league_id,b.season,b.status,b.attempts,l.league_name,l.country,l.sport,l.source,l.provider_key FROM research_season_backfill b JOIN research_leagues l ON l.league_id=b.league_id WHERE b.status IN ('PENDING','ERROR','PARTIAL') ORDER BY CASE b.status WHEN 'PENDING' THEN 0 WHEN 'ERROR' THEN 1 ELSE 2 END,CASE l.source WHEN 'OpenLigaDB' THEN 0 WHEN 'football-data.org' THEN 1 ELSE 2 END,CASE WHEN b.last_attempt_at IS NULL THEN 0 ELSE 1 END,b.last_attempt_at ASC LIMIT ?";
        try(Cursor c=db.rawQuery(sql,new String[]{String.valueOf(limit)})){while(c.moveToNext()){BackfillTask t=new BackfillTask();t.leagueId=c.getString(0);t.season=c.getString(1);t.status=c.getString(2);t.attempts=c.getInt(3);t.leagueName=c.getString(4);t.country=c.getString(5);t.sport=c.getString(6);t.source=c.getString(7);t.providerKey=c.getString(8);out.add(t);}}return out;
    }

    public static void markBackfill(SQLiteDatabase db,BackfillTask t,String status,int eventsCount,int roundsAdded,int duplicates,String now,String error){ContentValues v=new ContentValues();v.put("status",status);v.put("attempts",t.attempts+1);v.put("events_count",eventsCount);v.put("rounds_added",roundsAdded);v.put("duplicates_skipped",duplicates);v.put("last_attempt_at",now);if(error==null)v.putNull("last_error");else v.put("last_error",error);db.update("research_season_backfill",v,"league_id=? AND season=?",new String[]{t.leagueId,t.season});}

    public static List<SportsDbClient.League> leaguesWithEventsOnDate(SQLiteDatabase db,String date){
        List<SportsDbClient.League>out=new ArrayList<>();
        String sql="SELECT l.league_id,l.league_name,l.country,l.sport,l.source,l.season,l.provider_key,MIN(CASE WHEN l.last_sync_at IS NULL THEN '' ELSE l.last_sync_at END) sort_sync FROM research_leagues l JOIN research_fixtures f ON f.league_id=l.league_id WHERE f.event_date=? AND l.sport='Soccer' GROUP BY l.league_id ORDER BY CASE WHEN l.last_sync_at IS NULL THEN 0 ELSE 1 END,l.last_sync_at ASC";
        try(Cursor c=db.rawQuery(sql,new String[]{date})){while(c.moveToNext()){SportsDbClient.League l=new SportsDbClient.League();l.id=c.getString(0);l.name=c.getString(1);l.country=c.getString(2);l.sport=c.getString(3);l.source=c.getString(4);l.currentSeason=c.getString(5);l.providerKey=c.getString(6);out.add(l);}}
        return out;
    }


    public static List<SportsDbClient.League> openLigaCurrentLeagues(SQLiteDatabase db,String seasonA,String seasonB,int limit){
        List<SportsDbClient.League>out=new ArrayList<>();
        String sql="SELECT league_id,league_name,country,sport,source,season,provider_key FROM research_leagues WHERE sport='Soccer' AND source='OpenLigaDB' AND season IN (?,?) ORDER BY CASE WHEN last_sync_at IS NULL THEN 0 ELSE 1 END,last_sync_at ASC LIMIT ?";
        try(Cursor c=db.rawQuery(sql,new String[]{seasonA,seasonB,String.valueOf(limit)})){while(c.moveToNext()){SportsDbClient.League l=new SportsDbClient.League();l.id=c.getString(0);l.name=c.getString(1);l.country=c.getString(2);l.sport=c.getString(3);l.source=c.getString(4);l.currentSeason=c.getString(5);l.providerKey=c.getString(6);out.add(l);}}
        return out;
    }

    public static int tableSizeForLeague(SQLiteDatabase db,String leagueId){try(Cursor c=db.rawQuery("SELECT table_size FROM research_leagues WHERE league_id=?",new String[]{leagueId})){if(c.moveToFirst()&&!c.isNull(0))return c.getInt(0);}return 0;}

    public static void markLeagueSynced(SQLiteDatabase db, String leagueId, String season, int tableSize, String now, String error) {
        ContentValues v = new ContentValues(); v.put("last_sync_at", now); if (season != null) v.put("season", season); if (tableSize > 0) v.put("table_size", tableSize); if (error == null) v.putNull("last_error"); else v.put("last_error", error); db.update("research_leagues", v, "league_id=?", new String[]{leagueId});
    }

    public static int upsertFixtures(SQLiteDatabase db, List<SportsDbClient.Event> events, String now) {
        int n = 0;
        for (SportsDbClient.Event e : events) {
            if(e==null||e.id==null||e.leagueId==null)continue;
            ContentValues v = new ContentValues();
            v.put("event_id", e.id); v.put("league_id", e.leagueId); v.put("league_name", e.leagueName); v.put("season", e.season); v.put("round_no", e.roundNo); v.put("event_date", e.date); v.put("event_time", e.time);
            v.put("home_team_id", e.homeTeamId); v.put("home_team", e.homeTeam); v.put("away_team_id", e.awayTeamId); v.put("away_team", e.awayTeam);
            if (e.homeScore == null) v.putNull("home_score"); else v.put("home_score", e.homeScore); if (e.awayScore == null) v.putNull("away_score"); else v.put("away_score", e.awayScore);
            v.put("status", e.status); v.put("result_1x2", e.result1x2()); v.put("source", sourceForId(e.leagueId)); v.put("fetched_at", now);
            db.insertWithOnConflict("research_fixtures", null, v, SQLiteDatabase.CONFLICT_REPLACE); n++;
            ContentValues ht=new ContentValues();ht.put("team_id",e.homeTeamId);ht.put("team_name",e.homeTeam==null?e.homeTeamId:e.homeTeam);ht.put("league_id",e.leagueId);ht.put("source",sourceForId(e.leagueId));ht.put("updated_at",now);if(e.homeTeamId!=null)db.insertWithOnConflict("research_teams",null,ht,SQLiteDatabase.CONFLICT_REPLACE);
            ContentValues at=new ContentValues();at.put("team_id",e.awayTeamId);at.put("team_name",e.awayTeam==null?e.awayTeamId:e.awayTeam);at.put("league_id",e.leagueId);at.put("source",sourceForId(e.leagueId));at.put("updated_at",now);if(e.awayTeamId!=null)db.insertWithOnConflict("research_teams",null,at,SQLiteDatabase.CONFLICT_REPLACE);
        }
        return n;
    }

    public static String saveStandingSnapshot(SQLiteDatabase db, SportsDbClient.TableData table, String now) {
        if (table.rows.isEmpty()) return null;
        String snapshotId = table.leagueId + "|" + (table.season == null ? "?" : table.season) + "|" + now;
        db.beginTransaction();
        try {
            ContentValues s = new ContentValues(); s.put("snapshot_id", snapshotId); s.put("league_id", table.leagueId); s.put("league_name", table.leagueName); s.put("season", table.season); s.put("captured_at", now); s.put("table_size", table.rows.size()); s.put("source", sourceForId(table.leagueId)); db.insertOrThrow("research_table_snapshots", null, s);
            for (SportsDbClient.TableRow r : table.rows) {
                ContentValues v = new ContentValues(); v.put("snapshot_id", snapshotId); v.put("team_id", r.teamId); v.put("team_name", r.teamName); v.put("rank", r.rank); v.put("played", r.played); v.put("wins", r.wins); v.put("draws", r.draws); v.put("losses", r.losses); v.put("goals_for", r.goalsFor); v.put("goals_against", r.goalsAgainst); v.put("goal_diff", r.goalDiff); v.put("points", r.points); v.put("form", r.form); db.insertOrThrow("research_table_rows", null, v);
                ContentValues t = new ContentValues(); t.put("team_id", r.teamId); t.put("team_name", r.teamName); t.put("league_id", table.leagueId); t.put("source", sourceForId(table.leagueId)); t.put("updated_at", now); db.insertWithOnConflict("research_teams", null, t, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return snapshotId;
    }

    public static Map<String, Integer> rankMap(SQLiteDatabase db, String snapshotId) { Map<String, Integer> out = new LinkedHashMap<>(); try (Cursor c = db.rawQuery("SELECT team_id, rank FROM research_table_rows WHERE snapshot_id=?", new String[]{snapshotId})) { while (c.moveToNext()) out.put(c.getString(0), c.getInt(1)); } return out; }
    public static Integer uniformPlayed(SQLiteDatabase db, String snapshotId) { try (Cursor c = db.rawQuery("SELECT MIN(played), MAX(played) FROM research_table_rows WHERE snapshot_id=?", new String[]{snapshotId})) { if (c.moveToFirst() && !c.isNull(0) && c.getInt(0) == c.getInt(1)) return c.getInt(0); } return null; }

    public static int cleanupExactLocalDuplicates(SQLiteDatabase db){
        List<String>drop=new ArrayList<>();
        String againstStatic="SELECT l.observation_id FROM local_round_observations l WHERE l.state='COMPLETE' AND EXISTS (SELECT 1 FROM round_signatures s WHERE s.table_size=l.table_size AND COALESCE(s.date_min,'')=COALESCE(l.date_min,'') AND COALESCE(s.date_max,'')=COALESCE(l.date_max,'') AND s.signature=l.signature AND COALESCE(s.result_vector,'')=COALESCE(l.result_vector,'') AND COALESCE(s.score_vector,'')=COALESCE(l.score_vector,''))";
        try(Cursor c=db.rawQuery(againstStatic,null)){while(c.moveToNext())drop.add(c.getString(0));}
        String localDup="SELECT observation_id FROM local_round_observations WHERE state='COMPLETE' AND observation_id NOT IN (SELECT MIN(observation_id) FROM local_round_observations WHERE state='COMPLETE' GROUP BY table_size,COALESCE(date_min,''),COALESCE(date_max,''),signature,COALESCE(result_vector,''),COALESCE(score_vector,''))";
        try(Cursor c=db.rawQuery(localDup,null)){while(c.moveToNext())if(!drop.contains(c.getString(0)))drop.add(c.getString(0));}
        for(String id:drop){db.delete("local_round_games","observation_id=?",new String[]{id});db.delete("research_comparisons","observation_id=?",new String[]{id});db.delete("local_round_observations","observation_id=?",new String[]{id});}
        return drop.size();
    }

    public static boolean roundContentExists(SQLiteDatabase db,int tableSize,String dateMin,String dateMax,String signature,String resultVector,String scoreVector){
        String[]a=new String[]{String.valueOf(tableSize),safe(dateMin),safe(dateMax),safe(signature),safe(resultVector),safe(scoreVector)};
        String staticSql="SELECT 1 FROM round_signatures WHERE table_size=? AND COALESCE(date_min,'')=? AND COALESCE(date_max,'')=? AND signature=? AND COALESCE(result_vector,'')=? AND COALESCE(score_vector,'')=? LIMIT 1";
        try(Cursor c=db.rawQuery(staticSql,a)){if(c.moveToFirst())return true;}
        String localSql="SELECT 1 FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND COALESCE(date_min,'')=? AND COALESCE(date_max,'')=? AND signature=? AND COALESCE(result_vector,'')=? AND COALESCE(score_vector,'')=? LIMIT 1";
        try(Cursor c=db.rawQuery(localSql,a)){if(c.moveToFirst())return true;}
        // Multi-provider tolerance: UTC/local-date conversion may move a match by one calendar day.
        // Require the entire round body + score body to be identical and both range endpoints within 1 day.
        if(dateMin!=null&&dateMax!=null&&!dateMin.isEmpty()&&!dateMax.isEmpty()){
            String[]b=new String[]{String.valueOf(tableSize),safe(signature),safe(resultVector),safe(scoreVector),dateMin,dateMax};
            String fuzzyStatic="SELECT 1 FROM round_signatures WHERE table_size=? AND signature=? AND COALESCE(result_vector,'')=? AND COALESCE(score_vector,'')=? AND ABS(julianday(date_min)-julianday(?))<=1 AND ABS(julianday(date_max)-julianday(?))<=1 LIMIT 1";
            try(Cursor c=db.rawQuery(fuzzyStatic,b)){if(c.moveToFirst())return true;}
            String fuzzyLocal="SELECT 1 FROM local_round_observations WHERE state='COMPLETE' AND table_size=? AND signature=? AND COALESCE(result_vector,'')=? AND COALESCE(score_vector,'')=? AND ABS(julianday(date_min)-julianday(?))<=1 AND ABS(julianday(date_max)-julianday(?))<=1 LIMIT 1";
            try(Cursor c=db.rawQuery(fuzzyLocal,b)){if(c.moveToFirst())return true;}
        }
        return false;
    }
    private static String safe(String s){return s==null?"":s;}

    public static long startSync(SQLiteDatabase db, String now) { ContentValues v = new ContentValues(); v.put("started_at", now); v.put("status", "RUNNING"); return db.insert("research_sync_log", null, v); }

    public static void finishSync(SQLiteDatabase db, long id, String now, String status, ResearchEngine.SyncStats st, String message) {
        ContentValues v = new ContentValues(); v.put("finished_at", now); v.put("status", status); v.put("leagues_discovered", st.leaguesDiscovered); v.put("leagues_synced", st.leaguesSynced); v.put("fixtures_upserted", st.fixturesUpserted); v.put("snapshots_added", st.snapshotsAdded); v.put("observations_added", st.observationsAdded); v.put("observations_completed", st.observationsCompleted); v.put("countries_crawled",st.countriesCrawled);v.put("today_fixtures",st.todayFixtures);v.put("seasons_queued",st.seasonsQueued);v.put("backfills_processed",st.backfillsProcessed);v.put("historical_rounds_added",st.historicalRoundsAdded);v.put("duplicates_skipped",st.duplicatesSkipped);v.put("message", message); db.update("research_sync_log", v, "id=?", new String[]{String.valueOf(id)});
    }

    public static String getMeta(SQLiteDatabase db, String key, String fallback) { try (Cursor c = db.rawQuery("SELECT value FROM research_meta WHERE key=?", new String[]{key})) { if (c.moveToFirst()) return c.getString(0); } return fallback; }
    public static void putMeta(SQLiteDatabase db, String key, String value) { ContentValues v = new ContentValues(); v.put("key", key); v.put("value", value); db.insertWithOnConflict("research_meta", null, v, SQLiteDatabase.CONFLICT_REPLACE); }

    public static DashboardStats dashboard(SQLiteDatabase db) {
        DashboardStats d = new DashboardStats();
        d.baseHistoricalRounds = scalar(db, "SELECT COUNT(*) FROM round_signatures");
        d.localHistoricalRounds = scalar(db, "SELECT COUNT(*) FROM local_round_observations WHERE state='COMPLETE'");
        d.historicalRounds=d.baseHistoricalRounds+d.localHistoricalRounds;
        d.leagues = scalar(db, "SELECT COUNT(*) FROM research_leagues WHERE sport='Soccer'");
        d.leaguesSportsDb=scalar(db,"SELECT COUNT(*) FROM research_leagues WHERE sport='Soccer' AND source='TheSportsDB'");
        d.leaguesFootballData=scalar(db,"SELECT COUNT(*) FROM research_leagues WHERE sport='Soccer' AND source='football-data.org'");
        d.leaguesOpenLigaDb=scalar(db,"SELECT COUNT(*) FROM research_leagues WHERE sport='Soccer' AND source='OpenLigaDB'");
        d.countries=scalar(db,"SELECT COUNT(*) FROM research_country_queue");
        d.fixtures = scalar(db, "SELECT COUNT(*) FROM research_fixtures");
        d.snapshots = scalar(db, "SELECT COUNT(*) FROM research_table_snapshots");
        d.upcomingRounds = scalar(db, "SELECT COUNT(*) FROM local_round_observations WHERE state='UPCOMING'");
        d.completedRounds = d.localHistoricalRounds;
        d.backfillPending=scalar(db,"SELECT COUNT(*) FROM research_season_backfill WHERE status IN ('PENDING','ERROR','PARTIAL')");
        d.backfillDone=scalar(db,"SELECT COUNT(*) FROM research_season_backfill WHERE status='DONE'");
        String today=ResearchEngine.today();
        try(Cursor c=db.rawQuery("SELECT COUNT(*),COUNT(DISTINCT league_id) FROM research_fixtures WHERE event_date=?",new String[]{today})){if(c.moveToFirst()){d.todayFixtures=c.getInt(0);d.todayLeagues=c.getInt(1);}}
        try (Cursor c = db.rawQuery("SELECT finished_at, status, message FROM research_sync_log ORDER BY id DESC LIMIT 1", null)) { if (c.moveToFirst()) { d.lastSync = c.getString(0); d.lastStatus = c.getString(1); d.lastMessage = c.getString(2); } }
        return d;
    }

    private static int scalar(SQLiteDatabase db, String sql) { try (Cursor c = db.rawQuery(sql, null)) { return c.moveToFirst() ? c.getInt(0) : 0; } }

    public static List<String> recentComparisonSummaries(SQLiteDatabase db, int limit) {
        List<String> out = new ArrayList<>();
        String sql = "SELECT o.league_name, o.season, o.round_no, o.date_min, o.signature, c.summary " +
                "FROM local_round_observations o LEFT JOIN research_comparisons c ON c.observation_id=o.observation_id " +
                "WHERE o.state='UPCOMING' ORDER BY CASE WHEN o.date_min=? THEN 0 ELSE 1 END,o.date_min ASC LIMIT ?";
        try (Cursor c = db.rawQuery(sql, new String[]{ResearchEngine.today(),String.valueOf(limit)})) {
            while (c.moveToNext()) { out.add((c.getString(0) == null ? "?" : c.getString(0)) + " | Runde " + c.getString(2) + " | " + c.getString(3) + "\n" + c.getString(4) + "\n" + (c.getString(5) == null ? "Vergleich noch nicht berechnet" : c.getString(5))); }
        }
        return out;
    }

    private static String sourceForId(String leagueId) { if(leagueId!=null&&leagueId.startsWith("fd:"))return "football-data.org"; if(leagueId!=null&&leagueId.startsWith("olg:"))return "OpenLigaDB"; return "TheSportsDB"; }

    public static final class BackfillTask { public String leagueId,season,status,leagueName,country,sport,source,providerKey; public int attempts; }
    public static final class DashboardStats {
        public int historicalRounds,baseHistoricalRounds,localHistoricalRounds,leagues,leaguesSportsDb,leaguesFootballData,leaguesOpenLigaDb,countries,fixtures,snapshots,upcomingRounds,completedRounds,todayFixtures,todayLeagues,backfillPending,backfillDone;
        public String lastSync, lastStatus, lastMessage;
    }
}
