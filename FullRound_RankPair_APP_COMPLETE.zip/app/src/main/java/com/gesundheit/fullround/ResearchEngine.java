package com.gesundheit.fullround;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public final class ResearchEngine {
    public interface Progress { void onProgress(String text); }
    private final Context context;
    private final DbHelper helper;
    private final SportsDbClient client;
    private final FootballDataClient footballClient;

    public ResearchEngine(Context context) {
        this.context=context.getApplicationContext();
        this.helper=new DbHelper(this.context);
        this.client=new SportsDbClient(this.context);
        this.footballClient=new FootballDataClient(this.context);
    }

    public SyncStats runFullSync(Progress progress) throws Exception {
        SQLiteDatabase db=helper.open();
        ResearchDb.ensureSchema(db);
        SyncStats st=new SyncStats();
        String started=now(); long logId=ResearchDb.startSync(db, started);
        String finalMessage="OK"; String finalStatus="OK";
        try {
            if(progress!=null) progress.onProgress("Research: Ligen vorbereiten …");
            seedDefaultLeagues(db, st);
            seedExtraLeagues(db, st, progress);
            if (footballClient.enabled()) seedFootballDataLeagues(db, st, progress);
            List<SportsDbClient.League> todo=new ArrayList<>();
            if (footballClient.enabled()) todo.addAll(ResearchDb.leaguesNeedingSync(db, "football-data.org", 4));
            todo.addAll(ResearchDb.leaguesNeedingSync(db, "TheSportsDB", footballClient.enabled()?2:6));
            for(SportsDbClient.League base:todo){
                if(progress!=null) progress.onProgress("Research: " + base.name + " [" + base.source + "] …");
                syncLeague(db, base, st);
            }
            if(progress!=null) progress.onProgress("Neue Full-Round-Fälle finalisieren …");
            st.observationsCompleted += finalizeObservedRounds(db);
            if(progress!=null) progress.onProgress("Vergleichsspiele automatisch suchen …");
            generateComparisons(db);
            ResearchDb.putMeta(db,"last_successful_sync",now());
        } catch(Exception e) {
            finalStatus="ERROR"; finalMessage=e.getClass().getSimpleName()+": "+e.getMessage();
            throw e;
        } finally {
            ResearchDb.finishSync(db,logId,now(),finalStatus,st,finalMessage);
        }
        return st;
    }

    private void seedFootballDataLeagues(SQLiteDatabase db, SyncStats st, Progress progress) {
        try {
            if (progress != null) progress.onProgress("football-data.org Wettbewerbe laden …");
            for (SportsDbClient.League l : footballClient.listCompetitions()) {
                ResearchDb.upsertLeague(db, l, now());
                st.leaguesDiscovered++;
            }
        } catch (Exception ignored) {}
    }

    private void seedDefaultLeagues(SQLiteDatabase db, SyncStats st) {
        String n=now();
        for(SportsDbClient.League l:client.defaultLeagues()){
            ResearchDb.upsertLeague(db,l,n); st.leaguesDiscovered++;
        }
    }

    private void seedExtraLeagues(SQLiteDatabase db, SyncStats st, Progress progress) {
        SharedPreferences p=context.getSharedPreferences("research",Context.MODE_PRIVATE);
        String raw=p.getString("extra_league_ids",""); if(raw==null||raw.trim().isEmpty()) return;
        for(String x:raw.split("[,;\\s]+")){
            String id=x.trim(); if(id.isEmpty())continue;
            boolean exists=false;
            try(Cursor c=db.rawQuery("SELECT 1 FROM research_leagues WHERE league_id=?",new String[]{id})){exists=c.moveToFirst();}
            if(exists) continue;
            try {
                if(progress!=null) progress.onProgress("Zusatzliga " + id + " identifizieren …");
                SportsDbClient.League l=client.lookupLeague(id);
                if(l!=null && "Soccer".equalsIgnoreCase(l.sport)){ResearchDb.upsertLeague(db,l,now()); st.leaguesDiscovered++;}
            } catch(Exception ignored) {}
        }
    }

    private void syncLeague(SQLiteDatabase db, SportsDbClient.League base, SyncStats st) {
        String error=null; String season=null; int tableSize=0;
        try {
            SportsDbClient.League live=base;
            SportsDbClient.TableData table;
            Map<String,SportsDbClient.Event> events=new LinkedHashMap<>();
            if ("football-data.org".equals(base.source)) {
                table=footballClient.fetchTable(live);
                season=table.season!=null?table.season:live.currentSeason;
                merge(events,footballClient.fetchMatches(live));
            } else {
                live=base;
                live.source="TheSportsDB";
                ResearchDb.upsertLeague(db,live,now());
                table=client.fetchTable(live);
                season=table.season!=null?table.season:live.currentSeason;
                if(season!=null) merge(events,client.fetchSeasonEvents(live,season));
                merge(events,client.fetchNextLeagueEvents(live));
                merge(events,client.fetchPastLeagueEvents(live));
            }
            tableSize=table.rows.size();
            String snapshotId=null;
            if(!table.rows.isEmpty()) { snapshotId=ResearchDb.saveStandingSnapshot(db,table,now()); st.snapshotsAdded++; }
            st.fixturesUpserted += ResearchDb.upsertFixtures(db,new ArrayList<>(events.values()),now());
            if(snapshotId!=null && tableSize>=2 && tableSize%2==0) st.observationsAdded += captureUpcomingFullRounds(db, live, season, snapshotId, tableSize);
            st.leaguesSynced++;
        } catch(Exception e) { error=e.getClass().getSimpleName()+": "+e.getMessage(); }
        ResearchDb.markLeagueSynced(db,base.id,season,tableSize,now(),error);
    }

    private static void merge(Map<String,SportsDbClient.Event> map,List<SportsDbClient.Event> xs){for(SportsDbClient.Event e:xs)map.put(e.id,e);}

    private int captureUpcomingFullRounds(SQLiteDatabase db, SportsDbClient.League league, String season, String snapshotId, int tableSize) throws Exception {
        Map<String,Integer> ranks=ResearchDb.rankMap(db,snapshotId); if(ranks.size()!=tableSize)return 0;
        Integer k=ResearchDb.uniformPlayed(db,snapshotId);
        Map<String,List<FixtureRow>> groups=new LinkedHashMap<>();
        String sql;
        String[] args;
        if (season == null) {
            sql="SELECT event_id,round_no,event_date,home_team_id,away_team_id,home_score,away_score FROM research_fixtures WHERE league_id=? AND round_no IS NOT NULL ORDER BY event_date,event_id";
            args=new String[]{league.id};
        } else {
            sql="SELECT event_id,round_no,event_date,home_team_id,away_team_id,home_score,away_score FROM research_fixtures WHERE league_id=? AND season=? AND round_no IS NOT NULL ORDER BY event_date,event_id";
            args=new String[]{league.id,season};
        }
        try(Cursor c=db.rawQuery(sql,args)){
            while(c.moveToNext()){
                FixtureRow f=new FixtureRow(); f.eventId=c.getString(0); f.round=c.getString(1); f.date=c.getString(2); f.homeId=c.getString(3); f.awayId=c.getString(4);
                f.homeScore=c.isNull(5)?null:c.getInt(5); f.awayScore=c.isNull(6)?null:c.getInt(6);
                if(f.round==null||f.homeId==null||f.awayId==null)continue;
                groups.computeIfAbsent(f.round,z->new ArrayList<>()).add(f);
            }
        }
        int added=0; String today=today();
        for(Map.Entry<String,List<FixtureRow>> en:groups.entrySet()){
            List<FixtureRow> fs=en.getValue(); if(fs.size()!=tableSize/2)continue;
            Set<String> teams=new HashSet<>(); boolean allMapped=true; int finished=0; String minDate=null,maxDate=null;
            for(FixtureRow f:fs){
                teams.add(f.homeId);teams.add(f.awayId); if(!ranks.containsKey(f.homeId)||!ranks.containsKey(f.awayId))allMapped=false;
                if(f.homeScore!=null&&f.awayScore!=null)finished++;
                if(f.date!=null){if(minDate==null||f.date.compareTo(minDate)<0)minDate=f.date;if(maxDate==null||f.date.compareTo(maxDate)>0)maxDate=f.date;}
            }
            // Never reconstruct a prematch body from a table after games have already finished.
            if(!allMapped||teams.size()!=tableSize||finished>0||minDate==null||minDate.compareTo(today)<0)continue;
            List<PairGame> pairs=new ArrayList<>();
            for(FixtureRow f:fs){PairGame pg=new PairGame();pg.eventId=f.eventId;pg.homeId=f.homeId;pg.awayId=f.awayId;pg.homeRank=ranks.get(f.homeId);pg.awayRank=ranks.get(f.awayId);pairs.add(pg);}
            Collections.sort(pairs,Comparator.comparingInt(a->a.homeRank));
            List<String> ptxt=new ArrayList<>();for(PairGame p:pairs)ptxt.add(p.homeRank+"->"+p.awayRank);
            String signature=SignatureUtil.normalizeAndValidateDirectedSignature(String.join("|",ptxt),tableSize);
            String unordered=SignatureUtil.toUnorderedSignature(signature);
            String obsId=league.id+"|"+(season==null?"?":season)+"|"+en.getKey();
            boolean exists=false;try(Cursor c=db.rawQuery("SELECT 1 FROM local_round_observations WHERE observation_id=?",new String[]{obsId})){exists=c.moveToFirst();}
            if(exists)continue;
            db.beginTransaction();
            try{
                ContentValues v=new ContentValues();v.put("observation_id",obsId);v.put("league_id",league.id);v.put("league_name",league.name);v.put("season",season);v.put("round_no",en.getKey());v.put("table_size",tableSize);
                if(k==null)v.putNull("k_played");else v.put("k_played",k);v.put("date_min",minDate);v.put("date_max",maxDate);v.put("signature",signature);v.put("unordered_signature",unordered);v.put("state","UPCOMING");v.put("source",league.source==null?"TheSportsDB":league.source);v.put("prematch_snapshot_id",snapshotId);v.put("created_at",now());v.put("updated_at",now());
                db.insertOrThrow("local_round_observations",null,v);
                for(PairGame p:pairs){ContentValues g=new ContentValues();g.put("observation_id",obsId);g.put("event_id",p.eventId);g.put("home_team_id",p.homeId);g.put("away_team_id",p.awayId);g.put("home_rank",p.homeRank);g.put("away_rank",p.awayRank);db.insertOrThrow("local_round_games",null,g);}
                db.setTransactionSuccessful();added++;
            }finally{db.endTransaction();}
        }
        return added;
    }

    private int finalizeObservedRounds(SQLiteDatabase db) {
        List<String> obsIds=new ArrayList<>();try(Cursor c=db.rawQuery("SELECT observation_id FROM local_round_observations WHERE state='UPCOMING'",null)){while(c.moveToNext())obsIds.add(c.getString(0));}
        int done=0;
        for(String obs:obsIds){
            List<CompletedGame> gs=new ArrayList<>(); boolean complete=true;
            String sql="SELECT g.home_rank,g.away_rank,f.home_score,f.away_score FROM local_round_games g JOIN research_fixtures f ON f.event_id=g.event_id WHERE g.observation_id=? ORDER BY g.home_rank,g.away_rank";
            try(Cursor c=db.rawQuery(sql,new String[]{obs})){
                while(c.moveToNext()){CompletedGame g=new CompletedGame();g.hr=c.getInt(0);g.ar=c.getInt(1);if(c.isNull(2)||c.isNull(3)){complete=false;break;}g.hs=c.getInt(2);g.as=c.getInt(3);gs.add(g);}
            }
            if(!complete||gs.isEmpty())continue;
            StringBuilder rv=new StringBuilder(),sv=new StringBuilder();
            for(CompletedGame g:gs){if(rv.length()>0){rv.append('|');sv.append('|');}String p=g.hr+"->"+g.ar;String r=g.hs>g.as?"1":g.hs<g.as?"2":"X";rv.append(p).append(':').append(r);sv.append(p).append(':').append(g.hs).append('-').append(g.as);}
            ContentValues v=new ContentValues();v.put("result_vector",rv.toString());v.put("score_vector",sv.toString());v.put("state","COMPLETE");v.put("updated_at",now());db.update("local_round_observations",v,"observation_id=?",new String[]{obs});done++;
        }
        return done;
    }

    private void generateComparisons(SQLiteDatabase db) throws Exception {
        List<Upcoming> xs=new ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT observation_id,table_size,k_played,signature FROM local_round_observations WHERE state='UPCOMING' ORDER BY date_min LIMIT 20",null)){
            while(c.moveToNext()){Upcoming u=new Upcoming();u.id=c.getString(0);u.tableSize=c.getInt(1);u.k=c.isNull(2)?null:c.getInt(2);u.signature=c.getString(3);xs.add(u);}
        }
        for(Upcoming u:xs){
            DbHelper.AnalysisResult r=helper.analyzeAuto(u.tableSize,u.k,u.signature);
            String summary="mit K: "+r.directedWithK.size()+" | ohne K: "+r.directedAnyK.size()+" | unordered: "+r.unorderedAnyK.size()+"\n"+pairSummary(r.pairSummaries.get("directed_any_k"));
            ContentValues v=new ContentValues();v.put("observation_id",u.id);v.put("generated_at",now());v.put("directed_with_k_n",r.directedWithK.size());v.put("directed_any_k_n",r.directedAnyK.size());v.put("unordered_any_k_n",r.unorderedAnyK.size());v.put("summary",summary);db.insertWithOnConflict("research_comparisons",null,v,SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private String pairSummary(List<DbHelper.PairSummary> ps){if(ps==null)return "";StringBuilder sb=new StringBuilder();for(DbHelper.PairSummary p:ps){if(sb.length()>0)sb.append("; ");sb.append(p.pair).append('=').append(p.market()).append(" N").append(p.n);}return sb.toString();}

    public ResearchDb.DashboardStats dashboard() throws Exception {SQLiteDatabase db=helper.open();ResearchDb.ensureSchema(db);return ResearchDb.dashboard(db);}
    public List<String> recentComparisons() throws Exception {SQLiteDatabase db=helper.open();ResearchDb.ensureSchema(db);return ResearchDb.recentComparisonSummaries(db,10);}

    public static String now(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    public static String today(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}

    public static final class SyncStats {public int leaguesDiscovered,leaguesSynced,fixturesUpserted,snapshotsAdded,observationsAdded,observationsCompleted;public String describe(){return "Ligen synced: "+leaguesSynced+", Fixtures: "+fixturesUpserted+", Tabellen: "+snapshotsAdded+", neue Prematch-Runden: "+observationsAdded+", abgeschlossene neue Cases: "+observationsCompleted;}}
    private static final class FixtureRow{String eventId,round,date,homeId,awayId;Integer homeScore,awayScore;}
    private static final class PairGame{String eventId,homeId,awayId;int homeRank,awayRank;}
    private static final class CompletedGame{int hr,ar,hs,as;}
    private static final class Upcoming{String id,signature;int tableSize;Integer k;}
}
