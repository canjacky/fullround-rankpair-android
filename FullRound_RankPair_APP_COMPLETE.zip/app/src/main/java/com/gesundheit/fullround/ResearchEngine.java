package com.gesundheit.fullround;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public final class ResearchEngine {
    public interface Progress { void onProgress(String text); }
    private final Context context;
    private final DbHelper helper;
    private final SportsDbClient client;
    private final FootballDataClient footballClient;

    public ResearchEngine(Context context) {
        this.context=context.getApplicationContext();
        this.helper=new DbHelper(this.context);
        this.client=new SportsDbClient(this.context);
        this.footballClient=new FootballDataClient(this.context);
    }

    public SyncStats runFullSync(Progress progress) throws Exception {
        SQLiteDatabase db=helper.open();
        ResearchDb.ensureSchema(db);
        SyncStats st=new SyncStats();
        st.duplicatesSkipped+=ResearchDb.cleanupExactLocalDuplicates(db);
        String started=now(); long logId=ResearchDb.startSync(db, started);
        String finalMessage="OK"; String finalStatus="OK";
        try {
            if(progress!=null) progress.onProgress("Global Research: Länder und Ligen entdecken …");
            seedDefaultLeagues(db,st);
            discoverGlobalCatalog(db,st,progress);
            seedExtraLeagues(db,st,progress);
            if(footballClient.enabled()) seedFootballDataLeagues(db,st,progress);

            if(progress!=null) progress.onProgress("Heutige Fußballspiele weltweit abrufen …");
            scanTodayGlobally(db,st);

            Set<String> synced=new HashSet<>();
            long deepDeadline=System.currentTimeMillis()+5L*60L*1000L;
            List<SportsDbClient.League> todayLeagues=ResearchDb.leaguesWithEventsOnDate(db,today());
            st.todayLeaguesFound=todayLeagues.size();
            for(SportsDbClient.League l:todayLeagues){
                if(System.currentTimeMillis()>deepDeadline){st.todayLeaguesPending++;continue;}
                if(progress!=null)progress.onProgress("Heute: "+l.name+" ["+(l.country==null?"?":l.country)+"] …");
                syncLeague(db,l,st);synced.add(l.id);st.todayLeaguesDeepSynced++;
            }

            if(progress!=null)progress.onProgress("Weitere Ligen aktuell halten …");
            List<SportsDbClient.League> background=new ArrayList<>();
            if(footballClient.enabled())background.addAll(ResearchDb.leaguesNeedingSync(db,"football-data.org",2));
            background.addAll(ResearchDb.leaguesNeedingSync(db,"TheSportsDB",4));
            for(SportsDbClient.League l:background){if(synced.contains(l.id))continue;syncLeague(db,l,st);synced.add(l.id);}

            if(progress!=null)progress.onProgress("Historische Saison-Backfills vorbereiten …");
            discoverHistoricalSeasons(db,st,progress);
            if(progress!=null)progress.onProgress("Historische Full-Rounds rekonstruieren …");
            processHistoricalBackfills(db,st,progress);

            if(progress!=null) progress.onProgress("Neue aktuelle Full-Round-Fälle finalisieren …");
            st.observationsCompleted += finalizeObservedRounds(db);
            if(progress!=null) progress.onProgress("Heutige/kommende Runden mit der Datenbank vergleichen …");
            generateComparisons(db);
            ResearchDb.putMeta(db,"last_successful_sync",now());
            finalMessage=st.describe();
        } catch(Exception e) {
            finalStatus="ERROR"; finalMessage=e.getClass().getSimpleName()+": "+e.getMessage();
            throw e;
        } finally {
            ResearchDb.finishSync(db,logId,now(),finalStatus,st,finalMessage);
        }
        return st;
    }

    private void discoverGlobalCatalog(SQLiteDatabase db,SyncStats st,Progress progress){
        try{
            for(SportsDbClient.League l:client.fetchAllLeagues()){ResearchDb.upsertLeague(db,l,now());st.leaguesDiscovered++;}
        }catch(Exception e){ResearchDb.putMeta(db,"last_all_leagues_error",e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}
        try{
            List<String>countries=client.fetchAllCountries();ResearchDb.enqueueCountries(db,countries,now());st.countriesDiscovered+=countries.size();
        }catch(Exception e){ResearchDb.putMeta(db,"last_country_list_error",e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}
        for(String country:ResearchDb.countriesNeedingCrawl(db,10)){
            String err=null;
            try{
                if(progress!=null)progress.onProgress("Liga-Katalog: "+country+" …");
                for(SportsDbClient.League l:client.fetchSoccerLeaguesForCountry(country)){ResearchDb.upsertLeague(db,l,now());st.leaguesDiscovered++;}
                st.countriesCrawled++;
            }catch(Exception e){err=e.getClass().getSimpleName()+": "+e.getMessage();}
            ResearchDb.markCountryCrawled(db,country,now(),err);
        }
    }

    private void scanTodayGlobally(SQLiteDatabase db,SyncStats st){
        try{
            List<SportsDbClient.Event>events=client.fetchDayEvents(today());
            st.todayFixtures=events.size();st.fixturesUpserted+=ResearchDb.upsertFixtures(db,events,now());
            LinkedHashSet<String>seen=new LinkedHashSet<>();
            for(SportsDbClient.Event e:events){
                if(e.leagueId==null||!seen.add(e.leagueId))continue;
                SportsDbClient.League l=new SportsDbClient.League();l.id=e.leagueId;l.name=e.leagueName==null?"League "+e.leagueId:e.leagueName;l.country=e.country==null?"":e.country;l.sport="Soccer";l.currentSeason=e.season;l.source="TheSportsDB";ResearchDb.upsertLeague(db,l,now());
            }
        }catch(Exception e){ResearchDb.putMeta(db,"last_today_scan_error",e.getClass().getSimpleName()+": "+e.getMessage());}
    }

    private void seedFootballDataLeagues(SQLiteDatabase db, SyncStats st, Progress progress) {
        try { if (progress != null) progress.onProgress("Sekundärquelle football-data.org Wettbewerbe laden …"); for (SportsDbClient.League l : footballClient.listCompetitions()) { ResearchDb.upsertLeague(db, l, now()); st.leaguesDiscovered++; } } catch (Exception ignored) {}
    }

    private void seedDefaultLeagues(SQLiteDatabase db, SyncStats st) { String n=now(); for(SportsDbClient.League l:client.defaultLeagues()){ResearchDb.upsertLeague(db,l,n);st.leaguesDiscovered++;} }

    private void seedExtraLeagues(SQLiteDatabase db, SyncStats st, Progress progress) {
        SharedPreferences p=context.getSharedPreferences("research",Context.MODE_PRIVATE); String raw=p.getString("extra_league_ids",""); if(raw==null||raw.trim().isEmpty()) return;
        for(String x:raw.split("[,;\\s]+")){String id=x.trim();if(id.isEmpty())continue;try{if(progress!=null)progress.onProgress("Zusatzliga "+id+" identifizieren …");SportsDbClient.League l=client.lookupLeague(id);if(l!=null&&"Soccer".equalsIgnoreCase(l.sport)){ResearchDb.upsertLeague(db,l,now());st.leaguesDiscovered++;}}catch(Exception ignored){}}
    }

    private void syncLeague(SQLiteDatabase db, SportsDbClient.League base, SyncStats st) {
        String error=null;String season=base.currentSeason;int tableSize=0;
        try {
            SportsDbClient.League live=base;SportsDbClient.TableData table;Map<String,SportsDbClient.Event>events=new LinkedHashMap<>();
            if("football-data.org".equals(base.source)){
                table=footballClient.fetchTable(live);season=table.season!=null?table.season:live.currentSeason;merge(events,footballClient.fetchMatches(live));
            }else{
                if(live.currentSeason==null){try{SportsDbClient.League looked=client.lookupLeague(live.id);if(looked!=null)live=looked;}catch(Exception ignored){}}
                live.source="TheSportsDB";ResearchDb.upsertLeague(db,live,now());
                table=client.fetchTable(live);season=table.season!=null?table.season:live.currentSeason;
                if(season!=null){merge(events,client.fetchSeasonEvents(live,season));st.seasonsQueued+=ResearchDb.enqueueSeasons(db,live.id,Collections.singletonList(season));}
                merge(events,client.fetchNextLeagueEvents(live));merge(events,client.fetchPastLeagueEvents(live));
            }
            tableSize=table.rows.size();String snapshotId=null;if(!table.rows.isEmpty()){snapshotId=ResearchDb.saveStandingSnapshot(db,table,now());st.snapshotsAdded++;}
            st.fixturesUpserted+=ResearchDb.upsertFixtures(db,new ArrayList<>(events.values()),now());
            if(snapshotId!=null&&tableSize>=2&&tableSize%2==0)st.observationsAdded+=captureUpcomingFullRounds(db,live,season,snapshotId,tableSize);
            st.leaguesSynced++;
        }catch(Exception e){error=e.getClass().getSimpleName()+": "+e.getMessage();}
        ResearchDb.markLeagueSynced(db,base.id,season,tableSize,now(),error);
    }

    private void discoverHistoricalSeasons(SQLiteDatabase db,SyncStats st,Progress progress){
        for(SportsDbClient.League l:ResearchDb.leaguesNeedingSeasonDiscovery(db,10)){
            try{
                if(progress!=null)progress.onProgress("Historie katalogisieren: "+l.name+" …");
                List<String>seasons=client.fetchSeasons(l);st.seasonsQueued+=ResearchDb.enqueueSeasons(db,l.id,seasons);ResearchDb.markSeasonsDiscovered(db,l.id,now());
            }catch(Exception e){ResearchDb.putMeta(db,"season_discovery_error_"+l.id,e.getClass().getSimpleName()+": "+e.getMessage());}
        }
    }

    private void processHistoricalBackfills(SQLiteDatabase db,SyncStats st,Progress progress){
        for(ResearchDb.BackfillTask t:ResearchDb.backfillsNeedingWork(db,10)){
            String status="ERROR",err=null;int eventsCount=0,added=0,dups=0;
            try{
                if(progress!=null)progress.onProgress("Historischer Backfill: "+t.leagueName+" "+t.season+" …");
                SportsDbClient.League l=new SportsDbClient.League();l.id=t.leagueId;l.name=t.leagueName;l.country=t.country;l.sport="Soccer";l.source="TheSportsDB";l.currentSeason=t.season;
                List<SportsDbClient.Event>events=client.fetchSeasonEvents(l,t.season);eventsCount=events.size();st.fixturesUpserted+=ResearchDb.upsertFixtures(db,events,now());
                BackfillResult r=reconstructHistoricalFullRounds(db,l,t.season,events);added=r.added;dups=r.duplicates;status=r.complete?"DONE":"PARTIAL";
                st.historicalRoundsAdded+=added;st.duplicatesSkipped+=dups;st.backfillsProcessed++;
            }catch(Exception e){err=e.getClass().getSimpleName()+": "+e.getMessage();}
            ResearchDb.markBackfill(db,t,status,eventsCount,added,dups,now(),err);
        }
    }

    private BackfillResult reconstructHistoricalFullRounds(SQLiteDatabase db,SportsDbClient.League league,String season,List<SportsDbClient.Event>events)throws Exception{
        BackfillResult out=new BackfillResult();if(events==null||events.isEmpty())return out;
        Map<Integer,List<SportsDbClient.Event>>byRound=new LinkedHashMap<>();Set<String>teams=new LinkedHashSet<>();Map<String,String>teamNames=new HashMap<>();int maxRound=0;
        for(SportsDbClient.Event e:events){Integer r=parseRound(e.roundNo);if(r==null||r<1||e.homeTeamId==null||e.awayTeamId==null)continue;byRound.computeIfAbsent(r,z->new ArrayList<>()).add(e);teams.add(e.homeTeamId);teams.add(e.awayTeamId);teamNames.put(e.homeTeamId,e.homeTeam);teamNames.put(e.awayTeamId,e.awayTeam);if(r>maxRound)maxRound=r;}
        int tableSize=teams.size();if(tableSize<4||tableSize%2!=0||!byRound.containsKey(1))return out;
        List<Integer>rounds=new ArrayList<>(byRound.keySet());Collections.sort(rounds);
        Map<String,TeamStat>stats=new LinkedHashMap<>();for(String id:teams){TeamStat s=new TeamStat();s.id=id;s.name=teamNames.get(id);stats.put(id,s);}
        boolean chainStarted=false;boolean chainBroken=false;int expectedRound=1;
        for(Integer round:rounds){
            if(round!=expectedRound){chainBroken=true;break;}List<SportsDbClient.Event>games=byRound.get(round);
            if(!isCompleteFullRound(games,teams,tableSize)){chainBroken=true;break;}
            boolean allScores=true;for(SportsDbClient.Event e:games)if(e.homeScore==null||e.awayScore==null){allScores=false;break;}if(!allScores){chainBroken=true;break;}
            Integer k=uniformPlayed(stats);if(k==null){chainBroken=true;break;}
            if(k>0){
                Map<String,Integer>ranks=rankMap(stats);List<HistoricalPair>pairs=new ArrayList<>();String minDate=null,maxDate=null;
                for(SportsDbClient.Event e:games){HistoricalPair p=new HistoricalPair();p.event=e;p.hr=ranks.get(e.homeTeamId);p.ar=ranks.get(e.awayTeamId);pairs.add(p);if(e.date!=null){if(minDate==null||e.date.compareTo(minDate)<0)minDate=e.date;if(maxDate==null||e.date.compareTo(maxDate)>0)maxDate=e.date;}}
                Collections.sort(pairs,Comparator.comparingInt((HistoricalPair p)->p.hr).thenComparingInt(p->p.ar));
                List<String>sigParts=new ArrayList<>();StringBuilder rv=new StringBuilder(),sv=new StringBuilder();
                for(HistoricalPair p:pairs){String pair=p.hr+"->"+p.ar;sigParts.add(pair);if(rv.length()>0){rv.append('|');sv.append('|');}String res=p.event.homeScore>p.event.awayScore?"1":p.event.homeScore<p.event.awayScore?"2":"X";rv.append(pair).append(':').append(res);sv.append(pair).append(':').append(p.event.homeScore).append('-').append(p.event.awayScore);}
                String sig=SignatureUtil.normalizeAndValidateDirectedSignature(String.join("|",sigParts),tableSize);String unordered=SignatureUtil.toUnorderedSignature(sig);String resultVector=rv.toString(),scoreVector=sv.toString();
                if(ResearchDb.roundContentExists(db,tableSize,minDate,maxDate,sig,resultVector,scoreVector)){out.duplicates++;}
                else{insertHistoricalObservation(db,league,season,round,tableSize,k,minDate,maxDate,sig,unordered,resultVector,scoreVector);out.added++;}
            }
            for(SportsDbClient.Event e:games)apply(stats.get(e.homeTeamId),stats.get(e.awayTeamId),e.homeScore,e.awayScore);
            chainStarted=true;expectedRound++;
        }
        // A schedule is considered complete enough only if it at least covers a full single round-robin span and no safe-chain break occurred.
        out.complete=chainStarted&&!chainBroken&&maxRound>=tableSize-1;
        return out;
    }

    private void insertHistoricalObservation(SQLiteDatabase db,SportsDbClient.League league,String season,int round,int tableSize,int k,String minDate,String maxDate,String signature,String unordered,String resultVector,String scoreVector)throws Exception{
        String raw=tableSize+"|"+safe(minDate)+"|"+safe(maxDate)+"|"+signature+"|"+resultVector+"|"+scoreVector;String fp=sha256(raw);String obsId="hist|"+league.id+"|"+season+"|"+round+"|"+fp.substring(0,16);
        ContentValues v=new ContentValues();v.put("observation_id",obsId);v.put("league_id",league.id);v.put("league_name",league.name);v.put("season",season);v.put("round_no",String.valueOf(round));v.put("table_size",tableSize);v.put("k_played",k);v.put("date_min",minDate);v.put("date_max",maxDate);v.put("signature",signature);v.put("unordered_signature",unordered);v.put("result_vector",resultVector);v.put("score_vector",scoreVector);v.put("state","COMPLETE");v.put("source","TheSportsDB-HISTORICAL");v.put("prematch_snapshot_id","reconstructed:"+league.id+":"+season+":"+round);v.put("research_kind","HISTORICAL_BACKFILL");v.put("rank_method","POINTS_GD_GF_WINS_RECONSTRUCTED");v.put("dedupe_fingerprint",fp);v.put("created_at",now());v.put("updated_at",now());db.insertWithOnConflict("local_round_observations",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }

    private static boolean isCompleteFullRound(List<SportsDbClient.Event>games,Set<String>allTeams,int tableSize){if(games==null||games.size()!=tableSize/2)return false;Set<String>seen=new HashSet<>();for(SportsDbClient.Event e:games){if(!allTeams.contains(e.homeTeamId)||!allTeams.contains(e.awayTeamId)||!seen.add(e.homeTeamId)||!seen.add(e.awayTeamId))return false;}return seen.size()==tableSize;}
    private static Integer parseRound(String raw){if(raw==null)return null;StringBuilder n=new StringBuilder();for(int i=0;i<raw.length();i++){char ch=raw.charAt(i);if(Character.isDigit(ch))n.append(ch);else if(n.length()>0)break;}if(n.length()==0)return null;try{return Integer.valueOf(n.toString());}catch(Exception e){return null;}}
    private static Integer uniformPlayed(Map<String,TeamStat>stats){Integer x=null;for(TeamStat s:stats.values()){if(x==null)x=s.played;else if(x!=s.played)return null;}return x==null?0:x;}
    private static Map<String,Integer>rankMap(Map<String,TeamStat>stats){List<TeamStat>xs=new ArrayList<>(stats.values());Collections.sort(xs,(a,b)->{int c=Integer.compare(b.points,a.points);if(c!=0)return c;c=Integer.compare((b.gf-b.ga),(a.gf-a.ga));if(c!=0)return c;c=Integer.compare(b.gf,a.gf);if(c!=0)return c;c=Integer.compare(b.wins,a.wins);if(c!=0)return c;return safe(a.id).compareTo(safe(b.id));});Map<String,Integer>out=new HashMap<>();for(int i=0;i<xs.size();i++)out.put(xs.get(i).id,i+1);return out;}
    private static void apply(TeamStat h,TeamStat a,int hs,int as){h.played++;a.played++;h.gf+=hs;h.ga+=as;a.gf+=as;a.ga+=hs;if(hs>as){h.wins++;a.losses++;h.points+=3;}else if(hs<as){a.wins++;h.losses++;a.points+=3;}else{h.draws++;a.draws++;h.points++;a.points++;}}

    private static void merge(Map<String,SportsDbClient.Event> map,List<SportsDbClient.Event> xs){for(SportsDbClient.Event e:xs)if(e!=null&&e.id!=null)map.put(e.id,e);}

    private int captureUpcomingFullRounds(SQLiteDatabase db, SportsDbClient.League league, String season, String snapshotId, int tableSize) throws Exception {
        Map<String,Integer> ranks=ResearchDb.rankMap(db,snapshotId); if(ranks.size()!=tableSize)return 0;Integer k=ResearchDb.uniformPlayed(db,snapshotId);Map<String,List<FixtureRow>>groups=new LinkedHashMap<>();String sql;String[]args;
        if(season==null){sql="SELECT event_id,round_no,event_date,home_team_id,away_team_id,home_score,away_score FROM research_fixtures WHERE league_id=? AND round_no IS NOT NULL ORDER BY event_date,event_id";args=new String[]{league.id};}
        else{sql="SELECT event_id,round_no,event_date,home_team_id,away_team_id,home_score,away_score FROM research_fixtures WHERE league_id=? AND season=? AND round_no IS NOT NULL ORDER BY event_date,event_id";args=new String[]{league.id,season};}
        try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext()){FixtureRow f=new FixtureRow();f.eventId=c.getString(0);f.round=c.getString(1);f.date=c.getString(2);f.homeId=c.getString(3);f.awayId=c.getString(4);f.homeScore=c.isNull(5)?null:c.getInt(5);f.awayScore=c.isNull(6)?null:c.getInt(6);if(f.round==null||f.homeId==null||f.awayId==null)continue;groups.computeIfAbsent(f.round,z->new ArrayList<>()).add(f);}}
        int added=0;String today=today();
        for(Map.Entry<String,List<FixtureRow>>en:groups.entrySet()){
            List<FixtureRow>fs=en.getValue();if(fs.size()!=tableSize/2)continue;Set<String>teams=new HashSet<>();boolean allMapped=true;int finished=0;String minDate=null,maxDate=null;
            for(FixtureRow f:fs){teams.add(f.homeId);teams.add(f.awayId);if(!ranks.containsKey(f.homeId)||!ranks.containsKey(f.awayId))allMapped=false;if(f.homeScore!=null&&f.awayScore!=null)finished++;if(f.date!=null){if(minDate==null||f.date.compareTo(minDate)<0)minDate=f.date;if(maxDate==null||f.date.compareTo(maxDate)>0)maxDate=f.date;}}
            if(!allMapped||teams.size()!=tableSize||finished>0||minDate==null||minDate.compareTo(today)<0)continue;
            List<PairGame>pairs=new ArrayList<>();for(FixtureRow f:fs){PairGame pg=new PairGame();pg.eventId=f.eventId;pg.homeId=f.homeId;pg.awayId=f.awayId;pg.homeRank=ranks.get(f.homeId);pg.awayRank=ranks.get(f.awayId);pairs.add(pg);}Collections.sort(pairs,Comparator.comparingInt(a->a.homeRank));List<String>ptxt=new ArrayList<>();for(PairGame p:pairs)ptxt.add(p.homeRank+"->"+p.awayRank);String signature=SignatureUtil.normalizeAndValidateDirectedSignature(String.join("|",ptxt),tableSize);String unordered=SignatureUtil.toUnorderedSignature(signature);String obsId=league.id+"|"+(season==null?"?":season)+"|"+en.getKey();boolean exists=false;try(Cursor c=db.rawQuery("SELECT 1 FROM local_round_observations WHERE observation_id=?",new String[]{obsId})){exists=c.moveToFirst();}if(exists)continue;
            db.beginTransaction();try{ContentValues v=new ContentValues();v.put("observation_id",obsId);v.put("league_id",league.id);v.put("league_name",league.name);v.put("season",season);v.put("round_no",en.getKey());v.put("table_size",tableSize);if(k==null)v.putNull("k_played");else v.put("k_played",k);v.put("date_min",minDate);v.put("date_max",maxDate);v.put("signature",signature);v.put("unordered_signature",unordered);v.put("state","UPCOMING");v.put("source",league.source==null?"TheSportsDB":league.source);v.put("prematch_snapshot_id",snapshotId);v.put("research_kind","LIVE_PREMATCH_FREEZE");v.put("rank_method","PROVIDER_TABLE");v.put("created_at",now());v.put("updated_at",now());db.insertOrThrow("local_round_observations",null,v);for(PairGame p:pairs){ContentValues g=new ContentValues();g.put("observation_id",obsId);g.put("event_id",p.eventId);g.put("home_team_id",p.homeId);g.put("away_team_id",p.awayId);g.put("home_rank",p.homeRank);g.put("away_rank",p.awayRank);db.insertOrThrow("local_round_games",null,g);}db.setTransactionSuccessful();added++;}finally{db.endTransaction();}
        }
        return added;
    }

    private int finalizeObservedRounds(SQLiteDatabase db) {
        List<String>obsIds=new ArrayList<>();try(Cursor c=db.rawQuery("SELECT observation_id FROM local_round_observations WHERE state='UPCOMING'",null)){while(c.moveToNext())obsIds.add(c.getString(0));}int done=0;
        for(String obs:obsIds){List<CompletedGame>gs=new ArrayList<>();boolean complete=true;String sql="SELECT g.home_rank,g.away_rank,f.home_score,f.away_score FROM local_round_games g JOIN research_fixtures f ON f.event_id=g.event_id WHERE g.observation_id=? ORDER BY g.home_rank,g.away_rank";try(Cursor c=db.rawQuery(sql,new String[]{obs})){while(c.moveToNext()){CompletedGame g=new CompletedGame();g.hr=c.getInt(0);g.ar=c.getInt(1);if(c.isNull(2)||c.isNull(3)){complete=false;break;}g.hs=c.getInt(2);g.as=c.getInt(3);gs.add(g);}}if(!complete||gs.isEmpty())continue;StringBuilder rv=new StringBuilder(),sv=new StringBuilder();for(CompletedGame g:gs){if(rv.length()>0){rv.append('|');sv.append('|');}String p=g.hr+"->"+g.ar;String r=g.hs>g.as?"1":g.hs<g.as?"2":"X";rv.append(p).append(':').append(r);sv.append(p).append(':').append(g.hs).append('-').append(g.as);}ContentValues v=new ContentValues();v.put("result_vector",rv.toString());v.put("score_vector",sv.toString());v.put("state","COMPLETE");v.put("updated_at",now());db.update("local_round_observations",v,"observation_id=?",new String[]{obs});done++;}
        return done;
    }

    private void generateComparisons(SQLiteDatabase db) throws Exception {
        List<Upcoming>xs=new ArrayList<>();try(Cursor c=db.rawQuery("SELECT observation_id,table_size,k_played,signature FROM local_round_observations WHERE state='UPCOMING' ORDER BY CASE WHEN date_min=? THEN 0 ELSE 1 END,date_min LIMIT 100",new String[]{today()})){while(c.moveToNext()){Upcoming u=new Upcoming();u.id=c.getString(0);u.tableSize=c.getInt(1);u.k=c.isNull(2)?null:c.getInt(2);u.signature=c.getString(3);xs.add(u);}}
        for(Upcoming u:xs){DbHelper.AnalysisResult r=helper.analyzeAuto(u.tableSize,u.k,u.signature);Map<String,String>labels=teamLabelsForObservation(db,u.id);String summary="Full-Round Treffer – mit K: "+r.directedWithK.size()+" | ohne K: "+r.directedAnyK.size()+" | unordered: "+r.unorderedAnyK.size()+"\n"+automaticGameSummary(r,labels);ContentValues v=new ContentValues();v.put("observation_id",u.id);v.put("generated_at",now());v.put("directed_with_k_n",r.directedWithK.size());v.put("directed_any_k_n",r.directedAnyK.size());v.put("unordered_any_k_n",r.unorderedAnyK.size());v.put("summary",summary);db.insertWithOnConflict("research_comparisons",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    }

    private Map<String,String>teamLabelsForObservation(SQLiteDatabase db,String observationId){Map<String,String>out=new HashMap<>();String sql="SELECT g.home_rank,g.away_rank,f.home_team,f.away_team FROM local_round_games g JOIN research_fixtures f ON f.event_id=g.event_id WHERE g.observation_id=?";try(Cursor c=db.rawQuery(sql,new String[]{observationId})){while(c.moveToNext()){String pair=c.getInt(0)+"->"+c.getInt(1);String h=c.getString(2),a=c.getString(3);out.put(pair,(h==null?"?":h)+" – "+(a==null?"?":a));}}return out;}
    private String automaticGameSummary(DbHelper.AnalysisResult r,Map<String,String>labels){List<DbHelper.PairSummary>a=r.pairSummaries.get("directed_with_k"),b=r.pairSummaries.get("directed_any_k"),c=r.pairSummaries.get("unordered_any_k_direction_checked");Map<String,DbHelper.PairSummary>ma=pairMap(a),mb=pairMap(b),mc=pairMap(c);StringBuilder sb=new StringBuilder();for(String pair:SignatureUtil.splitPairs(r.directedSignature)){DbHelper.PairSummary x=ma.get(pair),y=mb.get(pair),z=mc.get(pair);sb.append(labels.containsKey(pair)?labels.get(pair):pair).append(" | ").append(pair).append(" | mit K ").append(pairCell(x)).append(" | ohne K ").append(pairCell(y)).append(" | unordered ").append(pairCell(z)).append('\n');}return sb.toString();}
    private Map<String,DbHelper.PairSummary>pairMap(List<DbHelper.PairSummary>xs){Map<String,DbHelper.PairSummary>m=new HashMap<>();if(xs!=null)for(DbHelper.PairSummary x:xs)m.put(x.pair,x);return m;}
    private String pairCell(DbHelper.PairSummary p){return p==null?"NO_SIGNAL":"N"+p.n+" "+p.one+"-"+p.draw+"-"+p.two+" => "+p.market();}
    public ResearchDb.DashboardStats dashboard() throws Exception {SQLiteDatabase db=helper.open();ResearchDb.ensureSchema(db);return ResearchDb.dashboard(db);}public List<String>recentComparisons()throws Exception{SQLiteDatabase db=helper.open();ResearchDb.ensureSchema(db);return ResearchDb.recentComparisonSummaries(db,30);}

    public static String now(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    public static String today(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}
    private static String safe(String x){return x==null?"":x;}
    private static String sha256(String text)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[]d=md.digest(text.getBytes(StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();for(byte b:d)sb.append(String.format(Locale.US,"%02x",b&255));return sb.toString();}

    public static final class SyncStats {
        public int countriesDiscovered,countriesCrawled,leaguesDiscovered,leaguesSynced,fixturesUpserted,snapshotsAdded,observationsAdded,observationsCompleted,todayFixtures,todayLeaguesFound,todayLeaguesDeepSynced,todayLeaguesPending,seasonsQueued,backfillsProcessed,historicalRoundsAdded,duplicatesSkipped;
        public String describe(){return "Heute: "+todayFixtures+" Spiele / "+todayLeaguesFound+" Ligen gefunden, tief geprüft: "+todayLeaguesDeepSynced+(todayLeaguesPending>0?" ("+todayLeaguesPending+" offen)":"")+"; Katalog: "+countriesCrawled+" Länder, "+leaguesDiscovered+" Liga-Einträge; Historie: "+backfillsProcessed+" Saison-Backfills, +"+historicalRoundsAdded+" neue Full-Rounds, "+duplicatesSkipped+" Duplikate übersprungen; aktuelle Prematch-Runden: +"+observationsAdded+", abgeschlossen: +"+observationsCompleted;}
    }
    private static final class FixtureRow{String eventId,round,date,homeId,awayId;Integer homeScore,awayScore;}
    private static final class PairGame{String eventId,homeId,awayId;int homeRank,awayRank;}
    private static final class CompletedGame{int hr,ar,hs,as;}
    private static final class Upcoming{String id,signature;int tableSize;Integer k;}
    private static final class TeamStat{String id,name;int played,wins,draws,losses,gf,ga,points;}
    private static final class HistoricalPair{SportsDbClient.Event event;int hr,ar;}
    private static final class BackfillResult{int added,duplicates;boolean complete;}
}
