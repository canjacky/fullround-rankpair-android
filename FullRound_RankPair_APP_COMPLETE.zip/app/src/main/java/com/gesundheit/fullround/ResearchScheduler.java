package com.gesundheit.fullround;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

public final class ResearchScheduler {
    private static final int JOB_ID=827431;
    private ResearchScheduler(){}
    public static void ensureScheduled(Context context){
        JobScheduler js=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return;
        JobInfo info=new JobInfo.Builder(JOB_ID,new ComponentName(context,ResearchJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(6L*60L*60L*1000L)
                .build();
        js.schedule(info);
    }
}
