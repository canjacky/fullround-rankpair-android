package com.gesundheit.fullround;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText tableSizeInput;
    private EditText kInput;
    private EditText signatureInput;
    private EditText teamNamesInput;
    private TextView output;
    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DbHelper(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("FullRound Rankpair Suche");
        title.setTextSize(22);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("System: letzter kompletter Spieltag = K; Ziel = K+1. " +
                "Directed mit K, danach directed ohne K. Unordered ohne K nur Diagnose. " +
                "Home/Away wird nie gedreht. Max-2-Filter gilt pro Rangpaar.");
        help.setTextSize(14);
        help.setPadding(0, 0, 0, dp(10));
        root.addView(help);

        tableSizeInput = new EditText(this);
        tableSizeInput.setHint("Teamzahl, z. B. 10");
        tableSizeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        tableSizeInput.setText("10");
        root.addView(tableSizeInput);

        kInput = new EditText(this);
        kInput.setHint("K = letzter vollständig beendeter Spieltag, z. B. 4");
        kInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        root.addView(kInput);

        signatureInput = new EditText(this);
        signatureInput.setHint("Komplette gerichtete Runde, z. B. 2->6|4->7|5->1|8->3|10->9");
        signatureInput.setMinLines(3);
        signatureInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(signatureInput);

        teamNamesInput = new EditText(this);
        teamNamesInput.setHint("Optional: Teamnamen je Spiel in derselben Eingabereihenfolge, eine Zeile pro Spiel");
        teamNamesInput.setMinLines(3);
        teamNamesInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(teamNamesInput);

        Button sample = new Button(this);
        sample.setText("Beispiel Scottish Championship laden");
        sample.setAllCaps(false);
        sample.setOnClickListener(v -> {
            tableSizeInput.setText("10");
            kInput.setText("4");
            // Deliberately unsorted input: app must canonicalize it automatically.
            signatureInput.setText("10->9|5->1|2->6|8->3|4->7");
            teamNamesInput.setText(
                    "Queen's Park – Greenock Morton\n" +
                    "Livingston – Stenhousemuir\n" +
                    "Partick Thistle – Ayr United\n" +
                    "Inverness CT – Raith Rovers\n" +
                    "Arbroath – Dunfermline Athletic");
        });
        root.addView(sample);

        Button analyze = new Button(this);
        analyze.setText("Full-Round suchen");
        analyze.setAllCaps(false);
        analyze.setOnClickListener(this::runAnalysis);
        root.addView(analyze);

        output = new TextView(this);
        output.setTextSize(13);
        output.setTextIsSelectable(true);
        output.setPadding(0, dp(12), 0, dp(20));
        root.addView(output);

        setContentView(scroll);
    }

    private void runAnalysis(View view) {
        try {
            int tableSize = Integer.parseInt(tableSizeInput.getText().toString().trim());
            String kRaw = kInput.getText().toString().trim();
            if (kRaw.isEmpty()) {
                throw new IllegalArgumentException("K ist Pflicht: letzter vollständig beendeter Spieltag.");
            }
            int k = Integer.parseInt(kRaw);
            String sig = signatureInput.getText().toString();
            Map<String, String> teamLabels = parseTeamLabels(sig, teamNamesInput.getText().toString());
            DbHelper.AnalysisResult r = dbHelper.analyze(tableSize, k, sig);
            output.setText(format(r, teamLabels));
        } catch (Exception e) {
            output.setText("FEHLER:\n" + e.getClass().getSimpleName() + ": " + e.getMessage() +
                    "\n\nPflicht: komplette Runde, exakt Teamzahl/2 Spiele, jeder Rang 1..Teamzahl genau einmal. " +
                    "Die Reihenfolge der Eingabe ist egal; Home/Away-Richtung bleibt unverändert.");
        }
    }

    private Map<String, String> parseTeamLabels(String signatureRaw, String labelsRaw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (labelsRaw == null || labelsRaw.trim().isEmpty()) return out;

        List<String> inputPairs = SignatureUtil.normalizedPairsPreserveOrder(signatureRaw);
        String[] rawLines = labelsRaw.replace("\r", "").split("\n");
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        for (String line : rawLines) {
            if (!line.trim().isEmpty()) lines.add(line.trim());
        }
        if (lines.size() != inputPairs.size()) {
            throw new IllegalArgumentException(
                    "Teamnamen: erwartet " + inputPairs.size() + " Zeilen, erkannt " + lines.size() + ".");
        }
        for (int i = 0; i < inputPairs.size(); i++) {
            out.put(inputPairs.get(i), lines.get(i));
        }
        return out;
    }

    private String format(DbHelper.AnalysisResult r, Map<String, String> teamLabels) {
        StringBuilder sb = new StringBuilder();
        sb.append("Zielkörper\n");
        sb.append("Teamzahl: ").append(r.tableSize).append('\n');
        sb.append("K: ").append(r.kPlayed).append('\n');
        sb.append("Zielspieltag: ").append(r.kPlayed + 1).append('\n');
        sb.append("Directed kanonisch: ").append(r.directedSignature).append('\n');
        sb.append("Unordered Diagnose: ").append(r.unorderedSignature).append("\n\n");

        appendHitBlock(sb, "1) HAUPTSUCHE: Directed Full-Round mit K", r.directedWithK);
        appendPairBlock(sb, r.pairSummaries.get("directed_with_k"), teamLabels);

        appendHitBlock(sb, "2) HAUPTSUCHE: Directed Full-Round ohne K", r.directedAnyK);
        appendPairBlock(sb, r.pairSummaries.get("directed_any_k"), teamLabels);

        appendHitBlock(sb, "3) DIAGNOSE: Unordered Full-Round ohne K; heutige Richtung je Paar separat", r.unorderedAnyK);
        appendPairBlock(sb, r.pairSummaries.get("unordered_any_k_direction_checked"), teamLabels);

        appendHitBlock(sb, "Zusatz-Audit: Unordered Full-Round mit K; keine eigene Freigabestufe", r.unorderedWithK);
        appendPairBlock(sb, r.pairSummaries.get("unordered_with_k_direction_checked"), teamLabels);

        return sb.toString();
    }

    private void appendHitBlock(StringBuilder sb, String title, List<DbHelper.RoundHit> hits) {
        sb.append(title).append('\n');
        sb.append("Full-Round Treffer: ").append(hits == null ? 0 : hits.size()).append('\n');
        if (hits != null) {
            int i = 1;
            for (DbHelper.RoundHit h : hits) {
                if (i > 10) { sb.append("... weitere Treffer nicht angezeigt\n"); break; }
                sb.append(i++).append(". ")
                        .append(h.leagueCode).append(" ").append(h.seasonKey)
                        .append(" | K").append(h.kPlayed)
                        .append(" | ").append(h.dateMin).append("-").append(h.dateMax)
                        .append("\n   ").append(h.signature)
                        .append("\n   ").append(h.resultVector).append("\n");
            }
        }
        sb.append('\n');
    }

    private void appendPairBlock(StringBuilder sb, List<DbHelper.PairSummary> pairs, Map<String, String> teamLabels) {
        sb.append("Pair-Filter: maximal 2 Ergebnisarten pro Rangpaar\n");
        sb.append("Spiel | Rangpaar | N | 1-X-2 | Kandidat\n");
        if (pairs != null) {
            for (DbHelper.PairSummary p : pairs) {
                String label = teamLabels.get(p.pair);
                if (label == null || label.trim().isEmpty()) label = "-";
                sb.append(label).append(" | ")
                        .append(p.pair).append(" | ").append(p.n).append(" | ")
                        .append(p.one).append('-').append(p.draw).append('-').append(p.two)
                        .append(" | ").append(p.market()).append('\n');
            }
        }
        sb.append('\n');
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
