package com.gesundheit.fullround;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText apiKeyInput, footballDataTokenInput, extraLeagueInput;
    private EditText tableSizeInput,kInput,signatureInput,teamNamesInput;
    private TextView status,dashboardOutput,analysisOutput;
    private ScrollView mainScroll;
    private DbHelper dbHelper;
    private volatile boolean syncing=false;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);dbHelper=new DbHelper(this);ResearchScheduler.ensureScheduled(this);
        ScrollView scroll=new ScrollView(this);mainScroll=scroll;LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);int pad=dp(14);root.setPadding(pad,pad,pad,pad);scroll.addView(root);
        addTitle(root,"FullRound Global Research",24);
        addText(root,"Die App arbeitet ausschließlich mit Full-Round-/RankPair-Körpern: heutige Soccer-Spiele aus mehreren Datenquellen finden, vollständige Prematch-Runden einfrieren, mit der lokalen Datenbank vergleichen und historische Saisons schrittweise als neue deduplizierte Full-Round-Cases rekonstruieren.",14);
        status=addText(root,"Status wird geladen …",14);

        Button sync=new Button(this);sync.setText("JETZT GLOBAL RESEARCHEN");sync.setAllCaps(false);sync.setOnClickListener(v->runResearch());root.addView(sync);
        Button refresh=new Button(this);refresh.setText("Datenbank & heutige Vergleiche anzeigen");refresh.setAllCaps(false);refresh.setOnClickListener(v->refreshDashboard(true));root.addView(refresh);
        dashboardOutput=addText(root,"Datenbank-Dashboard wird geladen …",13);dashboardOutput.setTextIsSelectable(true);dashboardOutput.setPadding(0,dp(8),0,dp(16));

        addTitle(root,"Datenquelle",18);
        addText(root,"Die App kombiniert mehrere Quellen: TheSportsDB für Länder/Ligen und Tagesdaten, OpenLigaDB ohne API-Key als zusätzliche aktuelle und historische Quelle sowie optional football-data.org mit eigenem Token. Historische OpenLigaDB-Jahrgänge werden automatisch rückwärts abgearbeitet. Jede importierte Saison muss erst den strengen COMPLETE-Full-Round-Test bestehen; unvollständige oder ungeeignete Ligen werden nicht als Vergleichsfälle gelernt.",13);
        SharedPreferences prefs=getSharedPreferences("research",Context.MODE_PRIVATE);
        apiKeyInput=new EditText(this);apiKeyInput.setHint("TheSportsDB API-Key (Standard 123)");apiKeyInput.setText(prefs.getString("sportsdb_key","123"));apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT);root.addView(apiKeyInput);
        footballDataTokenInput=new EditText(this);footballDataTokenInput.setHint("Optional: football-data.org Token");footballDataTokenInput.setText(prefs.getString("football_data_token",""));footballDataTokenInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);root.addView(footballDataTokenInput);
        extraLeagueInput=new EditText(this);extraLeagueInput.setHint("Optional: zusätzliche TheSportsDB League-IDs");extraLeagueInput.setText(prefs.getString("extra_league_ids",""));extraLeagueInput.setInputType(InputType.TYPE_CLASS_TEXT);root.addView(extraLeagueInput);
        Button save=new Button(this);save.setText("Research-Einstellungen speichern");save.setAllCaps(false);save.setOnClickListener(v->{prefs.edit().putString("sportsdb_key",apiKeyInput.getText().toString().trim()).putString("football_data_token",footballDataTokenInput.getText().toString().trim()).putString("extra_league_ids",extraLeagueInput.getText().toString().trim()).apply();status.setText("Einstellungen gespeichert. Globaler Autosync läuft alle 6 Stunden.");});root.addView(save);

        addTitle(root,"Manuelle Full-Round-Suche",18);
        addText(root,"Kontrollmodus für einen bereits bekannten Full-Round-Körper. Die Suche nutzt die eingebaute Basis plus alle von der App historisch oder live neu gelernten COMPLETE-Cases.",13);
        tableSizeInput=new EditText(this);tableSizeInput.setHint("Teamzahl, z. B. 10");tableSizeInput.setInputType(InputType.TYPE_CLASS_NUMBER);tableSizeInput.setText("10");root.addView(tableSizeInput);
        kInput=new EditText(this);kInput.setHint("K = letzter vollständig beendeter Spieltag");kInput.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(kInput);
        signatureInput=new EditText(this);signatureInput.setHint("Komplette gerichtete Runde, z. B. 2->6|4->7|5->1|8->3|10->9");signatureInput.setMinLines(3);signatureInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);root.addView(signatureInput);
        teamNamesInput=new EditText(this);teamNamesInput.setHint("Optional: Teamnamen je Spiel, eine Zeile pro Spiel");teamNamesInput.setMinLines(3);teamNamesInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);root.addView(teamNamesInput);
        Button analyze=new Button(this);analyze.setText("Full-Round vergleichen");analyze.setAllCaps(false);analyze.setOnClickListener(this::runAnalysis);root.addView(analyze);
        analysisOutput=addText(root,"",13);analysisOutput.setTextIsSelectable(true);analysisOutput.setPadding(0,dp(12),0,dp(20));setContentView(scroll);refreshDashboard(false);maybeInitialResearch();
    }

    private void maybeInitialResearch(){SharedPreferences p=getSharedPreferences("research",Context.MODE_PRIVATE);if(!p.getBoolean("initial_global_sync_started",false)){p.edit().putBoolean("initial_global_sync_started",true).apply();runResearch();}}

    private void runResearch(){
        if(syncing){status.setText("Research läuft bereits …");return;}syncing=true;status.setText("Global Research startet …");
        new Thread(()->{try{ResearchEngine engine=new ResearchEngine(getApplicationContext());ResearchEngine.SyncStats st=engine.runFullSync(text->runOnUiThread(()->status.setText(text)));runOnUiThread(()->{syncing=false;status.setText("Research fertig. "+st.describe());refreshDashboard(false);});}catch(Exception e){runOnUiThread(()->{syncing=false;status.setText("Research-Fehler: "+e.getMessage()+"\nDer nächste Autosync versucht es erneut.");refreshDashboard(false);});}},"manual-global-research").start();
    }

    private void refreshDashboard(boolean focus){
        if(focus){dashboardOutput.setText("Datenbank & heutige Vergleiche werden geladen …");scrollToDashboard();}
        new Thread(()->{try{ResearchEngine e=new ResearchEngine(getApplicationContext());ResearchDb.DashboardStats d=e.dashboard();List<String>comps=e.recentComparisons();StringBuilder sb=new StringBuilder();
            sb.append("GLOBAL AUTO-DATENBANK\n")
                    .append("Full-Round-Cases gesamt: ").append(d.historicalRounds).append("\n")
                    .append("  Eingebaute Basis: ").append(d.baseHistoricalRounds).append(" | selbst gelernt: ").append(d.localHistoricalRounds).append("\n")
                    .append("Katalog-Einträge Soccer: ").append(d.leagues).append(" | Länder im TheSportsDB-Crawl: ").append(d.countries).append("\n")
                    .append("  TheSportsDB: ").append(d.leaguesSportsDb).append(" | OpenLigaDB: ").append(d.leaguesOpenLigaDb).append(" | football-data.org: ").append(d.leaguesFootballData).append("\n")
                    .append("Heutige Events lokal: ").append(d.todayFixtures).append(" Spiele in ").append(d.todayLeagues).append(" Ligen\n")
                    .append("Fixtures lokal: ").append(d.fixtures).append(" | Tabellen-Snapshots: ").append(d.snapshots).append("\n")
                    .append("Prematch Full-Rounds offen: ").append(d.upcomingRounds).append("\n")
                    .append("Historische Backfill-Saisons: ").append(d.backfillDone).append(" fertig | ").append(d.backfillPending).append(" offen/teilweise\n")
                    .append("Letzter Sync: ").append(d.lastSync==null?"noch keiner":d.lastSync).append(" | ").append(d.lastStatus==null?"-":d.lastStatus).append('\n');
            if(d.lastMessage!=null)sb.append(d.lastMessage).append('\n');sb.append("\nHEUTIGE / KOMMENDE AUTOMATISCHE VERGLEICHE\n");if(comps.isEmpty())sb.append("Noch keine vollständige Prematch-Runde mit sicherem Tabellen-Freeze gefunden. Gefundene Tages-Events bleiben im lokalen Fixture-Speicher und werden bei späteren Syncs erneut geprüft.\n");else for(String x:comps)sb.append("\n").append(x).append("\n");runOnUiThread(()->{dashboardOutput.setText(sb.toString());if(focus)scrollToDashboard();});}catch(Exception ex){runOnUiThread(()->{String msg="DB-Fehler: "+ex.getMessage();status.setText(msg);dashboardOutput.setText(msg+"\n\nDie App versucht bei einem beschädigten lokalen DB-Abbild automatisch eine frische Basis zu installieren.");if(focus)scrollToDashboard();});}},"dashboard").start();
    }

    private void runAnalysis(View view){try{int tableSize=Integer.parseInt(tableSizeInput.getText().toString().trim());String kRaw=kInput.getText().toString().trim();if(kRaw.isEmpty())throw new IllegalArgumentException("K ist Pflicht im manuellen Modus.");int k=Integer.parseInt(kRaw);String sig=signatureInput.getText().toString();Map<String,String>labels=parseTeamLabels(sig,teamNamesInput.getText().toString());DbHelper.AnalysisResult r=dbHelper.analyze(tableSize,k,sig);analysisOutput.setText(format(r,labels));scrollToAnalysis();}catch(Exception e){analysisOutput.setText("FEHLER:\n"+e.getClass().getSimpleName()+": "+e.getMessage());scrollToAnalysis();}}
    private Map<String,String> parseTeamLabels(String signatureRaw,String labelsRaw){Map<String,String>out=new LinkedHashMap<>();if(labelsRaw==null||labelsRaw.trim().isEmpty())return out;List<String>inputPairs=SignatureUtil.normalizedPairsPreserveOrder(signatureRaw);String[]rawLines=labelsRaw.replace("\r","").split("\n");java.util.ArrayList<String>lines=new java.util.ArrayList<>();for(String line:rawLines)if(!line.trim().isEmpty())lines.add(line.trim());if(lines.size()!=inputPairs.size())throw new IllegalArgumentException("Teamnamen: erwartet "+inputPairs.size()+" Zeilen, erkannt "+lines.size()+".");for(int i=0;i<inputPairs.size();i++)out.put(inputPairs.get(i),lines.get(i));return out;}
    private String format(DbHelper.AnalysisResult r,Map<String,String>teamLabels){StringBuilder sb=new StringBuilder();sb.append("Zielkörper\nTeamzahl: ").append(r.tableSize).append('\n').append("K: ").append(r.kPlayed).append('\n').append("Directed kanonisch: ").append(r.directedSignature).append("\n\n");appendHitBlock(sb,"1) Directed Full-Round mit K",r.directedWithK);appendPairBlock(sb,r.pairSummaries.get("directed_with_k"),teamLabels);appendHitBlock(sb,"2) Directed Full-Round ohne K",r.directedAnyK);appendPairBlock(sb,r.pairSummaries.get("directed_any_k"),teamLabels);appendHitBlock(sb,"3) Unordered Diagnose ohne K",r.unorderedAnyK);appendPairBlock(sb,r.pairSummaries.get("unordered_any_k_direction_checked"),teamLabels);return sb.toString();}
    private void appendHitBlock(StringBuilder sb,String title,List<DbHelper.RoundHit>hits){sb.append(title).append("\nFull-Round Treffer: ").append(hits==null?0:hits.size()).append('\n');if(hits!=null){int i=1;for(DbHelper.RoundHit h:hits){if(i>12){sb.append("... weitere Treffer\n");break;}sb.append(i++).append(". ").append(h.leagueCode).append(' ').append(h.seasonKey).append(" | K").append(h.kPlayed).append(" | ").append(h.dateMin).append(" - ").append(h.dateMax).append(h.localResearch?" | AUTO-RESEARCH":"").append("\n   ").append(h.signature).append("\n   ").append(h.resultVector).append('\n');}}sb.append('\n');}
    private void appendPairBlock(StringBuilder sb,List<DbHelper.PairSummary>pairs,Map<String,String>labels){sb.append("Spiel | Rangpaar | N | 1-X-2 | Kandidat\n");if(pairs!=null)for(DbHelper.PairSummary p:pairs){String label=labels.get(p.pair);if(label==null||label.trim().isEmpty())label="-";sb.append(label).append(" | ").append(p.pair).append(" | ").append(p.n).append(" | ").append(p.one).append('-').append(p.draw).append('-').append(p.two).append(" | ").append(p.market()).append('\n');}sb.append('\n');}
    private void scrollToDashboard(){if(mainScroll==null||dashboardOutput==null)return;mainScroll.post(()->mainScroll.smoothScrollTo(0,Math.max(0,dashboardOutput.getTop()-dp(8))));}
    private void scrollToAnalysis(){if(mainScroll==null||analysisOutput==null)return;mainScroll.post(()->mainScroll.smoothScrollTo(0,Math.max(0,analysisOutput.getTop()-dp(8))));}
    private TextView addText(LinearLayout root,String text,int size){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setPadding(0,0,0,dp(8));root.addView(v);return v;}
    private void addTitle(LinearLayout root,String text,int size){TextView v=addText(root,text,size);v.setPadding(0,dp(8),0,dp(8));}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
