package com.gesundheit.fullround;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText apiKeyInput, footballDataTokenInput, extraLeagueInput;
    private EditText tableSizeInput,kInput,signatureInput,teamNamesInput;
    private TextView status,output;
    private DbHelper dbHelper;
    private volatile boolean syncing=false;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);dbHelper=new DbHelper(this);ResearchScheduler.ensureScheduled(this);
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);int pad=dp(14);root.setPadding(pad,pad,pad,pad);scroll.addView(root);
        addTitle(root,"FullRound Auto Research",24);
        addText(root,"Automatik: Fixtures + Tabellen abrufen → lokale SQLite fortschreiben → vollständige Prematch-Runden einfrieren → nach Abschluss als neue historische Cases übernehmen → Vergleichsspiele automatisch suchen.",14);
        status=addText(root,"Status wird geladen …",14);

        Button sync=new Button(this);sync.setText("JETZT AUTOMATISCH RESEARCHEN");sync.setAllCaps(false);sync.setOnClickListener(v->runResearch());root.addView(sync);
        Button refresh=new Button(this);refresh.setText("Datenbank & Vergleiche anzeigen");refresh.setAllCaps(false);refresh.setOnClickListener(v->refreshDashboard());root.addView(refresh);

        addTitle(root,"Datenquelle",18);
        addText(root,"Standard läuft sofort mit TheSportsDB Free-Key 123. Für vollständige Spielpläne + Tabellen kann zusätzlich ein football-data.org Token eingetragen werden; die App synchronisiert dann automatisch die dort freigeschalteten Wettbewerbe. Data provided by football-data.org.",13);
        SharedPreferences prefs=getSharedPreferences("research",Context.MODE_PRIVATE);
        apiKeyInput=new EditText(this);apiKeyInput.setHint("TheSportsDB API-Key (Standard 123)");apiKeyInput.setText(prefs.getString("sportsdb_key","123"));apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT);root.addView(apiKeyInput);
        footballDataTokenInput=new EditText(this);footballDataTokenInput.setHint("Optional: football-data.org Token (empfohlen für Full-Round-Automatik)");footballDataTokenInput.setText(prefs.getString("football_data_token",""));footballDataTokenInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);root.addView(footballDataTokenInput);
        extraLeagueInput=new EditText(this);extraLeagueInput.setHint("Optionale zusätzliche League-IDs, z. B. 4684,4802");extraLeagueInput.setText(prefs.getString("extra_league_ids",""));extraLeagueInput.setInputType(InputType.TYPE_CLASS_TEXT);root.addView(extraLeagueInput);
        Button save=new Button(this);save.setText("Research-Einstellungen speichern");save.setAllCaps(false);save.setOnClickListener(v->{prefs.edit().putString("sportsdb_key",apiKeyInput.getText().toString().trim()).putString("football_data_token",footballDataTokenInput.getText().toString().trim()).putString("extra_league_ids",extraLeagueInput.getText().toString().trim()).apply();status.setText("Einstellungen gespeichert. Autosync läuft alle 6 Stunden.");});root.addView(save);

        addTitle(root,"Manuelle Full-Round-Suche",18);
        addText(root,"Die manuelle Suche bleibt als Kontrollmodus erhalten. Automatisch erzeugte, später abgeschlossene Prematch-Cases werden zusätzlich zum eingebauten historischen Bestand durchsucht.",13);
        tableSizeInput=new EditText(this);tableSizeInput.setHint("Teamzahl, z. B. 10");tableSizeInput.setInputType(InputType.TYPE_CLASS_NUMBER);tableSizeInput.setText("10");root.addView(tableSizeInput);
        kInput=new EditText(this);kInput.setHint("K = letzter vollständig beendeter Spieltag");kInput.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(kInput);
        signatureInput=new EditText(this);signatureInput.setHint("Komplette gerichtete Runde, z. B. 2->6|4->7|5->1|8->3|10->9");signatureInput.setMinLines(3);signatureInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);root.addView(signatureInput);
        teamNamesInput=new EditText(this);teamNamesInput.setHint("Optional: Teamnamen je Spiel, eine Zeile pro Spiel");teamNamesInput.setMinLines(3);teamNamesInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);root.addView(teamNamesInput);
        Button analyze=new Button(this);analyze.setText("Full-Round vergleichen");analyze.setAllCaps(false);analyze.setOnClickListener(this::runAnalysis);root.addView(analyze);
        output=addText(root,"",13);output.setTextIsSelectable(true);output.setPadding(0,dp(12),0,dp(20));
        setContentView(scroll);
        refreshDashboard();
        maybeInitialResearch();
    }

    private void maybeInitialResearch(){
        SharedPreferences p=getSharedPreferences("research",Context.MODE_PRIVATE);if(!p.getBoolean("initial_sync_started",false)){p.edit().putBoolean("initial_sync_started",true).apply();runResearch();}
    }

    private void runResearch(){
        if(syncing){status.setText("Research läuft bereits …");return;}syncing=true;status.setText("Research startet …");
        new Thread(()->{
            try{
                ResearchEngine engine=new ResearchEngine(getApplicationContext());
                ResearchEngine.SyncStats st=engine.runFullSync(text->runOnUiThread(()->status.setText(text)));
                runOnUiThread(()->{syncing=false;status.setText("Research fertig. "+st.describe());refreshDashboard();});
            }catch(Exception e){runOnUiThread(()->{syncing=false;status.setText("Research-Fehler: "+e.getMessage()+"\nDer nächste Autosync versucht es erneut.");refreshDashboard();});}
        },"manual-auto-research").start();
    }

    private void refreshDashboard(){
        new Thread(()->{
            try{
                ResearchEngine e=new ResearchEngine(getApplicationContext());ResearchDb.DashboardStats d=e.dashboard();List<String> comps=e.recentComparisons();
                StringBuilder sb=new StringBuilder();sb.append("AUTO-DATENBANK\n").append("Historische Full-Round-Cases: ").append(d.historicalRounds).append("\n").append("Ligen: ").append(d.leagues).append(" | Fixtures: ").append(d.fixtures).append(" | Tabellen-Snapshots: ").append(d.snapshots).append('\n').append("Kommende eingefrorene Full-Rounds: ").append(d.upcomingRounds).append(" | Neu abgeschlossene eigene Cases: ").append(d.completedRounds).append('\n').append("Letzter Sync: ").append(d.lastSync==null?"noch keiner":d.lastSync).append(" | ").append(d.lastStatus==null?"-":d.lastStatus).append('\n');
                if(d.lastMessage!=null)sb.append(d.lastMessage).append('\n');sb.append("\nAUTOMATISCH GEFUNDENE VERGLEICHE\n");if(comps.isEmpty())sb.append("Noch keine kommende vollständige Runde mit sicherem Prematch-Freeze gefunden.\n");else for(String x:comps)sb.append("\n").append(x).append("\n");
                runOnUiThread(()->output.setText(sb.toString()));
            }catch(Exception ex){runOnUiThread(()->output.setText("DB-Fehler: "+ex.getMessage()));}
        },"dashboard").start();
    }

    private void runAnalysis(View view){
        try{int tableSize=Integer.parseInt(tableSizeInput.getText().toString().trim());String kRaw=kInput.getText().toString().trim();if(kRaw.isEmpty())throw new IllegalArgumentException("K ist Pflicht im manuellen Modus.");int k=Integer.parseInt(kRaw);String sig=signatureInput.getText().toString();Map<String,String>labels=parseTeamLabels(sig,teamNamesInput.getText().toString());DbHelper.AnalysisResult r=dbHelper.analyze(tableSize,k,sig);output.setText(format(r,labels));}catch(Exception e){output.setText("FEHLER:\n"+e.getClass().getSimpleName()+": "+e.getMessage());}
    }

    private Map<String,String> parseTeamLabels(String signatureRaw,String labelsRaw){Map<String,String>out=new LinkedHashMap<>();if(labelsRaw==null||labelsRaw.trim().isEmpty())return out;List<String>inputPairs=SignatureUtil.normalizedPairsPreserveOrder(signatureRaw);String[]rawLines=labelsRaw.replace("\r","").split("\n");java.util.ArrayList<String>lines=new java.util.ArrayList<>();for(String line:rawLines)if(!line.trim().isEmpty())lines.add(line.trim());if(lines.size()!=inputPairs.size())throw new IllegalArgumentException("Teamnamen: erwartet "+inputPairs.size()+" Zeilen, erkannt "+lines.size()+".");for(int i=0;i<inputPairs.size();i++)out.put(inputPairs.get(i),lines.get(i));return out;}

    private String format(DbHelper.AnalysisResult r,Map<String,String>teamLabels){StringBuilder sb=new StringBuilder();sb.append("Zielkörper\nTeamzahl: ").append(r.tableSize).append('\n').append("K: ").append(r.kPlayed).append('\n').append("Directed kanonisch: ").append(r.directedSignature).append("\n\n");appendHitBlock(sb,"1) Directed Full-Round mit K",r.directedWithK);appendPairBlock(sb,r.pairSummaries.get("directed_with_k"),teamLabels);appendHitBlock(sb,"2) Directed Full-Round ohne K",r.directedAnyK);appendPairBlock(sb,r.pairSummaries.get("directed_any_k"),teamLabels);appendHitBlock(sb,"3) Unordered Diagnose ohne K",r.unorderedAnyK);appendPairBlock(sb,r.pairSummaries.get("unordered_any_k_direction_checked"),teamLabels);return sb.toString();}
    private void appendHitBlock(StringBuilder sb,String title,List<DbHelper.RoundHit>hits){sb.append(title).append("\nFull-Round Treffer: ").append(hits==null?0:hits.size()).append('\n');if(hits!=null){int i=1;for(DbHelper.RoundHit h:hits){if(i>12){sb.append("... weitere Treffer\n");break;}sb.append(i++).append(". ").append(h.leagueCode).append(' ').append(h.seasonKey).append(" | K").append(h.kPlayed).append(" | ").append(h.dateMin).append(" - ").append(h.dateMax).append(h.localResearch?" | AUTO-RESEARCH":"").append("\n   ").append(h.signature).append("\n   ").append(h.resultVector).append('\n');}}sb.append('\n');}
    private void appendPairBlock(StringBuilder sb,List<DbHelper.PairSummary>pairs,Map<String,String>labels){sb.append("Spiel | Rangpaar | N | 1-X-2 | Kandidat\n");if(pairs!=null)for(DbHelper.PairSummary p:pairs){String label=labels.get(p.pair);if(label==null||label.trim().isEmpty())label="-";sb.append(label).append(" | ").append(p.pair).append(" | ").append(p.n).append(" | ").append(p.one).append('-').append(p.draw).append('-').append(p.two).append(" | ").append(p.market()).append('\n');}sb.append('\n');}

    private TextView addText(LinearLayout root,String text,int size){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setPadding(0,0,0,dp(8));root.addView(v);return v;}
    private void addTitle(LinearLayout root,String text,int size){TextView v=addText(root,text,size);v.setPadding(0,dp(8),0,dp(8));}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
