#!/usr/bin/env python3
"""Offline CLI for the Full-Round Rankpair SQLite app index.

System:
  1) directed Full-Round + K exact
  2) directed Full-Round without K exact
  3) unordered Full-Round without K = diagnostic only; current pair direction must still exist historically
  4) no standalone single-rankpair fallback

Example:
  python tools/search_fullround.py \
    --db app/src/main/assets/fullround_rankpair_app_v3.sqlite \
    --table-size 10 --k 4 \
    --signature '10->9|5->1|2->6|8->3|4->7'
"""
import argparse
import re
import sqlite3
from collections import OrderedDict

PAIR_RE = re.compile(r"^(\d+)\s*(?:->|→|=>|-)\s*(\d+)$")


def parse_pairs_preserve_order(raw: str):
    if not raw or not raw.strip():
        raise ValueError("Full-Round-Signatur fehlt")
    text = raw.replace(";", "|").replace(",", "|").replace("\r", "|").replace("\n", "|")
    pairs = []
    for part in text.split("|"):
        p = part.strip()
        if not p:
            continue
        m = PAIR_RE.fullmatch(p)
        if not m:
            raise ValueError(f"Ungültiges Rangpaar: {p!r}; erwartet z. B. 2->6")
        h, a = map(int, m.groups())
        pairs.append((h, a))
    if not pairs:
        raise ValueError("Keine Rangpaare erkannt")
    return pairs


def normalize_and_validate_directed(raw: str, table_size: int) -> str:
    if table_size < 2 or table_size % 2:
        raise ValueError("Teamzahl muss eine gerade Zahl >= 2 sein")
    pairs = parse_pairs_preserve_order(raw)
    expected = table_size // 2
    if len(pairs) != expected:
        raise ValueError(f"Unvollständige Full-Round: erwartet {expected} Spiele, erkannt {len(pairs)}")

    seen = set()
    for h, a in pairs:
        if not (1 <= h <= table_size and 1 <= a <= table_size):
            raise ValueError(f"Rang außerhalb 1..{table_size}: {h}->{a}")
        if h == a:
            raise ValueError(f"Identischer Home/Away-Rang: {h}->{a}")
        for r in (h, a):
            if r in seen:
                raise ValueError(f"Rang {r} kommt mehrfach in der Runde vor")
            seen.add(r)
    if seen != set(range(1, table_size + 1)):
        missing = sorted(set(range(1, table_size + 1)) - seen)
        raise ValueError(f"Full-Round ungültig; fehlende Ränge: {missing}")

    # Canonical DB order: sort the LIST by home rank. Never reverse pair direction.
    pairs.sort(key=lambda x: (x[0], x[1]))
    return "|".join(f"{h}->{a}" for h, a in pairs)


def unordered_signature(directed: str) -> str:
    out = []
    for p in directed.split("|"):
        a, b = map(int, p.split("->"))
        lo, hi = sorted((a, b))
        out.append((lo, hi))
    out.sort()
    return "|".join(f"{lo}-{hi}" for lo, hi in out)


def parse_result_vector(rv: str) -> dict:
    out = {}
    for item in (rv or "").split("|"):
        if ":" not in item:
            continue
        pair, result = item.split(":", 1)
        out[pair.strip()] = result.strip()
    return out


def query(conn, sql, params):
    cur = conn.execute(sql, params)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


def summarize_pairs(target_pairs, hits):
    summary = OrderedDict((p, {"N": 0, "1": 0, "X": 0, "2": 0}) for p in target_pairs)
    for hit in hits:
        rv = parse_result_vector(hit.get("result_vector", ""))
        for p in target_pairs:
            r = rv.get(p)
            if not r:
                continue  # direction mismatch; never flip
            summary[p]["N"] += 1
            if r in ("1", "X", "2"):
                summary[p][r] += 1
    return summary


def market(s):
    present = [k for k in ("1", "X", "2") if s[k] > 0]
    if s["N"] == 0:
        return "NO_SIGNAL"
    if len(present) == 3:
        return "RAUS: 1/X/2"
    if present == ["1", "X"]:
        return "1X"
    if present == ["X", "2"]:
        return "X2"
    if present == ["1", "2"]:
        return "12"
    if present == ["1"]:
        base = "1 / 1X"
    elif present == ["X"]:
        base = "X only, vorsichtig"
    elif present == ["2"]:
        base = "2 / X2"
    else:
        return "NO_SIGNAL"
    return base + (", Low-N" if s["N"] == 1 else "")
    return "NO_SIGNAL"


def print_block(name, target_pairs, hits):
    print(f"\n## {name}")
    print(f"Full-Round hits: {len(hits)}")
    for i, h in enumerate(hits[:10], 1):
        print(f"{i}. {h.get('league_code')} {h.get('season_key')} | K{h.get('k_played')} | {h.get('date_min')}-{h.get('date_max')}")
        sig = h.get("signature") or h.get("directed_signature")
        print(f"   {sig}")
        print(f"   {h.get('result_vector')}")
    if len(hits) > 10:
        print(f"... {len(hits)-10} more")
    print("\nPair filter (current direction only):")
    print("pair,N,1,X,2,market")
    for p, s in summarize_pairs(target_pairs, hits).items():
        print(f"{p},{s['N']},{s['1']},{s['X']},{s['2']},{market(s)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--table-size", type=int, required=True)
    ap.add_argument("--k", type=int, required=True, help="last fully completed round K")
    ap.add_argument("--signature", required=True)
    args = ap.parse_args()

    if args.k < 0:
        raise SystemExit("K darf nicht negativ sein")

    directed = normalize_and_validate_directed(args.signature, args.table_size)
    unordered = unordered_signature(directed)
    pairs = directed.split("|")

    conn = sqlite3.connect(args.db)
    conn.row_factory = sqlite3.Row
    qc = conn.execute("PRAGMA quick_check").fetchone()[0]
    if qc != "ok":
        raise SystemExit(f"DB quick_check failed: {qc}")

    print("Target")
    print(f"table_size={args.table_size}")
    print(f"k={args.k}")
    print(f"target_round={args.k + 1}")
    print(f"directed_canonical={directed}")
    print(f"unordered={unordered}")

    directed_k = query(conn,
        "SELECT * FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?",
        (args.table_size, args.k, directed))
    directed_any = query(conn,
        "SELECT * FROM round_signatures WHERE table_size=? AND signature=?",
        (args.table_size, directed))
    unordered_any = query(conn,
        "SELECT * FROM round_signatures_unordered WHERE table_size=? AND unordered_signature=?",
        (args.table_size, unordered))
    unordered_k = query(conn,
        "SELECT * FROM round_signatures_unordered WHERE table_size=? AND k_played=? AND unordered_signature=?",
        (args.table_size, args.k, unordered))

    print_block("1 MAIN: Directed with K", pairs, directed_k)
    print_block("2 MAIN: Directed without K", pairs, directed_any)
    print_block("3 DIAGNOSTIC: Unordered without K, direction checked per pair", pairs, unordered_any)
    print_block("EXTRA AUDIT: Unordered with K, not a release level", pairs, unordered_k)


if __name__ == "__main__":
    main()
