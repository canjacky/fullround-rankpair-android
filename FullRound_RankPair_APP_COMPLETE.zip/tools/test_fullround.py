#!/usr/bin/env python3
import sqlite3
import sys
from search_fullround import normalize_and_validate_directed, unordered_signature, summarize_pairs


def require(cond, msg):
    if not cond:
        raise AssertionError(msg)


def rows(conn, sql, params):
    cur = conn.execute(sql, params)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def main(db):
    conn = sqlite3.connect(db)

    # Scottish example: input order must not matter.
    raw_unsorted = "10->9|5->1|2->6|8->3|4->7"
    directed = normalize_and_validate_directed(raw_unsorted, 10)
    require(directed == "2->6|4->7|5->1|8->3|10->9", directed)
    unordered = unordered_signature(directed)

    directed_k = rows(conn,
        "SELECT * FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?",
        (10, 4, directed))
    directed_any = rows(conn,
        "SELECT * FROM round_signatures WHERE table_size=? AND signature=?",
        (10, directed))
    unordered_any = rows(conn,
        "SELECT * FROM round_signatures_unordered WHERE table_size=? AND unordered_signature=?",
        (10, unordered))

    require(len(directed_k) == 0, f"expected Scottish directed+K=0, got {len(directed_k)}")
    require(len(directed_any) == 0, f"expected Scottish directed anyK=0, got {len(directed_any)}")
    require(len(unordered_any) == 2, f"expected Scottish unordered anyK=2, got {len(unordered_any)}")

    s = summarize_pairs(directed.split("|"), unordered_any)
    require(s["2->6"] == {"N": 2, "1": 2, "X": 0, "2": 0}, s["2->6"])
    require(s["10->9"] == {"N": 2, "1": 0, "X": 0, "2": 2}, s["10->9"])
    require(s["8->3"]["N"] == 0, "direction mismatch must remain N=0")

    # Find one real directed exact round and prove reordering input still finds it.
    row = conn.execute(
        "SELECT table_size,k_played,signature FROM round_signatures ORDER BY table_size,k_played LIMIT 1"
    ).fetchone()
    table_size, k, canonical = row
    reversed_input = "|".join(reversed(canonical.split("|")))
    recanonical = normalize_and_validate_directed(reversed_input, table_size)
    require(recanonical == canonical, "canonicalization failed for a real DB round")
    hit = conn.execute(
        "SELECT COUNT(*) FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?",
        (table_size, k, recanonical)).fetchone()[0]
    require(hit >= 1, "reordered exact directed round must still hit")

    print("Full-Round CLI smoke test OK")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: test_fullround.py PATH.sqlite")
    main(sys.argv[1])
