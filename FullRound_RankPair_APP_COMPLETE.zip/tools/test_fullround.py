#!/usr/bin/env python3
import sqlite3
import sys
from search_fullround import normalize_and_validate_directed, unordered_signature


def require(cond, msg):
    if not cond:
        raise AssertionError(msg)


def main(db):
    conn = sqlite3.connect(db)
    row = conn.execute(
        "SELECT table_size,k_played,signature FROM round_signatures WHERE k_played>=0 ORDER BY table_size,k_played,round_uid LIMIT 1"
    ).fetchone()
    require(row is not None, "round_signatures is empty")
    table_size, k, canonical = row
    reversed_input = "|".join(reversed(canonical.split("|")))
    recanonical = normalize_and_validate_directed(reversed_input, table_size)
    require(recanonical == canonical, "canonicalization failed")

    directed_k = conn.execute(
        "SELECT COUNT(*) FROM round_signatures WHERE table_size=? AND k_played=? AND signature=?",
        (table_size, k, canonical),
    ).fetchone()[0]
    directed_any = conn.execute(
        "SELECT COUNT(*) FROM round_signatures WHERE table_size=? AND signature=?",
        (table_size, canonical),
    ).fetchone()[0]
    require(directed_k >= 1, "exact directed+K lookup failed")
    require(directed_any >= directed_k, "any-K result cannot be smaller than directed+K")

    unordered = unordered_signature(canonical)
    unordered_any = conn.execute(
        "SELECT COUNT(*) FROM round_signatures_unordered WHERE table_size=? AND unordered_signature=?",
        (table_size, unordered),
    ).fetchone()[0]
    require(unordered_any >= 1, "unordered lookup failed")

    dup_known = conn.execute("""
        SELECT COUNT(*) FROM (
          SELECT league_code,season_key,k_played,COUNT(*) c
          FROM round_signatures WHERE k_played>=0
          GROUP BY league_code,season_key,k_played
          HAVING c>1
        )
    """).fetchone()[0]
    require(dup_known == 0, f"duplicate known-K natural rounds: {dup_known}")
    mixed = conn.execute("SELECT COUNT(*) FROM round_signatures WHERE k_played=-1").fetchone()[0]
    require(mixed > 0, "expected mixed/unknown-K rounds")

    print(f"Full-Round CLI smoke test OK; directed+K={directed_k}; anyK={directed_any}; unorderedAnyK={unordered_any}; mixedK={mixed}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: test_fullround.py PATH.sqlite")
    main(sys.argv[1])
