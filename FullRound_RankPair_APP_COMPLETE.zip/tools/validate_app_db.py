#!/usr/bin/env python3
import sqlite3
import sys

EXPECTED = 25813
EXPECTED_MIXED_K = 2175
EXPECTED_BASE_ID = "fullround_canonical_v6_25813_20260902"
REQUIRED_TABLES = {
    "build_meta", "round_audit", "round_signatures", "round_signatures_unordered",
    "research_meta", "research_leagues", "research_teams", "research_fixtures",
    "research_table_snapshots", "research_table_rows", "local_round_observations",
    "local_round_games", "research_comparisons", "research_sync_log",
    "research_country_queue", "research_season_backfill",
}

def main(path):
    conn = sqlite3.connect(path)
    qc = conn.execute("PRAGMA quick_check").fetchone()[0]
    if qc != "ok":
        raise SystemExit(f"quick_check failed: {qc}")

    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    missing = REQUIRED_TABLES - tables
    if missing:
        raise SystemExit(f"missing required tables: {sorted(missing)}")

    directed = conn.execute("SELECT COUNT(*) FROM round_signatures").fetchone()[0]
    unordered = conn.execute("SELECT COUNT(*) FROM round_signatures_unordered").fetchone()[0]
    audit_n = conn.execute("SELECT COUNT(*) FROM round_audit").fetchone()[0]
    if directed != EXPECTED or unordered != EXPECTED or audit_n != EXPECTED:
        raise SystemExit(f"unexpected historical counts: directed={directed}, unordered={unordered}, audit={audit_n}, expected={EXPECTED}")

    base_id = conn.execute("SELECT value FROM build_meta WHERE key='canonical_base_id'").fetchone()
    if not base_id or base_id[0] != EXPECTED_BASE_ID:
        raise SystemExit(f"unexpected canonical base id: {base_id}")

    for t in ("round_signatures", "round_signatures_unordered"):
        bad = conn.execute(f"SELECT COUNT(*) FROM {t} WHERE num_games * 2 != table_size").fetchone()[0]
        if bad:
            raise SystemExit(f"{t}: {bad} incomplete rounds")

    # For known K a league/season/K body must remain unique. K=-1 explicitly means
    # mixed/unknown played counts and may occur multiple times in the same season.
    dup_known = conn.execute("""
        SELECT COUNT(*) FROM (
          SELECT league_code,season_key,k_played,COUNT(*) c
          FROM round_signatures WHERE k_played>=0
          GROUP BY league_code,season_key,k_played
          HAVING c>1
        )
    """).fetchone()[0]
    if dup_known:
        raise SystemExit(f"known-K natural duplicates found: {dup_known}")

    mixed = conn.execute("SELECT COUNT(*) FROM round_signatures WHERE k_played=-1").fetchone()[0]
    if mixed != EXPECTED_MIXED_K:
        raise SystemExit(f"unexpected mixed-K count: {mixed}, expected={EXPECTED_MIXED_K}")

    mismatch = conn.execute("""
        SELECT COUNT(*)
        FROM round_signatures s
        JOIN round_signatures_unordered u USING(round_uid)
        WHERE s.signature<>u.directed_signature
           OR COALESCE(s.result_vector,'')<>COALESCE(u.result_vector,'')
           OR COALESCE(s.score_vector,'')<>COALESCE(u.score_vector,'')
    """).fetchone()[0]
    if mismatch:
        raise SystemExit(f"directed/unordered mismatches: {mismatch}")

    mode = conn.execute("SELECT value FROM research_meta WHERE key='app_research_mode'").fetchone()
    if not mode or mode[0] != "GLOBAL_FULLROUND_ONLY":
        raise SystemExit(f"unexpected research mode: {mode}")
    schema = conn.execute("SELECT value FROM research_meta WHERE key='research_schema_version'").fetchone()
    if not schema or schema[0] != 'MULTISOURCE_V10':
        raise SystemExit(f"unexpected research schema: {schema}")

    print(f"DB OK: quick_check={qc}; canonical={base_id[0]}; directed={directed}; unordered={unordered}; known-K duplicates=0; mixed-K={mixed}; research_schema={schema[0]}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: validate_app_db.py PATH.sqlite")
    main(sys.argv[1])
