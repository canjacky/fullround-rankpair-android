#!/usr/bin/env python3
import sqlite3
import sys

REQUIRED_TABLES = {
    "round_signatures", "round_signatures_unordered",
    "research_meta", "research_leagues", "research_teams", "research_fixtures",
    "research_table_snapshots", "research_table_rows", "local_round_observations",
    "local_round_games", "research_comparisons", "research_sync_log",
}


def main(path):
    conn = sqlite3.connect(path)
    qc = conn.execute("PRAGMA quick_check").fetchone()[0]
    if qc != "ok":
        raise SystemExit(f"quick_check failed: {qc}")

    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    missing = REQUIRED_TABLES - tables
    if missing:
        raise SystemExit(f"missing required tables: {sorted(missing)}")

    directed = conn.execute("SELECT COUNT(*) FROM round_signatures").fetchone()[0]
    unordered = conn.execute("SELECT COUNT(*) FROM round_signatures_unordered").fetchone()[0]
    if directed != 10260 or unordered != 10260:
        raise SystemExit(f"unexpected historical counts: directed={directed}, unordered={unordered}")

    for t in ("round_signatures", "round_signatures_unordered"):
        bad = conn.execute(f"SELECT COUNT(*) FROM {t} WHERE num_games * 2 != table_size").fetchone()[0]
        if bad:
            raise SystemExit(f"{t}: {bad} incomplete rounds")

    forbidden = {"rankpair_counts", "rankpair_counts_by_league", "rankpair_scores"}
    if tables & forbidden:
        raise SystemExit(f"forbidden fallback tables bundled: {sorted(tables & forbidden)}")

    print(f"DB OK: quick_check={qc}; directed={directed}; unordered={unordered}; research_schema=OK")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: validate_app_db.py PATH.sqlite")
    main(sys.argv[1])
