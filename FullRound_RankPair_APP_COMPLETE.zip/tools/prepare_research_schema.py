#!/usr/bin/env python3
import sqlite3, sys
p=sys.argv[1]
con=sqlite3.connect(p)
con.executescript('''
CREATE TABLE IF NOT EXISTS research_meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS research_leagues (league_id TEXT PRIMARY KEY, league_name TEXT, country TEXT, sport TEXT, source TEXT NOT NULL, season TEXT, table_size INTEGER, discovered_at TEXT, last_sync_at TEXT, last_error TEXT, seasons_discovered_at TEXT);
CREATE TABLE IF NOT EXISTS research_country_queue (country TEXT PRIMARY KEY, discovered_at TEXT NOT NULL, last_crawled_at TEXT, last_error TEXT);
CREATE TABLE IF NOT EXISTS research_season_backfill (league_id TEXT NOT NULL, season TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0, events_count INTEGER DEFAULT 0, rounds_added INTEGER DEFAULT 0, duplicates_skipped INTEGER DEFAULT 0, last_attempt_at TEXT, last_error TEXT, PRIMARY KEY(league_id,season));
CREATE INDEX IF NOT EXISTS idx_backfill_status ON research_season_backfill(status,last_attempt_at);
CREATE TABLE IF NOT EXISTS research_teams (team_id TEXT PRIMARY KEY, team_name TEXT NOT NULL, league_id TEXT, source TEXT NOT NULL, updated_at TEXT);
CREATE TABLE IF NOT EXISTS research_fixtures (event_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, event_date TEXT, event_time TEXT, home_team_id TEXT, home_team TEXT, away_team_id TEXT, away_team TEXT, home_score INTEGER, away_score INTEGER, status TEXT, result_1x2 TEXT, source TEXT NOT NULL, fetched_at TEXT);
CREATE INDEX IF NOT EXISTS idx_research_fixtures_league_round ON research_fixtures(league_id, season, round_no);
CREATE INDEX IF NOT EXISTS idx_research_fixtures_date ON research_fixtures(event_date);
CREATE TABLE IF NOT EXISTS research_table_snapshots (snapshot_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, captured_at TEXT NOT NULL, table_size INTEGER NOT NULL, source TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_research_snapshots_league ON research_table_snapshots(league_id, captured_at);
CREATE TABLE IF NOT EXISTS research_table_rows (snapshot_id TEXT NOT NULL, team_id TEXT NOT NULL, team_name TEXT NOT NULL, rank INTEGER, played INTEGER, wins INTEGER, draws INTEGER, losses INTEGER, goals_for INTEGER, goals_against INTEGER, goal_diff INTEGER, points INTEGER, form TEXT, PRIMARY KEY(snapshot_id, team_id));
CREATE TABLE IF NOT EXISTS local_round_observations (observation_id TEXT PRIMARY KEY, league_id TEXT NOT NULL, league_name TEXT, season TEXT, round_no TEXT, table_size INTEGER NOT NULL, k_played INTEGER, date_min TEXT, date_max TEXT, signature TEXT NOT NULL, unordered_signature TEXT NOT NULL, result_vector TEXT, score_vector TEXT, state TEXT NOT NULL, source TEXT NOT NULL, prematch_snapshot_id TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, research_kind TEXT, rank_method TEXT, dedupe_fingerprint TEXT);
CREATE INDEX IF NOT EXISTS idx_local_round_signature ON local_round_observations(table_size, signature, state);
CREATE INDEX IF NOT EXISTS idx_local_round_unordered ON local_round_observations(table_size, unordered_signature, state);
CREATE UNIQUE INDEX IF NOT EXISTS idx_local_round_fingerprint ON local_round_observations(dedupe_fingerprint) WHERE dedupe_fingerprint IS NOT NULL;
CREATE TABLE IF NOT EXISTS local_round_games (observation_id TEXT NOT NULL, event_id TEXT NOT NULL, home_team_id TEXT, away_team_id TEXT, home_rank INTEGER NOT NULL, away_rank INTEGER NOT NULL, PRIMARY KEY(observation_id, event_id));
CREATE TABLE IF NOT EXISTS research_comparisons (observation_id TEXT PRIMARY KEY, generated_at TEXT NOT NULL, directed_with_k_n INTEGER, directed_any_k_n INTEGER, unordered_any_k_n INTEGER, summary TEXT);
CREATE TABLE IF NOT EXISTS research_sync_log (id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL, leagues_discovered INTEGER DEFAULT 0, leagues_synced INTEGER DEFAULT 0, fixtures_upserted INTEGER DEFAULT 0, snapshots_added INTEGER DEFAULT 0, observations_added INTEGER DEFAULT 0, observations_completed INTEGER DEFAULT 0, countries_crawled INTEGER DEFAULT 0, today_fixtures INTEGER DEFAULT 0, seasons_queued INTEGER DEFAULT 0, backfills_processed INTEGER DEFAULT 0, historical_rounds_added INTEGER DEFAULT 0, duplicates_skipped INTEGER DEFAULT 0, message TEXT);
''')
con.execute("INSERT OR REPLACE INTO research_meta(key,value) VALUES('app_research_mode','GLOBAL_FULLROUND_ONLY')")
con.execute("INSERT OR REPLACE INTO research_meta(key,value) VALUES('global_research_schema','v7')")
con.commit()
print('quick_check=',con.execute('pragma quick_check').fetchone()[0])
print('historical_rounds=',con.execute('select count(*) from round_signatures').fetchone()[0])
print('research_tables=',con.execute("select count(*) from sqlite_master where type='table' and name like 'research_%'").fetchone()[0])
con.close()
