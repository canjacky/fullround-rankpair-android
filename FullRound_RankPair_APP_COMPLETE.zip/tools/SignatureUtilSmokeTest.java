import com.gesundheit.fullround.SignatureUtil;

public final class SignatureUtilSmokeTest {
    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String a = SignatureUtil.normalizeAndValidateDirectedSignature(
                "10->9|5->1|2->6|8->3|4->7", 10);
        String b = SignatureUtil.normalizeAndValidateDirectedSignature(
                "2->6|4->7|5->1|8->3|10->9", 10);
        require(a.equals(b), "same round in different input order must canonicalize identically");
        require(a.equals("2->6|4->7|5->1|8->3|10->9"), "unexpected canonical order: " + a);
        require(SignatureUtil.toUnorderedSignature(a).equals("1-5|2-6|3-8|4-7|9-10"),
                "unexpected unordered signature");

        boolean rejected = false;
        try {
            SignatureUtil.normalizeAndValidateDirectedSignature("2->6|4->7|5->1|8->3", 10);
        } catch (IllegalArgumentException expected) {
            rejected = true;
        }
        require(rejected, "incomplete round must be rejected");

        rejected = false;
        try {
            SignatureUtil.normalizeAndValidateDirectedSignature("2->6|4->7|5->1|8->3|2->9", 10);
        } catch (IllegalArgumentException expected) {
            rejected = true;
        }
        require(rejected, "duplicate rank must be rejected");

        System.out.println("SignatureUtil smoke test OK");
    }
}
