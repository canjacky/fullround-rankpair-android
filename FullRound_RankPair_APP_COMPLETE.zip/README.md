# FullRound Global Research v3.2.0

Diese Android-App arbeitet ausschließlich mit Full-Round-/RankPair-Körpern. JSTB ist nicht Bestandteil der App.

## Kanonische eingebaute Basis

- 25.813 directed Full-Round-Cases
- 25.813 passende unordered Cases
- Grundlage: `fullround_rankpair_reconstructed_v6.sqlite`
- V6 entfernt 548 normalisierte Cross-Source-Doppelrunden aus dem alten V5-Kern
- zusätzlich 2.588 validierte explizite Full-Rounds gegenüber dem bereinigten V5-Kern
- Legacy-V4 wird **nicht** blind angehängt: die 171 alten App-Fälle besitzen in der kompakten Altbasis keine Match-Level-Teamidentität mehr und können deshalb nicht vollständig semantisch gegen V6 dedupliziert werden
- 2.175 Runden besitzen `K=-1`: K/Played ist dort gemischt oder nicht einheitlich; diese Runden sind für Suchen **ohne K** nutzbar
- bei bekanntem `K >= 0` bleibt `(Liga, Saison, K)` eindeutig

## Basis-Upgrade ohne Verlust lokaler Research-Daten

Der interne DB-Name bleibt unverändert. Beim Update erkennt die App die alte 23.944er Basis über `build_meta` und ersetzt **nur die statischen Basis-Tabellen** durch die kanonische V6-Basis. Lokale Research-Tabellen, historische Backfill-Queues, Fixtures, Snapshots und selbst gelernte COMPLETE-Cases bleiben erhalten. Exakte lokale Fälle, die inzwischen bereits in der neuen statischen Basis vorkommen, werden anschließend dedupliziert.

Der frühere Unique-Zwang auf `(Liga,Saison,K)` wurde entfernt, weil er für `K=-1` fachlich falsch ist: mehrere valide Mixed-K-Runden derselben Saison müssen gespeichert werden dürfen.

## Multi-Source-Research

Alle 6 Stunden und beim ersten Start arbeitet die App mehrere Quellen ab:

1. **TheSportsDB**
   - Länder und Soccer-Ligen entdecken
   - Tages-Events abrufen
   - Tabellen und Saisonfixtures laden
   - optional mit eigenem Key für größere Provider-Abdeckung

2. **OpenLigaDB** — ohne API-Key
   - aktuelle Soccer-Ligen katalogisieren
   - aktuelle Spieltage zusätzlich nach heutigen Events durchsuchen
   - historische Jahrgänge automatisch rückwärts katalogisieren
   - historische Saisons in die Backfill-Queue übernehmen

3. **football-data.org** — optional mit Token
   - verfügbare Wettbewerbe laden
   - heutige Matches laden
   - aktuelle Tabellen und Matches laden
   - verfügbare historische Saisons für Backfills katalogisieren

## Heutige Spiele

Gefundene Tages-Events werden zunächst lokal gespeichert. Für eine automatische Full-Round-Analyse muss anschließend eine vollständige Runde mit sicherer Prematch-Tabelle vorhanden sein. Erst dann wird der Rangpaar-Körper eingefroren und gegen die Datenbank geprüft:

- directed mit K
- directed ohne K
- unordered ohne K

## Historischer Backfill

Historische Saisons werden nicht einfach als Roh-Ergebnisse übernommen. Die App rekonstruiert den Tabellenstand Runde für Runde und akzeptiert nur vollständige Full-Rounds. Die generische Rekonstruktions-Rangfolge ist Punkte → Tordifferenz → erzielte Tore → Siege. Provider- oder ligaspezifische Sonderregeln können davon abweichen; solche Fälle bleiben als rekonstruierte Research-Cases gekennzeichnet.

## Update-Verhalten

- Paketname: `com.gesundheit.fullround`
- Stable-Debug-Signatur unverändert
- interner DB-Name unverändert
- `versionCode=13`
- `versionName=3.2.0-canonical-v6-stablesign`
- vorhandene `build.yml` bleibt unverändert

## Dashboard

Der Datenbank-/Tages-Bereich besitzt weiterhin einen eigenen Ausgabebereich direkt unter dem Button und scrollt nach dem Laden dorthin.
