# FullRound Auto Research v2.1 — Expanded V4

Android-App mit eingebauter historischer Full-Round-Datenbank plus selbst wachsender Research-Schicht.

## Automatik
- Background-Sync alle 6 Stunden über Android JobScheduler
- sofortiger erster Sync beim ersten App-Start
- TheSportsDB Free-Key 123 funktioniert ohne Einrichtung
- optional football-data.org Token für vollständige, freigeschaltete Wettbewerbe
- Fixtures/Ergebnisse werden in SQLite upserted
- Tabellen werden als zeitgestempelte Snapshots gespeichert
- kommende vollständige Runden werden nur vor dem ersten beendeten Spiel eingefroren
- nach Abschluss wird der eingefrorene Prematch-Körper als neuer lokaler historischer Full-Round-Case gespeichert
- automatische Vergleichssuche gegen 10.260 eingebettete historische Runden aus `fullround_rankpair_expanded_v4.sqlite` + neu gelernte lokale Cases

## Datenintegrität
Prematch-Ränge werden niemals aus einer nach Spielbeginn aktualisierten Tabelle rückwirkend erzeugt. Eine neue lokale historische Runde entsteht nur, wenn sie vorher als UPCOMING mit vollständiger Tabelle und vollständigem Spielplan eingefroren wurde.

## Datenquellen
- TheSportsDB v1: Standard-Key 123; freie Abdeckung ist providerseitig begrenzt.
- football-data.org v4: optionaler Token; Data provided by football-data.org.

Die App speichert den optionalen Token nur lokal in Android SharedPreferences.

## Eingebettete historische DB
- Basis: `fullround_rankpair_expanded_v4.sqlite`
- Directed Full-Round Cases: 10.260
- Unordered Full-Round Cases: 10.260
- Die Research-Schicht bleibt aktiv und ergänzt neue, sauber prematch eingefrorene Runden lokal.
