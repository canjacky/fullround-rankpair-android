# FullRound Auto Research v2.2 — Union V6

Diese Android-App enthält eine deduplizierte historische Full-Round-Datenbank und die automatische Research-Schicht.

## Historische Basis

- `fullround_rankpair_reconstructed_v5.sqlite`: 23.773 Runden
- alte `fullround_rankpair_expanded_v4.sqlite`: 10.260 Runden
- davon 10.089 exakt bereits in V5 vorhanden → **nicht doppelt übernommen**
- 171 echte zusätzliche V4-Runden übernommen
- finale Basis: **23.944 eindeutige Full-Round-Runden**

Die App sucht weiterhin:
- directed mit K
- directed ohne K / Any-K
- unordered mit/ohne K als Richtungs-Audit
- neu gelernte lokale Auto-Research-Cases zusätzlich zur historischen Basis

## Automatisches Research

Die bestehende Auto-Research-Logik bleibt erhalten: Fixtures/Tabellen laden, Prematch-Runden einfrieren, Ergebnisse nachtragen und abgeschlossene lokale Runden als neue Vergleichscases speichern.

Siehe `DATABASE_MERGE_REPORT.txt` für den Dedupe-Audit.
