# FullRound Global Research v3.0

Diese Android-App arbeitet ausschließlich mit Full-Round-/RankPair-Körpern. JSTB ist nicht Bestandteil der App.

## Eingebaute Basis

- 23.944 deduplizierte directed Full-Round-Cases
- 23.944 passende unordered Cases
- Basis aus reconstructed V5 + den 171 zusätzlichen, nicht in V5 enthaltenen V4-Runden

## Automatik

Alle 6 Stunden und beim ersten Start:

1. globalen Soccer-Liga-Katalog erweitern
2. Länder schrittweise crawlen und dort Soccer-Ligen entdecken
3. heutige Soccer-Spiele über den Tages-Endpunkt abrufen
4. für heutige Ligen aktuelle Tabelle + verfügbare Saisonfixtures abrufen
5. vollständige heutige/kommende Prematch-Runden einfrieren
6. mit der gesamten lokalen Full-Round-Datenbank vergleichen
7. historische Saisons in einer persistenten Backfill-Queue abarbeiten
8. historische Tabellenstände aus den bis dahin abgeschlossenen Spielen rekonstruieren
9. nur vollständige Runden als neue COMPLETE-Cases speichern
10. vor dem Speichern gegen Basis + lokal gelernte Cases deduplizieren

## Historische Rekonstruktion

Historische Rangstände werden aus Saisonergebnissen mit der generischen Reihenfolge Punkte, Tordifferenz, erzielte Tore, Siege rekonstruiert. Eine Saison wird nur entlang einer lückenlosen Folge kompletter Full-Rounds verarbeitet. Bei fehlenden/gekürzten Providerdaten bleibt sie `PARTIAL` und kann später erneut geprüft werden.

## Datenquellen

- Hauptquelle: TheSportsDB
- optional: football-data.org als zweite aktuelle Quelle

Die tatsächliche weltweite Abdeckung hängt von den vom jeweiligen API-Key gelieferten Datensätzen und Limits ab. Die App selbst besitzt keine feste Länder-/Ligaliste mehr.

## GitHub

Der Dateiname der vollständigen Projekt-ZIP bleibt `FullRound_RankPair_APP_COMPLETE.zip`, damit die vorhandene `build.yml` unverändert weiterverwendet werden kann.
