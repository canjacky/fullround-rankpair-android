# FullRound Global Research v3.1

Diese Android-App arbeitet ausschließlich mit Full-Round-/RankPair-Körpern. JSTB ist nicht Bestandteil der App.

## Eingebaute Basis

- 23.944 directed Full-Round-Cases
- 23.944 passende unordered Cases
- automatische lokale Erweiterung durch neue COMPLETE-Full-Rounds

## Multi-Source-Research

Alle 6 Stunden und beim ersten Start arbeitet die App mehrere Quellen ab:

1. **TheSportsDB**
   - Länder und Soccer-Ligen entdecken
   - Tages-Events abrufen
   - Tabellen und Saisonfixtures laden
   - optional mit eigenem Key für größere Provider-Abdeckung

2. **OpenLigaDB** — ohne API-Key
   - aktuelle Soccer-Ligen aus aktuellem und vorherigem Saisonjahr katalogisieren
   - aktuelle Spieltage zusätzlich nach heutigen Events durchsuchen
   - historische Jahrgänge automatisch rückwärts katalogisieren
   - pro Sync weitere historische Saisons in die Backfill-Queue übernehmen

3. **football-data.org** — optional mit Token
   - verfügbare Wettbewerbe laden
   - heutige Matches in einer globalen Tagesabfrage laden
   - aktuelle Tabellen und Matches laden
   - verfügbare historische Saisons für Backfills katalogisieren

## Heutige Spiele

Gefundene Tages-Events werden zunächst lokal gespeichert. Für eine automatische Full-Round-Analyse muss anschließend eine vollständige Runde mit sicherer Prematch-Tabelle vorhanden sein. Erst dann wird der Rangpaar-Körper eingefroren und gegen die Datenbank geprüft:

- directed mit K
- directed ohne K
- unordered ohne K

## Historischer Backfill

Historische Saisons werden nicht einfach als Roh-Ergebnisse übernommen. Die App rekonstruiert den Tabellenstand Runde für Runde und akzeptiert nur einen Fall, wenn:

- die Liga eine gerade Teamzahl besitzt,
- jede Runde vollständig ist,
- jedes Team genau einmal in der Runde vorkommt,
- alle Ergebnisse der Runde vorhanden sind,
- die vorherigen Runden lückenlos rekonstruiert werden konnten.

Die generische Rekonstruktions-Rangfolge ist Punkte → Tordifferenz → erzielte Tore → Siege. Provider- oder ligaspezifische Sonderregeln können davon abweichen; solche Fälle bleiben als rekonstruierte Research-Cases gekennzeichnet.

## Deduplizierung

Vor jedem neuen COMPLETE-Insert wird gegen die eingebaute Basis und alle lokal gelernten Fälle geprüft. Bei Multi-Source-Daten wird zusätzlich ein ±1-Tages-Toleranzfenster verwendet, aber nur wenn kompletter Rangpaar-, Ergebnis- und Scorekörper identisch sind. Dadurch sollen UTC/Lokalzeit-Verschiebungen nicht zu Doppelzählungen führen.

## Update-Verhalten

- Paketname bleibt `com.gesundheit.fullround`.
- Stable-Debug-Signatur bleibt unverändert.
- Interner DB-Name bleibt unverändert, damit selbst gelernte Fälle bei APK-Updates erhalten bleiben.
- `versionCode=11`
- `versionName=3.1.0-multisource-global-stablesign`

## GitHub

Der Dateiname bleibt `FullRound_RankPair_APP_COMPLETE.zip`. Die vorhandene `build.yml` muss nicht geändert werden.
