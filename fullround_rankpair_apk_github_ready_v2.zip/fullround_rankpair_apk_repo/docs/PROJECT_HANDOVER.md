# Projektübergabe — Full-Round-/Rankpair-System

Stand: 2026-09-01
App: v1.1.0
App-DB: v3

## Ziel

Eigenständiges Fußball-Prematch-System ohne Odds, WDL, Form oder altes JSTB-Framework. Einstieg ist immer der komplette Zielspieltag.

## Prematch-Rekonstruktion

```text
Letzter vollständig beendeter Spieltag = K
Nächster Zielspieltag = K+1
Tabelle nach K -> Ränge für alle Spiele von K+1
```

Ein bereits beendeter Zielspieltag darf nicht rückwirkend als Input verwendet werden.

## Suchlogik

1. directed Full-Round mit `K` exakt.
2. directed Full-Round ohne `K` exakt.
3. unordered Full-Round ohne `K` nur als Diagnose; danach aktuelle Home/Away-Richtung je Paar separat prüfen.
4. Kein Standalone-Einzelrangpaar-Fallback.

`1->10 != 10->1`. Keine Richtungsdrehung.

## Kanonisierung

Die Reihenfolge der Spiele in der Eingabe ist irrelevant. Vor der DB-Suche wird die Liste der gerichteten Rangpaare nach Home-Rang sortiert. Dadurch erzeugen verschiedene Eingabereihenfolgen dieselbe Full-Round-Signatur, ohne Home/Away zu verändern.

## Eingabegate

Für eine Liga mit `N` Teams:

- `N` gerade,
- genau `N/2` Spiele,
- jeder Rang `1..N` exakt einmal,
- `K` Pflicht.

Unvollständige oder doppelte Runden werden vor der DB-Suche abgelehnt.

## Max-2-Filter

Gilt je Paarung innerhalb eines gefundenen Full-Round-Kontexts:

```text
1-X-2 -> raus
1-X-0 -> 1X
0-X-2 -> X2
1-0-2 -> 12
1-0-0 -> 1 / 1X
0-X-0 -> X only
0-0-2 -> 2 / X2
```

## Validierter historischer Stand

Kompakte App-DB:

```text
data/fullround_rankpair_app_v3.sqlite.zip
```

Enthalten:

- `round_signatures`: 2999
- `round_signatures_unordered`: 2999
- keine Einzelrangpaar-Fallbacktabellen
- `PRAGMA quick_check = ok`

Der Scottish-Championship-Diagnosetest reproduziert weiterhin:

```text
directed mit K = 0
directed ohne K = 0
unordered ohne K = 2
2->6 = N2 / 2-0-0
10->9 = N2 / 0-0-2
8->3 = N0 wegen fehlender heutiger historischer Richtung
```

## Aktuelle App

Manuelle Offline-Eingabe:

- Teamzahl
- K
- komplette gerichtete Full-Round-Signatur
- optional aktuelle Teamnamen, eine Zeile pro Spiel

Ausgabe je Suchstufe:

```text
Spiel | Rangpaar | N | 1-X-2 | Kandidat
```

Die App kennt noch keinen automatischen Fixture-/Tabellenadapter. Automatische Bestimmung von K und Aufbau der Rangpaare ist die nächste Ausbaustufe.

## GitHub Actions

Der Workflow validiert DB und Suchlogik vor jedem Android-Build. Gradle 8.10.2 wird gepinnt; im CI wird daraus der offizielle Wrapper erzeugt und anschließend über `./gradlew assembleDebug` gebaut.
