# Validierung — FullRound Rankpair APK v1.1.0

Stand: 2026-09-01

## Datenbank

- `PRAGMA quick_check = ok`
- `round_signatures = 2999`
- `round_signatures_unordered = 2999`
- jede gebündelte Runde erfüllt `num_games * 2 = table_size`
- keine `rankpair_counts`, `rankpair_counts_by_league` oder `rankpair_scores` in der App-DB
- App-DB entpackt: 2,625,536 Byte
- App-DB ZIP: ca. 661 KiB

## Logiktests

### Kanonisierung

Diese Eingaben müssen denselben directed Key ergeben:

```text
10->9|5->1|2->6|8->3|4->7
2->6|4->7|5->1|8->3|10->9
```

Erwartet:

```text
2->6|4->7|5->1|8->3|10->9
```

Test: bestanden.

### Vollständigkeitsgate

- zu wenige Spiele: abgelehnt
- doppelt verwendeter Rang: abgelehnt
- Rang außerhalb der Teamzahl: abgelehnt
- ungerade Teamzahl: abgelehnt

### Scottish-Championship-Regression

Ziel:

```text
2->6|4->7|5->1|8->3|10->9
```

Ergebnis:

```text
Directed mit K: 0
Directed ohne K: 0
Unordered ohne K: 2
```

Paarprüfung in heutiger Richtung:

```text
2->6  N=2  2-0-0  1 / 1X
4->7  N=1  1-0-0  1 / 1X, Low-N
5->1  N=1  0-0-1  2 / X2, Low-N
8->3  N=0  Richtung historisch nicht vorhanden
10->9 N=2  0-0-2  2 / X2
```

Test: bestanden.

### Reordered real directed hit

Ein realer directed Full-Round-Treffer aus der DB wird im Test umgekehrt eingegeben, neu kanonisiert und erneut exakt gesucht.

Test: bestanden.

## Build-Prüfung

- Workflow-YAML syntaktisch parsebar
- Python-Tools kompilieren syntaktisch
- Shell-Skripte bestehen `bash -n`
- reine Java-Signaturlogik kompiliert mit `javac` und Smoke-Test bestanden

Der vollständige Android-APK-Build wird durch GitHub Actions ausgeführt. Der Workflow pinnt Java 17, Gradle 8.10.2 und erzeugt vor `assembleDebug` den offiziellen Gradle Wrapper im CI.
