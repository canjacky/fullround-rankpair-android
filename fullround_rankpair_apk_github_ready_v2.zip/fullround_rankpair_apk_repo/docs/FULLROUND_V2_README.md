# Full-Round Index — aktive App-Lesung

## Zweck

Historischer Vergleich kompletter Spieltags-Rangpaarungen. Für die Android-App wird eine kompakte DB verwendet, die ausschließlich Full-Round-Tabellen enthält.

## Directed Full-Round

Kanonische gerichtete Signatur:

```text
HomeRank->AwayRank|HomeRank->AwayRank|...
```

Die Liste wird nach Home-Rang sortiert. Die Richtung innerhalb eines Paars wird nie verändert.

Beispiel:

```text
10->9|5->1|2->6|8->3|4->7
```

wird kanonisch:

```text
2->6|4->7|5->1|8->3|10->9
```

### Suchstufe 1 — directed mit K

```sql
SELECT *
FROM round_signatures
WHERE table_size=?
  AND k_played=?
  AND signature=?;
```

### Suchstufe 2 — directed ohne K

```sql
SELECT *
FROM round_signatures
WHERE table_size=?
  AND signature=?;
```

## Unordered Full-Round — nur Diagnose

Jedes Paar wird intern als `minRank-maxRank` dargestellt; alle Paare werden sortiert.

```sql
SELECT *
FROM round_signatures_unordered
WHERE table_size=?
  AND unordered_signature=?;
```

`K` wird in der eigentlichen Diagnose ignoriert. Ein zusätzlicher unordered-mit-K-Block darf nur als Audit gezeigt werden.

Wichtig: Ein unordered Full-Round-Treffer erzeugt noch keinen Tipp. Für jedes aktuelle Rangpaar wird im historischen `result_vector` anschließend **exakt die heutige Richtung** gesucht. Fehlt sie, ist `N=0`; es gibt keine Richtungsdrehung.

## Max-2-Filter pro Paarung

| Historische Arten | Ausgabe |
|---|---|
| 1/X/2 | raus |
| 1+X | 1X |
| X+2 | X2 |
| 1+2 | 12 |
| nur 1 | 1 / 1X |
| nur X | X only |
| nur 2 | 2 / X2 |

## App-DB v3

Gebündelt sind nur:

- `round_signatures`
- `round_signatures_unordered`
- die dafür nötigen Indizes

Standalone-Tabellen wie `rankpair_counts` oder `rankpair_scores` werden absichtlich **nicht** mit der App ausgeliefert.
