# FullRound Rankpair APK — v1.1.0 / App-DB v3

Offline-Android-App und GitHub-Actions-Projekt für das Full-Spieltag-Rangpaar-System.

## Verbindliche Systemregel

1. Letzter vollständig beendeter Spieltag = `K`.
2. Zielspieltag = `K+1`.
3. Tabelle nach `K` liefert die Ränge für alle Spiele von `K+1`.
4. Die komplette Zielrunde wird als gerichtete Full-Round-Signatur gesucht.
5. Home/Away wird niemals gedreht: `1->10` ist nicht `10->1`.
6. Der Max-2-Filter gilt pro Rangpaar, nicht für die gesamte historische Runde.
7. Keine Einzel-Rangpaar-Suche ohne vorherigen Full-Round-Kontext.

### Suchstufen

- **1 Hauptsuche:** Full-Round `table_size + K + directed` exakt.
- **2 Hauptsuche:** Full-Round `table_size + directed` exakt, `K` historisch egal.
- **3 Diagnose:** Full-Round `table_size + unordered` ohne `K`; anschließend wird je aktuellem Rangpaar nur die **heutige Home/Away-Richtung** gezählt.
- **Zusatz-Audit:** unordered mit `K`; keine eigene Freigabestufe.

## Wichtige Korrektur: kanonische Signatur

Die Reihenfolge, in der Spiele eingegeben werden, darf keinen Treffer verändern. Die App sortiert deshalb die **Liste** der gerichteten Paarungen automatisch nach Home-Rang.

Beide Eingaben werden identisch gesucht:

```text
10->9|5->1|2->6|8->3|4->7
2->6|4->7|5->1|8->3|10->9
```

Kanonisch:

```text
2->6|4->7|5->1|8->3|10->9
```

Dabei wird **kein Paar gedreht**.

## Harte Eingabevalidierung

Für `N` Teams akzeptiert die App nur eine vollständige Runde:

- Teamzahl gerade und >= 2.
- exakt `N/2` Spiele.
- jeder Rang `1..N` genau einmal.
- keine Rangwiederholung.
- kein `x->x`.
- `K` ist Pflicht.

## Teamnamen

Optional können aktuelle Teamnamen eingegeben werden, eine Zeile pro Spiel in derselben Reihenfolge wie die ursprüngliche Signatur. Die Ergebnisliste zeigt dann:

```text
Spiel | Rangpaar | N | 1-X-2 | Kandidat
```

Die historische DB bleibt rangbasiert; Teamnamen sind nur aktuelle Anzeige-Metadaten.

## Kompakte App-Datenbank

Das APK-Paket enthält nur die zwei benötigten Full-Round-Tabellen:

```text
round_signatures
round_signatures_unordered
```

Nicht enthalten sind die ausgeschlossenen Standalone-Rankpair-Fallbacktabellen.

Datei im Repo:

```text
data/fullround_rankpair_app_v3.sqlite.zip
```

Validierter Stand:

- directed Full-Rounds: `2999`
- unordered Full-Rounds: `2999`
- SQLite `quick_check = ok`
- SQLite entpackt: ca. 2.6 MB
- ZIP: ca. 0.66 MB

Der Workflow entpackt nach:

```text
app/src/main/assets/fullround_rankpair_app_v3.sqlite
```

## GitHub Actions APK-Build

Workflow:

```text
.github/workflows/build.yml
```

Zusätzlich liegt dieselbe Datei als `build.yml` im Repo-Root.

Der Build führt vor dem APK-Build aus:

1. kompakte DB entpacken,
2. DB-Schema + `quick_check` validieren,
3. Java-Smoke-Test für kanonische Signaturen,
4. Python-Smoke-Test gegen echte historische Full-Rounds,
5. offiziellen Gradle Wrapper mit Gradle `8.10.2` im CI erzeugen,
6. `./gradlew assembleDebug`,
7. APK als GitHub Artifact hochladen.

## Lokaler Test

Datenbank entpacken:

```bash
./tools/unpack_db.sh
```

CLI-Test:

```bash
python3 tools/test_fullround.py app/src/main/assets/fullround_rankpair_app_v3.sqlite
```

Manuelle Suche:

```bash
python3 tools/search_fullround.py \
  --db app/src/main/assets/fullround_rankpair_app_v3.sqlite \
  --table-size 10 \
  --k 4 \
  --signature '10->9|5->1|2->6|8->3|4->7'
```

Wenn lokal Gradle 8.10.2 vorhanden ist, kann der offizielle Wrapper erzeugt werden:

```bash
./tools/bootstrap_gradle_wrapper.sh
./gradlew assembleDebug
```

Auf GitHub Actions wird dieser Wrapper-Bootstrap automatisch durchgeführt.

## Aktueller App-Scope

Die App ist ein **Offline-MVP ab dem rekonstruierten Prematch-Zustand**. Sie erwartet aktuell:

- Teamzahl,
- `K`,
- komplette Rangpaar-Signatur,
- optional Teamnamen.

Noch nicht automatisch enthalten sind Fixture-Download, Tabellenrekonstruktion und automatische Bestimmung von `K`. Diese gehören zur nächsten Adapter-Stufe und ändern die Full-Round-Suchlogik nicht.
