#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.10.2 muss einmalig auf PATH vorhanden sein, um den offiziellen Wrapper zu erzeugen." >&2
  echo "Auf GitHub Actions erledigt der Workflow diesen Bootstrap automatisch." >&2
  exit 1
fi
gradle wrapper --gradle-version 8.10.2 --distribution-type bin
chmod +x gradlew
./gradlew --version
