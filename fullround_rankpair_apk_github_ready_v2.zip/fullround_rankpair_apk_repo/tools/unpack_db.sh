#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p app/src/main/assets
unzip -o data/fullround_rankpair_app_v3.sqlite.zip -d app/src/main/assets
rm -f app/src/main/assets/FULLROUND_APP_DB_README.txt
python3 tools/validate_app_db.py app/src/main/assets/fullround_rankpair_app_v3.sqlite
ls -lh app/src/main/assets/fullround_rankpair_app_v3.sqlite
